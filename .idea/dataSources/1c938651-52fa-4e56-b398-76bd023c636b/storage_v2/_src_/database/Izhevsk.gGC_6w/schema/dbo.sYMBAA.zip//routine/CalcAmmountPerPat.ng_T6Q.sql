

-- Скалярная функция определяющая стоимость одного прикрепления
create function dbo.CalcAmmountPerPat(
	@FM_CLINK_PATIENTS_ID int,
	@CHECK_BILLDET_PAY bit = 1
) returns money 
as 
begin
	declare @Result money
	set @Result = null

	select
		@Result = 
		case 
			when p.MANUAL_PRICE=1 then 
				-- Цена задана вручную:
				-- Или Стоимость полиса-прикрепления пациента или Стоимость полиса-Мед.программы или Сумма договора-договора
				coalesce(p.AMOUNT_PER_PAT, cl.AMOUNT_PER_PAT, ct.CONTR_SUM, 0)
			when IsNull(ct.CALC_PRICE_INSURER, 0)=0 then
				-- Для договоров с ценами НЕ по страхователю
			    -- Стоимость прикрепления = (ISNULL( Стоимость МП, Стоимость Договора) + Надбавка) * Коэф-т
				(coalesce(cl.AMOUNT_PER_PAT, ct.CONTR_SUM, 0) + IsNull(p.INCREASE,0))*IsNull(NullIf(p.COEF, 0), 1)	
			else			
				-- Для договоров с ПО страхователю
				case 
					-- Страхователь не указан
					when p.FM_ORG_INSURER is null then
					  -- (Базовая стоимость для минимального количества прикрепленных + Надбавка)*Коэф-т    
					  (IsNull((select max(p1.PRICE)
						from FM_CLINK_PRICE p1 with (nolock)
						inner join (
							select FM_CLINK_ID, IsNull(min(PATIENTS_COUNT_MAX),0) PATIENTS_COUNT_MIN
							from FM_CLINK_PRICE with (nolock)
							where FM_CLINK_ID=cl.FM_CLINK_ID
							group by FM_CLINK_ID
						) p2 on p1.FM_CLINK_ID=p2.FM_CLINK_ID
							and IsNull(p1.PATIENTS_COUNT_MAX,0)=IsNull(p2.PATIENTS_COUNT_MIN, 0)
					  ), 0)+IsNull(p.INCREASE,0))*IsNull(NullIf(p.COEF, 0), 1)
					-- Страхователь указан
					else
						-- подтверждена ли для него рассчитанная стоимость?
						case 
							when not exists(
								select 1
								from FM_CLINK_FM_ORG (nolock) where FM_CLINK_ID=cl.FM_CLINK_ID and FM_ORG_ID=p.FM_ORG_INSURER
							)	
								then NULL
							else
						  -- (Базовая стоимость для Страхователя + Надбавка)*Коэф-т  
						  (IsNull((select min(PRICE) from FM_CLINK_FM_ORG with (nolock) where FM_CLINK_ID=cl.FM_CLINK_ID and FM_ORG_ID=p.FM_ORG_INSURER), 0)
							+IsNull(p.INCREASE,0))*IsNull(NullIf(p.COEF, 0), 1)
						end
				end
		end
	from FM_CLINK_PATIENTS p with (nolock)
	inner join FM_CLINK cl with (nolock) on p.FM_CLINK_ID=cl.FM_CLINK_ID
	inner join FM_CONTR ct with (nolock) on ct.FM_CONTR_ID=cl.FM_CONTR_ID
	where p.FM_CLINK_PATIENTS_ID=@FM_CLINK_PATIENTS_ID
	  and ct.PAYMENT_TYPE='P'
	  -- НЕ созданы талоны
	  and (@CHECK_BILLDET_PAY=0 or
	   not exists(
		select * from FM_BILLDET_PAY with (nolock)
		where FM_CLINK_PATIENTS_ID=p.FM_CLINK_PATIENTS_ID)  
	 )
	return @Result
end
go

