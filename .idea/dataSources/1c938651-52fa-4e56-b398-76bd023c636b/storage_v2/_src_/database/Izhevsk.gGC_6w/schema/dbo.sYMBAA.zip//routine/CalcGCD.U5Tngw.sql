create function [dbo].[CalcGCD] (@a numeric(20,6), @b numeric(20,6))
returns numeric(20,6)
as
begin

/* Функция нахождения НОД 2-х чисел типа numeric(20,6) */

  set @a = abs(@a)
  set @b = abs(@b)

  declare @fact_a int
  declare @fact_b int

  set @fact_a = 0
  set @fact_b = 0

  declare @tmp numeric(20,6)
  set @tmp = @a
  while (@tmp - round(@tmp, 0)) <> 0
  begin
    set @tmp = @tmp * 10
    set @fact_a = @fact_a + 1
  end

  set @tmp = @b
  while (@tmp - round(@tmp, 0)) <> 0
  begin
    set @tmp = @tmp * 10
    set @fact_b = @fact_b + 1
  end

  if @fact_b > @fact_a set @fact_a = @fact_b
  set @fact_b = @fact_a
  while @fact_b > 0
  begin
    set @a = @a * 10
    set @b = @b * 10
    set @fact_b = @fact_b - 1
  end

  while @a <> @b
  begin
    if @a > @b set @a = @a - @b;
    else set @b = @b - @a;
  end

  if @a <> 1.0
    while @fact_a > 0
    begin
      set @a = @a / 10
      set @fact_a = @fact_a - 1
    end
  return @a
end
go

