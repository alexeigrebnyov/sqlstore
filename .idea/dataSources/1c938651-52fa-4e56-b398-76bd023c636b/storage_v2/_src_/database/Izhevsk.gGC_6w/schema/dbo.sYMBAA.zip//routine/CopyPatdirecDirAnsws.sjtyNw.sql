

CREATE PROCEDURE dbo.CopyPatdirecDirAnsws(@SourcePatdirId INT, @TargetPatdirId INT, @CopyCanceled INT = 1) AS
/*declARE @SourcePatdirId INT, @TargetPatdirId INT
select @SourcePatdirId=2717987, @TargetPatdirId=2718284*/
BEGIN 
  DECLARE
    @DirAnswId INT,
    @DirAnswCount INT,
    @SourceDays INT,
    @ShiftInDays INT,
    @SourceStartDate DATETIME,
    @TargetStartDate DATETIME,
    @PlaneDate DATETIME,
    @TargetPlaneDate DATETIME,
    @Note VARCHAR,
    @KeepIntakeTime BIT,
    @ShiftInMinutes INT,
    @DrugDose FLOAT,
    @INTAKE_SPEED FLOAT,
    @INTAKE_DURATION INT,
    @IS_REANIMATION BIT,
	@ANSW_STATE INT,
    @REANIMATION_DAY_START DATETIME,
    @FROM_DATE_TIME DATETIME,
    @TO_DATE_TIME DATETIME,
	@PR_TEMPLATE_SCHEMES_ID INT;

  -- получаем количество DIR_ANSW в @SourcePatdir
  SELECT @DirAnswCount = count(DIR_ANSW_ID)
  FROM DIR_ANSW
  WHERE PATDIREC_ID = @SourcePatdirId
  if @DirAnswCount = 0
    RETURN

  -- получаем для @SourcePatdir дату начала и продолжительность в днях
  SELECT @SourceDays = DATEDIFF(d, BEGIN_DATE_TIME, END_DATE_TIME),
         @SourceStartDate = BEGIN_DATE_TIME,
         @KeepIntakeTime = IsNull(KEEP_INTAKE_TIME, 0),
         @FROM_DATE_TIME = BEGIN_DATE_TIME,
         @TO_DATE_TIME = dateadd(d, 5000, BEGIN_DATE_TIME)
  FROM PATDIREC
  WHERE PATDIREC_ID = @SourcePatdirId

  -- получаем дату начала @TargetPatdir
  SELECT @TargetStartDate = BEGIN_DATE_TIME, @IS_REANIMATION = IsNull(REANIM, 0), @REANIMATION_DAY_START = IsNull(REANIM_DAY_START, BEGIN_DATE_TIME),
		 @PR_TEMPLATE_SCHEMES_ID = PR_TEMPLATE_SCHEMES_ID
  FROM PATDIREC
  WHERE PATDIREC_ID = @TargetPatdirId

  SET @ShiftInDays = DATEDIFF(d, @SourceStartDate, @TargetStartDate)
  SET @ShiftInMinutes = DATEDIFF(mi, @SourceStartDate, @TargetStartDate)

  IF (@IS_REANIMATION = 1)
  BEGIN
    SET @ShiftInDays = DATEDIFF(d, @FROM_DATE_TIME, @REANIMATION_DAY_START)
    IF datepart(hh, @FROM_DATE_TIME) < datepart(hh, @REANIMATION_DAY_START)
      SET @ShiftInDays = @ShiftInDays + 1
    SET @FROM_DATE_TIME = dateadd(d, -@ShiftInDays, @REANIMATION_DAY_START)
    SET @TO_DATE_TIME = dateadd(ss, -1, dateadd(d, 1, @FROM_DATE_TIME))
  END

  -- курсор DIR_ANSW исходного назначения
  DECLARE DA CURSOR SCROLL FOR
    SELECT PLANE_DATE, NOTE, DRUG_DOSE, INTAKE_SPEED, INTAKE_DURATION, ANSW_STATE
    FROM DIR_ANSW
    WHERE PATDIREC_ID = @SourcePatdirId
		       AND PLANE_DATE BETWEEN @FROM_DATE_TIME AND @TO_DATE_TIME
		       AND (
				((@IS_REANIMATION = 0 OR ANSW_STATE <> 2) and @PR_TEMPLATE_SCHEMES_ID is null) or   -- for reanimation dont copy cancel dir_answ
				 (ANSW_STATE <> 2 and @PR_TEMPLATE_SCHEMES_ID is not null)							-- for template
				   )
  OPEN DA

  -- курсор объявлен и открыт, начинаем копирование DirAnsw в назначение-копию
  FETCH FIRST FROM DA INTO @PlaneDate, @Note, @DrugDose, @INTAKE_SPEED, @INTAKE_DURATION, @ANSW_STATE
  WHILE @@FETCH_STATUS = 0
  BEGIN
    IF (@IS_REANIMATION = 1)
    BEGIN
      SET @TargetPlaneDate = DATEADD(d, @ShiftInDays, @PlaneDate)
    END
    ELSE
    IF @KeepIntakeTime = 0
    BEGIN
      SET @TargetPlaneDate = DATEADD(mi, @ShiftInMinutes, @PlaneDate)
    END
    ELSE
    BEGIN
      SET @TargetPlaneDate = DATEADD(d, @ShiftInDays, @PlaneDate)
      IF @TargetPlaneDate < @TargetStartDate
      BEGIN
        SET @TargetPlaneDate = DATEADD(d, @SourceDays + 1, @TargetPlaneDate)
      END
    END

    IF (@CopyCanceled = 1) OR (@CopyCanceled = 0 AND @ANSW_STATE <> 2) 
	BEGIN
		EXEC up_get_id 'DIR_ANSW', 1, @DirAnswId OUTPUT
		INSERT DIR_ANSW (DIR_ANSW_ID, PATDIREC_ID, ANSW_STATE, PLANE_DATE, NOTE, DRUG_DOSE, INTAKE_SPEED, INTAKE_DURATION)
		VALUES (@DirAnswId, @TargetPatdirId, 0, @TargetPlaneDate, @Note, @DrugDose, @INTAKE_SPEED, @INTAKE_DURATION)
	END
    FETCH NEXT FROM DA INTO @PlaneDate, @Note, @DrugDose, @INTAKE_SPEED, @INTAKE_DURATION, @ANSW_STATE
  END

  -- освобождаем ресурсы
  CLOSE DA
  DEALLOCATE DA

END
go

