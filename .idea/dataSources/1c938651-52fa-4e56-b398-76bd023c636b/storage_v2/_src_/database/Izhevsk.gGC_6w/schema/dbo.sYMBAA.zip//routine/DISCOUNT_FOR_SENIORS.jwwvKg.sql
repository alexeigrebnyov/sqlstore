-- =============================================
-- Author:		РИФНУР ВАХИТОВ
-- Create date: 11.07.2018
-- Description:	На направления отправляемые в каонтагенты добавляется внешняя организация если выставлен код забора биоматериала.
-- =============================================
CREATE PROCEDURE  [dbo].[DISCOUNT_FOR_SENIORS]
AS
BEGIN
	SET NOCOUNT ON;
 
declare
@PATIENTS_ID int

declare DISCOUNT cursor LOCAL FORWARD_ONLY for

Select  PATIENTS_ID from PATIENTS where MEDECINS_ID not in (529,530 )
and ((POL=0 and DATEDIFF(year,ne_le,getdate())>=65) or (POL=1 and DATEDIFF(year,ne_le,getdate())>=60)) and CKIDKA_PENSIONERAM=0

open   DISCOUNT

fetch NEXT from   DISCOUNT
into @PATIENTS_ID

while @@FETCH_STATUS = 0

begin

 declare
 @V int,
 @N int ,
 @ID_ int

begin
set @V=(select COUNT(PATIENTS_DISCOUNT.PATIENTS_ID) from PATIENTS_DISCOUNT 
WHERE  PATIENTS_DISCOUNT.PATIENTS_ID=@PATIENTS_ID group by PATIENTS_DISCOUNT.PATIENTS_ID )
if @V=0 or @V is null
SET @N=1
else
SET @N=@V+1

exec up_get_id 'PATIENTS_DISCOUNT', 1, @ID_ output

insert into PATIENTS_DISCOUNT
      ([PATIENTS_DISCOUNT_ID]
      ,[PATIENTS_ID]
      ,[MODIFY_DATE_TIME]
      ,[N_LINE]
      ,[FM_DISCOUNT_ID]
      ,[MEDECINS_ID])
values
(@ID_,
 @PATIENTS_ID,
 GETDATE(),
 @N,
 164,
399 
)

UPDATE PATIENTS
set CKIDKA_PENSIONERAM=1
WHERE PATIENTS_ID=@PATIENTS_ID
end  

fetch NEXT from DISCOUNT
into @PATIENTS_ID
end
close DISCOUNT
DEALLOCATE DISCOUNT
END
go

