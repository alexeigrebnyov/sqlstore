-- =============================================
-- Author:		РИФНУР ВАХИТОВ
-- Create date: 26.08.2021
-- Description:	Удаляем скидки добавленные за протоколы
-- =============================================
CREATE PROCEDURE  [dbo].[DISCOUNT_IKO_PROTOCOL]
AS
BEGIN
	SET NOCOUNT ON;
 
declare
@PATIENTS_DISCOUNT_ID int

declare SKIDKA cursor LOCAL FORWARD_ONLY for

select PATIENTS_DISCOUNT_ID from PATIENTS_DISCOUNT where FM_DISCOUNT_ID in (171,172,173,174,175,176,177,178,179,180,181,182,183,184,185)

open   SKIDKA

fetch NEXT from   SKIDKA
into @PATIENTS_DISCOUNT_ID

while @@FETCH_STATUS = 0

begin

delete PATIENTS_DISCOUNT
where PATIENTS_DISCOUNT_ID=@PATIENTS_DISCOUNT_ID

fetch NEXT from SKIDKA
into @PATIENTS_DISCOUNT_ID
end
close SKIDKA
DEALLOCATE SKIDKA



END
go

