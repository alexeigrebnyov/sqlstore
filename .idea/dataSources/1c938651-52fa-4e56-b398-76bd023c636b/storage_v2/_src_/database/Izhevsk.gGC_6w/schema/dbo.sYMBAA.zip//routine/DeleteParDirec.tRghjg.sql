create procedure dbo.DeleteParDirec @Requests varchar(max), @Tasks varchar(max), @RequestsHandler int, @TaskHandler int
as
declare @Test int
select @Test = 0
/*declare @Requests varchar(max), @Tasks varchar(max), @RequestsHandler int, @TaskHandler int
select
	@Test=		1,
	@Requests=	'5636635',
	@Tasks=		'5636637',
	@RequestsHandler=1,
	@TaskHandler=1
*/

if object_id('tempdb..#Requests') is not null
	drop table #Requests
select Data as PATDIREC_ID
into #Requests
from dbo.Split(@Requests, ',')
--select * from #Requests

if object_id('tempdb..#Tasks') is not null
	drop table #Tasks
select Data as PATDIREC_ID
into #Tasks
from dbo.Split(@Tasks, ',')
--select * from #Tasks

declare @St varchar(800)
declare @ErrorMessage nvarchar(4000)
declare @ErrorSeverity int
declare @ErrorState int

-- Проверить что среди выделенных заданий нет заданий совмещенных с требованиями
select @St=''
select @St=@St+'Удаление задания '+t.PATDIREC_ID+' невозможно по скольку оно совмещено с требованием'+char(13)
from #Tasks t
inner join dbo.PATDIREC p with (nolock) on p.PATDIREC_id=convert(int, t.PATDIREC_ID)
where p.IS_REQUEST=1 and p.IS_TASK=1
if @St<>'' and @RequestsHandler=0 begin
	select @st=substring(@St, 1, len(@St)-1)
	raiserror(@st, 16, 10)  
	return
end else if @St<>'' and @RequestsHandler=1 begin
	-- Убрать задания совмещенные с требованиями
	delete t
	from #Tasks t
	inner join dbo.PATDIREC p on p.PATDIREC_id=convert(int, t.PATDIREC_ID)
	where p.IS_REQUEST=1 and p.IS_TASK=1
end

-- Тест данные ДО
if @Test=1
	select p.* 
	from dbo.PATDIREC p
	inner join (
		select s2.PATDIREC_ID TASK_ID
		from dbo.dir_serv s 
		inner join dbo.dir_serv s2 on s.DIR_SERV_TASK_ID=s2.DIR_SERV_ID
		inner join #Requests r on s.PATDIREC_id=r.PATDIREC_ID
		--where s.PATDIREC_id=5636612
		group by s2.PATDIREC_ID
	) p2 on p.PATDIREC_ID=p2.TASK_ID
	where p.IS_TASK=1


if object_id('tempdb..#PROCESSING') is not null
	drop table #PROCESSING
select * 
into #PROCESSING
from (
	select TASK.PATDIREC_ID, CAST(case when ISNULL(TASK.BIO_CODE, '') <> '' then 1
		else ISNULL((select 1
			from DIR_ANSW DA_TASK (nolock)
			where TASK.PATDIREC_ID = DA_TASK.PATDIREC_ID
				and not (DA_TASK.MOTCONSU_RESP_ID is null and DA_TASK.FM_BILL_ID is null)
			group by DA_TASK.PATDIREC_ID), 0)
		end as BIT) PROCESSING
	from PATDIREC TASK (nolock)
	inner join #Tasks t on TASK.PATDIREC_ID=convert(int, t.PATDIREC_ID)
) a
where a.PROCESSING=1 

select @St=''
select @St=@St+'Удаление задания не возможно. Задание '+convert(varchar(200), PATDIREC_ID)+' в работе'+char(13)
from #PROCESSING
if @St<>'' and @TaskHandler=0 begin
	select @st=substring(@St, 1, len(@St)-1)
	raiserror(@st, 16, 10)  
	return
end else if @St<>'' and @TaskHandler=1 begin
	-- Убрать задания 
	delete t
	from #Tasks t
	inner join #PROCESSING p on p.PATDIREC_ID=convert(int, t.PATDIREC_ID)
end

-- Выделенные на удаление задания связанны с не выделенными требованиями
select @St=''
select @St=@St+'Удаление задания '+p2.TASK_ID+' невозможно. На него смотрит направление '+convert(varchar(200),p.PATDIREC_ID)+char(13)
from dbo.PATDIREC p
inner join (
	-- Связанные Требования по Заданию
	select s2.PATDIREC_ID REQUEST_ID, t.PATDIREC_ID TASK_ID
	from dbo.dir_serv s (nolock)
	inner join dbo.dir_serv s2 (nolock) on s2.DIR_SERV_TASK_ID=s.DIR_SERV_ID
	inner join #Tasks t on s.PATDIREC_id=convert(int, t.PATDIREC_ID)
	group by s2.PATDIREC_ID, t.PATDIREC_ID
) p2 on p.PATDIREC_ID=p2.REQUEST_ID
  and p.IS_REQUEST=1
left join #Requests r on p.PATDIREC_id=convert(int, r.PATDIREC_ID)
where
	r.PATDIREC_ID is null
if @St<>'' and @TaskHandler=0 begin
	select @st=substring(@St, 1, len(@St)-1)
	raiserror(@st, 16, 10)  
	return
end 

set XACT_ABORT ON	
-- Все ошибки, которые возникнут в триггерах будут обработаны и переведены
-- xact_abort отменит транзакцию
begin tran

create table #UnLinkTask (
	REQUEST_ID	int,
	TASK_ID		int
)

if @St<>'' and @TaskHandler=1 begin
	-- Отвязать задания
	select p.PATDIREC_ID REQUEST_ID, p2.TASK_ID
	-- Лишние (не выделенные) задания
	into #ExcessTask
	from dbo.PATDIREC p
	inner join (
		-- Связанные Требования по Заданию
		select s2.PATDIREC_ID REQUEST_ID, t.PATDIREC_ID TASK_ID
		from dbo.dir_serv s 
		inner join dbo.dir_serv s2 on s2.DIR_SERV_TASK_ID=s.DIR_SERV_ID
		inner join #Tasks t on s.PATDIREC_id=convert(int, t.PATDIREC_ID)
		group by s2.PATDIREC_ID, t.PATDIREC_ID
	) p2 on p.PATDIREC_ID=p2.REQUEST_ID
	  and p.IS_REQUEST=1
	left join #Requests r on p.PATDIREC_id=convert(int, r.PATDIREC_ID)
	where
		r.PATDIREC_ID is null
	-----------------------------
	insert #UnLinkTask
	select s2.PATDIREC_ID REQUEST_ID, t.PATDIREC_ID TASK_ID
	from dbo.dir_serv s 
	inner join dbo.dir_serv s2 on s2.DIR_SERV_TASK_ID=s.DIR_SERV_ID
	inner join #Tasks t on s.PATDIREC_id=convert(int, t.PATDIREC_ID)
	-- Отвязываем от всех - решение Спольникова П.
	--where s2.PATDIREC_ID not in (select REQUEST_ID from #ExcessTask)
	group by s2.PATDIREC_ID, t.PATDIREC_ID	
	-----------------------------
	select s.DIR_SERV_ID, s.PATDIREC_ID REQUEST_ID
	into #delete_dir_serv
	from dbo.dir_serv s 
	--inner join #UnLinkTask t on s.PATDIREC_ID=t.REQUEST_ID
	group by s.DIR_SERV_ID, s.PATDIREC_ID
	-----------------------------
	-- Не удаляем dir_serv требования, а отвязываем
	update s set s.DIR_SERV_TASK_ID=null
	--select s.DIR_SERV_ID, s.DIR_SERV_TASK_ID, s2.PATDIREC_ID
	from #delete_dir_serv d
	inner join dbo.dir_serv s on d.DIR_SERV_ID=s.DIR_SERV_ID
	inner join dbo.dir_serv s2 on s.DIR_SERV_TASK_ID=s2.DIR_SERV_ID
	inner join #Tasks t on s2.PATDIREC_id=convert(int, t.PATDIREC_ID)	
end

-- Удаление dir_serv
select s.DIR_SERV_ID DIR_SERV_ID1, s.PATDIREC_ID PATDIREC_ID1, 
	s2.DIR_SERV_ID DIR_SERV_ID2, s2.PATDIREC_ID PATDIREC_ID2
into #delete_dir_serv2
from dbo.dir_serv s 
inner join #Tasks t on s.PATDIREC_ID=convert(int, t.PATDIREC_ID)
inner join DIR_SERV s2 on s2.DIR_SERV_TASK_ID = s.DIR_SERV_ID

-- Не удаляем dir_serv требования, а отвязываем
update ds set ds.DIR_SERV_TASK_ID=null
--select ds.*
from #delete_dir_serv2 d
inner join dbo.dir_serv ds on d.DIR_SERV_ID2=ds.DIR_SERV_ID
inner join #Requests r on ds.PATDIREC_ID=convert(int, r.PATDIREC_ID)
-----------------------------
delete ds
--select ds.*
from #delete_dir_serv2 d
inner join dbo.dir_serv ds on d.DIR_SERV_ID1=ds.DIR_SERV_ID
inner join #Tasks t on ds.PATDIREC_id=convert(int, t.PATDIREC_ID)
-- Исключим задания которые привязаны к другим требованиям
--left join #UnLinkTask u on ds.PATDIREC_id=u.TASK_ID
--where u.REQUEST_ID is null

-- Удаление заданий
delete p
from #Tasks t
inner join dbo.PATDIREC p on p.PATDIREC_id=convert(int, t.PATDIREC_ID)
-- Исключим задания которые привязаны к другим требованиям
--left join #UnLinkTask u on p.PATDIREC_id=u.TASK_ID
where p.IS_TASK=1
--and u.REQUEST_ID is null

-- Тест данные ПОСЛЕ
if @Test=1
	select p.* 
	from dbo.PATDIREC p
	inner join (
		select s2.PATDIREC_ID TASK_ID
		from dbo.dir_serv s 
		inner join dbo.dir_serv s2 on s.DIR_SERV_TASK_ID=s2.DIR_SERV_ID
		inner join #Requests r on s.PATDIREC_id=r.PATDIREC_ID
		--where s.PATDIREC_id=5636612
		group by s2.PATDIREC_ID
	) p2 on p.PATDIREC_ID=p2.TASK_ID
	where p.IS_TASK=1

commit
go

