CREATE PROCEDURE [dbo].[GISTOLOGIYA_CHZ]
AS
DECLARE 
	@Patients_ID int,
	@data_zap_ datetime,
	@FM_INTORG_ID int,
	@PL_SUBJ_ID int
	
set @data_zap_= dbo.date(dateadd(DAY,10,GETDATE()))
  
DECLARE KURSOR CURSOR LOCAL
FOR
/***************************************************/
SELECT distinct
 PATIENTS.PATIENTS_ID,PATDIREC.FM_INTORG_ID
from PATDIREC inner JOIN PATIENTS
on PATDIREC.PATIENTS_ID=PATIENTS.PATIENTS_ID
INNER JOIN PL_EXAM ON PATDIREC.PL_EXAM_ID=PL_EXAM.PL_EXAM_ID
where dbo.Date(PATDIREC.DATE_BIO)=dbo.Date(GETDATE()) and PATDIREC.PL_EXAM_ID in (7540,7575,11882,11720)-- and PATDIREC.FM_INTORG_ID in (20,21) --and PATIENTS.PATIENTS_ID=5662
 
OPEN KURSOR

FETCH NEXT FROM KURSOR
into @PATIENTS_ID,@FM_INTORG_ID

WHILE @@FETCH_STATUS = 0  
        
begin

-----------------------------------делаем запись в расписание-----------------------------------
set @PL_SUBJ_ID= (case when @FM_INTORG_ID=53 then 463 when @FM_INTORG_ID=56 then 464 when @FM_INTORG_ID=20 then 15  when @FM_INTORG_ID=42 then 115 when @FM_INTORG_ID=43 then 168 end) 

exec dbo.pNNPlus_planning @data_zap_,@PL_SUBJ_ID,8344,@PATIENTS_ID,NULL,399,19


/****************************************************************************************/
FETCH NEXT FROM KURSOR
INTO  @PATIENTS_ID,@FM_INTORG_ID
end

CLOSE KURSOR
DEALLOCATE KURSOR
/****************/
go

