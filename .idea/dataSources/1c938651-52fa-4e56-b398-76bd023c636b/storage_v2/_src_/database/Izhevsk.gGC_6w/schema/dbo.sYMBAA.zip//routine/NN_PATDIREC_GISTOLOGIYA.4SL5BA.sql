-- =============================================
-- Author:		РИФНУР ВАХИТОВ
-- Create date: 23.04.2020
-- Description:	Создание
-- =============================================
CREATE PROCEDURE  [dbo].[NN_PATDIREC_GISTOLOGIYA](@PATIENTS_ID int,@CURRENT_MEDECIN int,@CURRENT_DEP int,@MOTCONSU_ID int,@filial1 int,@PL_EXAM_ID int )
AS
BEGIN
	SET NOCOUNT ON;

	

DECLARE  @serv_id_ int
DECLARE  @KOL_VO_ int
DECLARE  @EXAM_CODE_ VARCHAR(150)
DECLARE  @EXAM_ID_ INT
--DECLARE  @PATIENTS_ID INT
declare @PREPARAT_ int
declare @POLE_ID_FB int
declare @CLINK_ID_ INT
DECLARE @CLINK_PROG_ID_ INT
declare @render int
declare @ID_ZAPISI int
declare @oplata_ int
declare @POLE_ID_P int
declare @POLE_ID_D int
declare @FM_CLINK_PATIENTS_ID_ int
declare @POLE_ID int
declare @SOBYT_ID int
declare @user_ int
                                 
----------------------------------------------------------------КОНСТАНТЫ-----------------------------------------------------------------

SET @POLE_ID=@MOTCONSU_ID
set @serv_id_=17406 /*гистология*/
--SET @SOBYT_ID=@CURRENT_MOTCONSU_EV
set @user_=@CURRENT_MEDECIN
--------------------------------------------------поиск медпрограмм и прикреплений--------------------------------------------

if (SELECT DISTINCT top 1 FM_CLINK_PATIENTS.PATIENTS_ID FROM
 FM_CLINK_PATIENTS left JOIN FM_CLINK ON  FM_CLINK_PATIENTS.FM_CLINK_ID=FM_CLINK.FM_CLINK_ID 
left JOIN FM_CLINK_PROG ON FM_CLINK_PROG.FM_CLINK_ID=FM_CLINK.FM_CLINK_ID
  LEFT JOIN FM_PROG_serv ON FM_CLINK_PROG.FM_PROG_ID=FM_PROG_serv.FM_PROG_ID OR FM_CLINK.FM_CLINK_ID=FM_PROG_serv.FM_CLINK_ID
  WHERE FM_CLINK_PATIENTS.PATIENTS_ID=@PATIENTS_ID and CONVERT (date,FM_CLINK_PATIENTS.DATE_FROM)<=CONVERT (date,GETDATE()) 
  AND CONVERT (date,FM_CLINK_PATIENTS.DATE_TO)>=CONVERT (date,GETDATE()) and
  FM_PROG_serv.CANCEL=0 --and FM_CLINK_PROG.CANCEL_AN=0
   and FM_PROG_serv.FM_SERV_ID=@serv_id_) is null 

begin RAISERROR('Нет действующих медпрограмм для оплаты услуг',16,1) end 
else 
if (SELECT COUNT(PL_EXAM_ID) FROM PATDIREC where PATDIREC.MOTCONSU_ID=@MOTCONSU_ID and PL_EXAM_ID=@PL_EXAM_ID)=0
Begin

SELECT DISTINCT top 1 @FM_CLINK_PATIENTS_ID_=FM_CLINK_PATIENTS.FM_CLINK_PATIENTS_ID,@CLINK_ID_=FM_CLINK_PATIENTS.FM_CLINK_ID FROM
 FM_CLINK_PATIENTS left JOIN FM_CLINK ON  FM_CLINK_PATIENTS.FM_CLINK_ID=FM_CLINK.FM_CLINK_ID 
left JOIN FM_CLINK_PROG ON FM_CLINK_PROG.FM_CLINK_ID=FM_CLINK.FM_CLINK_ID
  LEFT JOIN FM_PROG_serv ON FM_CLINK_PROG.FM_PROG_ID=FM_PROG_serv.FM_PROG_ID OR FM_CLINK.FM_CLINK_ID=FM_PROG_serv.FM_CLINK_ID
  WHERE FM_CLINK_PATIENTS.PATIENTS_ID=@PATIENTS_ID and CONVERT (date,FM_CLINK_PATIENTS.DATE_FROM)<=CONVERT (date,GETDATE()) 
  AND CONVERT (date,FM_CLINK_PATIENTS.DATE_TO)>=CONVERT (date,GETDATE()) and
  FM_PROG_serv.CANCEL=0 --and FM_CLINK_PROG.CANCEL_AN=0 
  and FM_PROG_serv.FM_SERV_ID=@serv_id_

SET @CLINK_PROG_ID_=(SELECT TOP 1
 FM_CLINK_PROG.FM_CLINK_PROG_ID
FROM
FM_CLINK_PROG FM_CLINK_PROG  LEFT OUTER JOIN FM_PROG FM_PROG ON (FM_CLINK_PROG.FM_PROG_ID= FM_PROG.FM_PROG_ID)
 JOIN FM_PROG_SERV FM_PROG_SERV ON FM_PROG.FM_PROG_ID = FM_PROG_SERV.FM_PROG_ID 
 JOIN FM_SERV FM_SERV ON FM_SERV.FM_SERV_ID = FM_PROG_SERV.FM_SERV_ID 
WHERE
 (FM_CLINK_PROG.FM_CLINK_ID=@CLINK_ID_ and FM_SERV.FM_SERV_ID=@serv_id_))

if @CLINK_ID_=0 or @FM_CLINK_PATIENTS_ID_=0 or @CLINK_PROG_ID_=0 begin set @oplata_=0 end
else begin set @oplata_=1 end
--------------------------------------------------------СОЗДАЕМ НАПРАВЛЕНИЕ------------------------------------------------------------

exec up_get_nn_id  'PATDIREC', 1, @POLE_ID_P output
insert into PATDIREC
(PATDIREC_ID,
DESCRIPTION,
DIR_STATE,
PATIENTS_ID,
MEDECINS_CREATOR_ID,
MOTCONSU_ID,
PL_EXAM_ID,
QUANTITY,
BIO_TYPE,
CITO,
FM_INTORG_ID,
STANDARTED,
CREATE_DATE_TIME,
CANCELLED,
BEGIN_DATE_TIME,
KRN_CREATE_USER_ID,
MANIPULATIVE,
KEEP_INTAKE_TIME,
PATDIREC_KIND,
NEED_OPEN_EDITOR,
QUANTITY_DONE)
values( @POLE_ID_P,
'Морфологическое исследование препарата тканей  ( гистология).',
1,
@PATIENTS_ID,
@user_,
@POLE_ID,
@PL_EXAM_ID,
1,
'',
0,
@filial1,--:%AF_CURRENT_FILIAL,
0,
GETDATE(),
0,
GETDATE(),
@user_,
0,
0,
0,
0,
0)

--------------------------------------------------------СОЗДАЕМ ЗАПИСЬ В DIR_SERV-------------------------------------------------------------
exec up_get_nn_id  'DIR_SERV', 1, @POLE_ID_D output
insert into DIR_SERV
(DIR_SERV_ID,
PATDIREC_ID,
PATIENTS_ID,
FM_SERV_ID,
CNT,
PAYER,
FM_CLINK_PATIENTS_ID,
FREE_PAY)
values(
@POLE_ID_D,
@POLE_ID_P,
@PATIENTS_ID,
@serv_id_,
1,
'M',
@FM_CLINK_PATIENTS_ID_,
0
)

-----------------------------------------------------СОЗДАЕМ ТАЛОН--------------------------------------------------------------------------------------
declare @POLE_ID_F int
exec up_get_nn_id  'FM_BILL', 1, @POLE_ID_F output

insert into FM_BILL
(FM_BILL_ID,
BILL_DATE,
PATIENTS_ID,
MOTCONSU_ID,
MOTCONSU_DIR_ID,
MOTCONSU_MAIN_ID,
MOTCONSU_EV_ID,
MEDECINS_CREATE_ID,
MEDECINS_MODIFY_ID,
DATE_MODIFY,
DATE_CREATE,
FM_ORG_ID,
INSURANCE_TYPE,
IS_PREPAID,
BILL_TYPE,
ESTIMATE_CHILD,
ERR_SAVED,
BILL_NUM
)
values(@POLE_ID_F,
CONVERT (date,GETDATE()),
@PATIENTS_ID,
@POLE_ID,
@POLE_ID,
@POLE_ID,
NULL,--@SOBYT_ID,
@user_,
@user_,
dateadd(hh,8,dbo.date(GETDATE())),
dateadd(hh,8,dbo.date(GETDATE())),
@filial1,--:%AF_CURRENT_FILIAL,
'D',
0,
5,
0,
1,
@POLE_ID_F)

--------------------------------------------------ДЕЛАЕМ ЗАПИСЬ В ТАБЛИЦЕ FM_BILLDET--------------------------------------------------------------------------
declare @PRICE int
SET @PRICE=(case when @filial1=20 then dbo.fcServCashPriceFilial(@serv_id_,1,1,GETDATE() )
          when @filial1=43 then dbo.fcServCashPriceFilial(@serv_id_,1,3, GETDATE() )
          when @filial1=42 then dbo.fcServCashPriceFilial(@serv_id_,1,2, GETDATE() )
          when @filial1=53 or @filial1=56  then dbo.fcServCashPriceFilial(@serv_id_,1,4, GETDATE() )		  end)
SET @CLINK_PROG_ID_=(SELECT TOP 1
 FM_CLINK_PROG.FM_CLINK_PROG_ID
FROM
FM_CLINK_PROG FM_CLINK_PROG  LEFT OUTER JOIN FM_PROG FM_PROG ON (FM_CLINK_PROG.FM_PROG_ID= FM_PROG.FM_PROG_ID)
 JOIN FM_PROG_SERV FM_PROG_SERV ON FM_PROG.FM_PROG_ID = FM_PROG_SERV.FM_PROG_ID 
 JOIN FM_SERV FM_SERV ON FM_SERV.FM_SERV_ID = FM_PROG_SERV.FM_SERV_ID 
WHERE
 (FM_CLINK_PROG.FM_CLINK_ID=@CLINK_ID_ and FM_SERV.FM_SERV_ID=@serv_id_))

exec up_get_nn_id  'FM_BILLDET', 1, @POLE_ID_FB output
insert into FM_BILLDET
(FM_BILLDET_ID,
FM_BILL_ID,
FM_PRICETYPE_ID,
CNT,
PRICE,
TOTAL_PRICE,
PRICE_TO_PAY,
FM_ORG_ID,
FM_CLINK_ID,
FM_SERV_ID,
FM_DEVISE_ID,
FM_CLINK_PROG_ID,
MEDECINS_ID,
MEDECINS_MODIFY_ID,
DATE_MODIFY,   
FM_ORG1_ID,
BLOCKED,
DISCOUNT,
PRICE_FORCED,
FM_CLINK_PATIENTS_ID,
RENDERED,
FORCE_RENDERED,
DIR_SERV_ID,
DATE_CREATE,
DISCOUNT_AMOUNT,
CANCEL,
DONE,
FORCE_DONE,
AUTOSERV,
FM_PRICETYPE_PAT_ID,
ORG1_PERC,
FREE_PAY,
FM_PRICE_CATEGORY_ID,
PROVIDED,
CLINK_NULL_SERV,
BY_ARRANGE,
IS_MAIN_SERV,
AUTO_CANCELLED,
MAIN_BILLDET_ID)
values(
@POLE_ID_FB,
@POLE_ID_F,
1,
1,
@PRICE,--dbo.fcServCashPrice(@serv_id_,1,null),
@PRICE,--dbo.fcServCashPrice(@serv_id_,1,null),
@PRICE,--dbo.fcServCashPrice(@serv_id_,1,null),
@filial1,--:%AF_CURRENT_FILIAL,
@CLINK_ID_,
@serv_id_,
2,
@CLINK_PROG_ID_,
@user_,
@user_,
dateadd(hh,8,dbo.date(GETDATE())),
@filial1,--:%AF_CURRENT_FILIAL,
0,
0,
0,
@FM_CLINK_PATIENTS_ID_,
@oplata_,
0,
@POLE_ID_D,
dateadd(hh,8,dbo.date(GETDATE())),
0,
0,
0,
0,
1,
1,
100,
0,
1,
0,
0,
0,
0,
0,
0)

--------------------------------------------------------------------------------Создаем запись в таблице FM_BILLDET_PAY-------------------------------------------------------------------
declare @POLE_ID_FBP int
exec up_get_nn_id  'FM_BILLDET_PAY', 1, @POLE_ID_FBP output

insert into FM_BILLDET_PAY
(FM_BILLDET_PAY_ID,
PATIENTS_ID,
FM_BILLDET_ID,
PERC,
INVOICE_AMOUNT,
NDS,
PRICE,
FM_ORG_ID,
PRICE_FORCED,
DISCOUNT_AMOUNT,
PRICE_DISCOUNT,
CANCEL,
FM_CLINK_ID,
FM_CLINK_PATIENTS_ID,
IS_STORNO,
FM_DEVISE_ID,
FM_BILLDET_DONE_ID)
values(@POLE_ID_FBP,
NULL,
@POLE_ID_FB,
100,
@PRICE,--dbo.fcServCashPrice(@serv_id_,1,null),
0,
@PRICE,--dbo.fcServCashPrice(@serv_id_,1,null),
@filial1,--:%AF_CURRENT_FILIAL,
0,
0,
0,
0,
@CLINK_ID_,
@FM_CLINK_PATIENTS_ID_, 
0,
1,
@POLE_ID_FB)

-------------------------------------------------------DIR_ANSW--------------------------------------------------------------
declare @POLE_ID_DA int
exec up_get_nn_id  'DIR_ANSW', 1, @POLE_ID_DA output

insert DIR_ANSW
([DIR_ANSW_ID]
      ,[PATDIREC_ID]
      ,[FM_BILL_ID]
      ,[ANSW_STATE]
      ,[CANCEL_PAY]
)
values (@POLE_ID_DA,
 @POLE_ID_P,
 @POLE_ID_F,
 0,
 0
)
UPDATE MOTCONSU
set SKRIPT_GISTOLOGIYA=1
where MOTCONSU_ID=@MOTCONSU_ID

--declare
--  @Value integer,
--  @Template varchar(50)

--exec dbo.up_get_counter_value  @KeyName = 'Kontragent_vse',  @Shift = 1,
--   @Value = @Value output, @Template = @Template output

--declare @LAB_CONTS int
--exec up_get_id  @KeyName = 'LAB_CONTS', @Shift = 1, @ID = @LAB_CONTS output

--insert into LAB_CONTS
--(LAB_CONTS_ID,PATIENTS_ID,CODE,BIO_DATE,STATE,DATE_EXP,MEDECINS_BIO_ID,MEDECINS_BIO_DEP_ID,KRN_CREATE_USER_ID,PATDIR_STATE,KRN_MODIFY_USER_ID,KRN_MODIFY_DATE,KRN_CREATE_DATE)
--values(@LAB_CONTS,@PATIENTS_ID,@Value,GETDATE(),0,GETDATE(),@CURRENT_MEDECIN,@CURRENT_DEP,@CURRENT_MEDECIN,'B',@CURRENT_MEDECIN,GETDATE(),GETDATE())

--declare @LAB_PATDIRECCONTS int
--exec up_get_id  @KeyName = 'LAB_PATDIRECCONTS', @Shift = 1, @ID = @LAB_PATDIRECCONTS output

--insert into LAB_PATDIRECCONTS
--(LAB_PATDIRECCONTS_ID,LAB_CONTS_ID,PATDIREC_ID,KRN_CREATE_USER_ID,KRN_MODIFY_USER_ID,KRN_MODIFY_DATE,KRN_CREATE_DATE)
--values(@LAB_PATDIRECCONTS,@LAB_CONTS,@POLE_ID_P,@CURRENT_MEDECIN,@CURRENT_MEDECIN,GETDATE(),GETDATE())

--update PATDIREC set 
--BIO_CODE=@Value
--,DATE_BIO=GETDATE()
--,MEDECINS_BIO_ID=@CURRENT_MEDECIN
--,MEDECINS_BIO_DEP_ID=@CURRENT_DEP
--,STATE='B',
--KRN_MODIFY_DATE = convert(varchar(30),GetDate(),20),
--KRN_MODIFY_USER_ID = @CURRENT_MEDECIN
--where PATDIREC_ID=@POLE_ID_P

end
END
go

