-- =============================================
-- Author:		РИФНУР ВАХИТОВ
-- Create date: 17/04/2020
-- Description:	Запись в расписание репродуктологам
-- =============================================
CREATE PROCEDURE  [dbo].[PLANNING_REPR](@PATIENTS_ID int,@CURRENT_MEDECIN int,@CURRENT_DEP int,@CURRENT_MOTCONSU_EV int,@filial1 int)
AS
BEGIN
	SET NOCOUNT ON;

/*репродуктологам*/
declare 
@MEDECINS_ID3 int,
@PL_SUBJ_ID int, 
@PL_PARAM_ID int,
@foms int
SELECT @foms=CONVERT(int,DATA_PMT_ART_CYCLE.FOMS) FROM DATA_PMT_ART_CYCLE where motconsu_ID=@CURRENT_MOTCONSU_EV
/*Пациенты по ФОМС */
if   @foms=1
begin
/*Находим лечащего врача*/
	SELECT top 1 @MEDECINS_ID3= DATA_PMT_ART_CYCLE.LECHASCHIY_VRACH FROM DATA_PMT_ART_CYCLE where motconsu_ID=@CURRENT_MOTCONSU_EV
/*Находим расписание врача по репродуктологам*/
	SELECT top 1  
	@PL_SUBJ_ID= PL_SUBJ_PARAM.PL_SUBJ_ID, 
	@PL_PARAM_ID=PL_SUBJ_PARAM.PL_PARAM_ID
	FROM PL_SUBJ INNER JOIN PL_SUBJ_PARAM ON PL_SUBJ.PL_SUBJ_ID=PL_SUBJ_PARAM.PL_SUBJ_ID
	where MEDECINS_ID= @MEDECINS_ID3  and 
	(case when @filial1=53 or @filial1=56 then 108 when  @filial1=20 then 4 when  @filial1=42 then 34 when  @filial1=43 then 61 end) in(PL_SUBJ_PARAM.PL_PARAM_ID)
	/**/
	declare 
	@a int = 1, /*Записываем пациентов на завтра или позже когда у врача будет рабочий день*/
	@priem datetime,
	@priem1 datetime,
	@nemo int =0
	set @priem1=[dbo].[nnf_DAY_PRIEMA](@PL_SUBJ_ID,@PL_PARAM_ID,@a)--SELECT [dbo].[nnf_DAY_PRIEMA](282,108,2)
		if @priem1 is not null begin set @priem=@priem1 end else
		while @priem1 is null and @a<60--@nemo =0 --([dbo].[nnf_DAY_PRIEMA](@PL_SUBJ_ID,@PL_PARAM_ID,@a)) is null
			begin
			set @a=@a+1
			set @priem1=[dbo].[nnf_DAY_PRIEMA](@PL_SUBJ_ID,@PL_PARAM_ID,@a)
			set @priem=@priem1 /*Нашли рабочий день врача*/
			end		
				if @priem is not null 
				begin
				declare @filial int
				,@data_zap_ datetime
				, @subj_ int
				, @exam_ int
				, @patient_ int
				, @comment_ varchar(254)
				, @medecins_ int
				, @dep_ int
				, @time1 int
				, @time2 int
				, @time int
				set @data_zap_=@priem
				set @subj_=@PL_SUBJ_ID
				set @exam_=8166--11978
				set @patient_=@PATIENTS_ID--400974--:%AF_CURRENT_PATIENT
				set @comment_=NULL --@COMMENT
				set @medecins_= @CURRENT_MEDECIN--472--=:%AF_CURRENT_MEDECIN
				set @dep_=@CURRENT_DEP --171--=:%AF_CURRENT_DEP
				set @time1=730--@end1
				set @time2=2200
				set @time=null
				exec  dbo.pNNPlus_planning_no_error_730 @data_zap_ , @subj_ , @exam_, @patient_ , @comment_ ,@medecins_ , @dep_
				end
				
end
END
go

