CREATE proc [dbo].[SendMessage] (

-- exec dbo.SendMessage 0, 1235, '', 0, 0, 0, 1235, '', 'Test subject', 'Test body', 0, '2012-12-31', NULL, NULL, 0

	@SenderType int,               -- тип отправителя 0..3 ver 75072
	@Sender int,                   -- отправитель для типов 0,1; может быть NULL (письмо от пациента)
	@SenderAddress varchar(100),   -- строковый адрес отправителя для типов 2,3, или ''
	@Category int,			       -- категория (0=обычное, 1=По пациенту)
	@ResourceId int,		       -- (если Category=1, то ID пациента, для Category=0 этот параметр игнорируется) 
	@ReceiverType int,             -- тип получателя 0..3
	@Receiver int,			       -- Получатель (ID либо из таблицы врачей, либо из таблицы постов); может быть NULL (письмо пациенту)
    @ReceiverAddress varchar(100), -- строковый адрес получателя для типов 2,3, или ''
	@Subject varchar(100),         -- Тема сообщения
	@Body varchar(2047),	       -- Текст сообщения
	@Priority int,			       -- Важность (0=Обычная, 1=Повышенная)
	@DeadDateTime DateTime,	       -- Дата, до которой существует сообщение.
	@Source int,			       -- Ид предыдущего сообщения в цепочке сообщений ("ответ на")
	@Root int,				       -- Ид корневого сообщения в цепочке сообщений 
	@ModerationRequired bit        -- Требуется модерация
)
as

declare @CreateDateTime DateTime;
set @CreateDateTime = GetDate();

-- Message
declare @MessageId integer;
execute up_get_id 'MSG_MESSAGES', 1, @MessageId output;

-- Сообщения от внешних источников не контролируются автором, условно помечаются удаленными автором.
-- Уничтожатся по пометкам получателей.
declare @DeletedBySender bit;
if @SenderType = 0
	set @DeletedBySender = 0;
else
	set @DeletedBySender = 1;

insert into [MSG_MESSAGES] (
	[MSG_MESSAGES_ID],
	[SENDER_ID],
	[CREATE_DATE_TIME],
	[DEAD_DATE_TIME],
	[PRIORITY],
	[CATEGORY],
	[RESOURCE_ID],
	[SUBJECT],
	[BODY],
	[BODY_PLAIN],
	[SOURCE],
	[ROOT],
	[SENDER_TYPE],
	[SENDER_ADDRESS],
	[DELETED]
	)
values (
	@MessageId,
	@Sender,
	@CreateDateTime,
	@DeadDateTime,
	@Priority,
	@Category,
	@ResourceId,
	@Subject,
	@Body,
	@Body,
	@Source,
	@Root,
	@SenderType,
	@SenderAddress,
	@DeletedBySender
	);

-- Receiving

if @Receiver IS NULL return;

declare @ReceivingId int;
execute up_get_id 'MSG_RECEIVING', 1, @ReceivingId output;

insert into [MSG_RECEIVING] (
	[MSG_RECEIVING_ID],
	[MESSAGES_ID],
	[DELETED],
	[READED],
	[SAVED],
	[USER_ID],
	[USER_TYPE],
	[USER_ADDERSS],
	[EXTERNAL_SEND_STATUS],
	[MODERATION_REQUIRED]
	)
values (
	@ReceivingId,
	@MessageId,
	0,	-- Deleted
	0,	-- Readed
	0,	-- Saved
	@Receiver,	--Receiver,
	@ReceiverType,  -- User_type 
	@ReceiverAddress,  -- User_address
	0,	-- not sent
	@ModerationRequired
	);


go

