CREATE PROCEDURE [dbo].[SendRPL_message] 

	@Sender int,           	       -- отправитель
	@Category int,			       -- категория (0=обычное, 1=По пациенту)
	@ResourceId int,		       -- (если Category=1, то ID пациента, для Category=0 этот параметр игнорируется) 
	@Receiver int,			       -- Получатель 
	@Subject varchar(100),         -- Тема сообщения
	@Body varchar(2047),	       -- Текст сообщения
	@Priority int,			       -- Важность (0=Обычная, 1=Повышенная)
	@DeadDateTime DateTime         -- Дата, до которой существует сообщение.
AS
BEGIN

DECLARE
	@SenderType int,               -- тип отправителя 0..3
	@SenderAddress varchar(100),   -- строковый адрес отправителя для типов 2,3, или ''
	@ReceiverType int,             -- тип получателя 0..3
    @ReceiverAddress varchar(100), -- строковый адрес получателя для типов 2,3, или ''
	@Source int,			       -- Ид предыдущего сообщения в цепочке сообщений ("ответ на")
	@Root int,				       -- Ид корневого сообщения в цепочке сообщений 
    @ModerationRequired bit        -- Требуется модерация

SET @SenderType = 0
SET @SenderAddress = ''
SET @ReceiverType = 0
SET @ReceiverAddress = ''
SET @Source = NULL
SET @Root = NULL
SET @ModerationRequired = 0

EXECUTE [dbo].[SendMessage] 
	@SenderType,
	@Sender,
	@SenderAddress,
	@Category,
	@ResourceId,
	@ReceiverType,
	@Receiver,
    @ReceiverAddress,
	@Subject,
	@Body,
	@Priority,
	@DeadDateTime,
	@Source,
	@Root,
    @ModerationRequired

END

go

