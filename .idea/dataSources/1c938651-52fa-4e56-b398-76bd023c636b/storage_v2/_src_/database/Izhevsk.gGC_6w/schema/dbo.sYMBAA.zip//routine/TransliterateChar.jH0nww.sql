CREATE FUNCTION [dbo].[TransliterateChar](@Ch varchar(1)) 
RETURNS varchar(10) 
AS 
BEGIN 
	/* транслитерация один символ */ 
	DECLARE @Result varchar(10) 
 
	SET @Result = 
		CASE @Ch 
		    WHEN 'а' THEN 'a' 
		    WHEN 'б' THEN 'b' 
		    WHEN 'в' THEN 'v' 
		    WHEN 'г' THEN 'g' 
		    WHEN 'д' THEN 'd' 
		    WHEN 'е' THEN 'e' 
		    WHEN 'ё' THEN 'e' 
		    WHEN 'ж' THEN 'zh' 
		    WHEN 'з' THEN 'z' 
		    WHEN 'и' THEN 'i' 
		    WHEN 'й' THEN 'y' 
		    WHEN 'к' THEN 'k' 
		    WHEN 'л' THEN 'l' 
		    WHEN 'м' THEN 'm' 
		    WHEN 'н' THEN 'n' 
		    WHEN 'о' THEN 'o' 
		    WHEN 'п' THEN 'p' 
		    WHEN 'р' THEN 'r' 
		    WHEN 'с' THEN 's' 
		    WHEN 'т' THEN 't' 
		    WHEN 'у' THEN 'u' 
		    WHEN 'ф' THEN 'f' 
		    WHEN 'х' THEN 'h' 
		    WHEN 'ц' THEN 'c' 
		    WHEN 'ч' THEN 'ch' 
		    WHEN 'ш' THEN 'sh' 
		    WHEN 'щ' THEN 'sch' 
		    WHEN 'ъ' THEN '_' 
		    WHEN 'ы' THEN 'y' 
		    WHEN 'ь' THEN '_' 
		    WHEN 'э' THEN 'e' 
		    WHEN 'ю' THEN 'yu' 
		    WHEN 'я' THEN 'ya' 
			ELSE @Ch 
   END 
 
  IF ASCII(@Ch) = ASCII(UPPER(@Ch))
    SET @Result = UPPER(@Result)
  RETURN @Result 
END
go

