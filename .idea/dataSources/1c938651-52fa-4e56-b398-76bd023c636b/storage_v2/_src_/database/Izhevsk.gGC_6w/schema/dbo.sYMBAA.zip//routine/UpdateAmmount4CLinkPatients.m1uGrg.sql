

create procedure dbo.UpdateAmmount4CLinkPatients @FM_CLINK_ID int
as
--declare @FM_CLINK_ID int = 6856
--select p.FM_CLINK_PATIENTS_ID,  cl.FM_CLINK_ID, p.FM_ORG_INSURER,
update p set 
	p.AMOUNT_PER_PAT=
  -- расчет по Страхователю
  case when ct.CALC_PRICE_INSURER=1 then
    -- Указан страхователь
    case when p.FM_ORG_INSURER is not null then
	  -- (Базовая стоимость для Страхователя + Надбавка)*Коэф-т  
	  (IsNull((select min(PRICE) from FM_CLINK_FM_ORG with (nolock) where FM_CLINK_ID=cl.FM_CLINK_ID and FM_ORG_ID=p.FM_ORG_INSURER), 0)
		+IsNull(p.INCREASE,0))*IsNull(NullIf(p.COEF, 0), 1)
	else
	  -- (Базовая стоимость для минимального количества прикрепленных + Надбавка)*Коэф-т    
	  (IsNull((select max(p1.PRICE)
		from FM_CLINK_PRICE p1 with (nolock)
		inner join (
			select FM_CLINK_ID, IsNull(min(PATIENTS_COUNT_MAX),0) PATIENTS_COUNT_MIN
			from FM_CLINK_PRICE with (nolock)
			where FM_CLINK_ID=cl.FM_CLINK_ID
			group by FM_CLINK_ID
		) p2 on p1.FM_CLINK_ID=p2.FM_CLINK_ID
			and IsNull(p1.PATIENTS_COUNT_MAX,0)=IsNull(p2.PATIENTS_COUNT_MIN, 0)
	  ), 0)+IsNull(p.INCREASE,0))*IsNull(NullIf(p.COEF, 0), 1)
	end
  else
    -- Стоимость прикрепления = (ISNULL( Стоимость МП, Стоимость Договора) + Надбавка) * Коэф-т
	(coalesce(cl.AMOUNT_PER_PAT, ct.CONTR_SUM, 0) + IsNull(p.INCREASE,0))*IsNull(NullIf(p.COEF, 0), 1)
  end
from FM_CLINK_PATIENTS p
inner join FM_CLINK cl with (nolock) on p.FM_CLINK_ID=cl.FM_CLINK_ID
inner join FM_CONTR ct with (nolock) on ct.FM_CONTR_ID=cl.FM_CONTR_ID
where ct.PAYMENT_TYPE='P'
  and p.MANUAL_PRICE=0
  and cl.FM_CLINK_ID = @FM_CLINK_ID
  and not exists(
		select * from FM_BILLDET_PAY with (nolock)
		where FM_CLINK_PATIENTS_ID=p.FM_CLINK_PATIENTS_ID)
go

