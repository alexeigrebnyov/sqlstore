-- =============================================
-- Author:		Рифнур Вахитов
-- Create date:03.12.2018
-- Description:	Возврат ао ЭКО из Исхода 
-- =============================================
CREATE PROCEDURE [dbo].[VOZVRAT_PROTOCOLI_2_OLD](@PACIENT_ID int, @MOTCONSU_ID INT, @MOTCONSU_ISHOD_ID INT)
AS
BEGIN
declare  @vozvrat_id int

/*начало ест перенос 3 цикла*/
declare  @OPLATE int,
 @OPLATE1 int
declare  @code_1_3ES int
declare  @cnt_1_3ES int
declare  @price_u_3ES int
declare  @price_1_3ES int
declare  @discount_1_3ES int
declare  @code_2_3ES int
declare  @price_2_3ES int
declare  @discount_2_3ES int 
declare  @price_2_3ES_1 int
/*конец ест перенос 3 цикла*/

/*начало МДФ 3*/
declare  @code_1_MDF3 int
declare  @cnt_1_MDF3 int
declare  @price_u_MDF3 int
declare  @price_1_MDF3 int
declare  @discount_1_MDF3 int
declare  @code_2_MDF3 int
declare  @price_2_MDF3 int
declare  @discount_2_MDF3 int 
declare  @price_2_MDF3_1 int
/*конец МДФ 3*/

/*начало криоперенос СРМ*/
declare  @code_1_KRIO_PL_SRM int
declare  @cnt_1_KRIO_PL_SRM int
declare  @price_u_KRIO_PL_SRM int
declare  @price_1_KRIO_PL_SRM int
declare  @discount_1_KRIO_PL_SRM int
declare  @code_2_KRIO_PL_SRM int
declare  @price_2_KRIO_PL_SRM int
declare  @discount_2_KRIO_PL_SRM int 
declare  @price_2_KRIO_IMB_RAB_SRM int
declare  @discount_2_KRIO_IMB_RAB_SRM  int
declare  @price_2_KRIO_PER_SRM int
declare  @discount_2_KRIO_PER_SRM int

/*конец криоперенос СРМ*/
declare @POLE_ID int
declare @code_1 int
declare @code_2 int
declare @cnt_3 int
declare  @cnt_3_H_I int
declare  @cnt_3_Z_S int
declare  @cnt_3_H_S int
declare @price_3 int
declare @price_u int
declare @price_u_H_I int
declare @price_u_Z_S int
declare @price_u_H_S int
declare @price_u_30 int
declare @price_u_SRM int
declare @price_u_VMI int
declare @cnt_1 int 
declare @cnt_2 int =0
declare @price_1 int 
declare @price_2 int =0
declare @discount_1 int
declare @discount_2 int
declare @pay_1  int
declare @pay_2  int
declare @code_2_30_11  int
declare @price_2_30_1  int
declare @discount_2_30_1  int
declare @code_2_35_11  int
declare @price_2_35_1  int
declare @discount_2_35_1  int
declare @code_2_36_11  int
declare @price_2_36_1  int
declare @discount_2_36_1  int
declare @code_2_41_11  int
declare @price_2_41_1  int
declare @discount_2_41_1  int

/**/
declare @code_1_D_S_V  int
declare @cnt_1_D_S_V  int
declare @price_u_D_S_V  int
declare @price_1_D_S_V  int
declare @discount_1_D_S_V  int
declare @code_2_D_S_V  int
declare @cnt_2_D_S_V  int=0
declare @cnt_3_D_S_V  int
declare @price_2_D_S_V  int =0
declare @price_3_D_S_V  int
declare @discount_2_D_S_V  int

/**/

/*начало мдф.ец часть 2 */
declare @code_2_MDF_2  int
declare @price_2_ms_embr_2  int
declare @price_2_es_embr_2  int
declare @price_2_puction_2  int
declare @price_2_perenos_2  int
/*конец мдф ец часть 2*/

/*начало ИКСИ*/
declare @code_1_ICSI  int
declare @cnt_1_ICSI  int
declare @price_u_ICSI  int
declare @price_1_ICSI  int
declare @discount_1_ICSI  int
declare @code_2_ICSI  int
declare @cnt_2_ICSI  int=0
declare @cnt_3_ICSI  int
declare @price_2_ICSI  int =0
declare @price_3_ICSI  int
declare @discount_2_ICSI  int
/*конец ИКСИ*/

/*начало Индив хранение зам сперм 1 мес*/
declare @code_2_H_I_6   int
declare @cnt_2_H_I_6   int
declare @cnt_3_H_I_6  int
declare @price_2_H_I_6  int
declare @price_3_H_I_6  int
declare @discount_2_H_I_6  int
/*конец Индив хранение зам сперм 1 мес*/

declare @code_2_MDF_1  int
declare @price_2_ms_stim_1  int
declare @price_2_es_stim_1  int
declare @price_u_MDF  int
declare @code_1_MDF  int
declare @code_2_MDF  int
declare  @cnt_1_MDF  int
declare  @price_1_MDF  int
declare  @discount_1_MDF  int
declare @price_2_es_stim  int
declare @discount_2_es_stim  int 
declare @price_2_es_plan  int
declare @price_2_ms_stim  int
declare @discount_2_ms_stim  int
declare @price_2_puction  int
declare @price_2_es_embr_rab  int
declare @price_2_perenos  int
declare @price_2_mc_embr_rab  int
 declare @price_2_embriosit  int
declare @code_2_MS int
declare @price_2_perenos_ms int
declare @code_2_MS2  int
declare @price_2_mc2_embr_rab  int
declare  @price_2_ms2  int

declare @code_1_30 int
declare @code_2_30 int
declare @cnt_1_30  int
declare @cnt_2_30  int
declare @code_2_30_1 int
declare @price_1_30 int
declare @price_2_30 int
declare @discount_1_30 int
declare @discount_2_30 int
declare @discount_2_30_st int
declare @discount_2_35_st int
declare @pay_1_30  int
declare @pay_2_30  int
declare @price_2_30_pl  int
declare @price_2_30_st  int
declare @price_2_30_PUN  int
declare @price_2_30_IMB  int
declare @price_2_30_ST6  int
declare @price_2_30_PER  int
declare  @price_2_35_st  int
declare @discount_2_36_40_st   int
declare @price_2_36_40_st  int
declare  @discount_2_41_st  int
declare  @price_2_41_st  int,
@price_OM int

/*начало ст протоколо часть2*/
declare  @code_2_30_2  int
declare  @price_2_30_PUN_2  int
declare  @discount_2_30_st_2  int
declare  @price_2_30_IMB_2  int
declare  @price_2_30_PER_2  int
/*конец ст протоколо часть2*/

/* ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * начало вычисляем цену услуг  Возврат по криоцит. отсроченный перенос
* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
declare  @code_2_KR_IM_R  int
declare  @price_2_KR_IM_R  int
declare   @discount_2_KR_IM_R  int
declare   @price_2_KR_IM_PL  int
declare   @price_2_KR_IM_RAZ_O  int
declare   @price_2_KR_IM_PER  int
declare  @price_2_O_P_IMB  int
declare  @discount_2_O_P_IMB  int
declare  @price_2_O_P_IMB_RAB  int
/* ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * Возврат по Хранению эмбрионов за 1 саломинку
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
declare @code_1_H_I int
declare @code_2_H_I int
declare @cnt_1_H_I  int
declare @cnt_2_H_I  int=0
declare @price_1_H_I int
declare @price_2_H_I int=0
declare @price_3_H_I int
declare @discount_1_H_I int
declare @discount_2_H_I int
declare @pay_1_H_I  int
declare @pay_2_H_I  int
/* ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * Начало Возврат по Замораживанию спермы за 1 месяц
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
declare @code_1_Z_S int
declare @code_2_Z_S int
declare @cnt_1_Z_S  int
declare @cnt_2_Z_S  int=0
declare @price_1_Z_S int
declare @price_2_Z_S int=0
declare  @price_3_Z_S int
declare @discount_1_Z_S int
declare @discount_2_Z_S int
declare @pay_1_Z_S  int
declare @pay_2_Z_S  int

/* начало замораживание +индивид хранение сперм 3 месяц*/
declare @code_1_H_S3 int
declare @cnt_1_H_S3 int
declare @price_u_H_S3 int
declare @price_u_H_S3_1 int
declare @price_1_H_S3 int
declare @discount_1_H_S3 int
declare @cnt_2_H_S3_1 int=0
declare @cnt_3_H_S3_1 int
declare @price_2_H_S3_1 int=0
declare @price_3_H_S3_1 int
declare @discount_2_H_S3_1 int
/* конец  замораживание +индивид хранение сперм 3 месяц*/
/* ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * Возврат по Хранению спермы
 * ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
declare @code_1_H_S int
declare @code_2_H_S int
declare @cnt_1_H_S  int
declare @cnt_2_H_S  int=0
declare @price_1_H_S int
declare @price_2_H_S int=0

declare @price_3_H_S int
declare @discount_1_H_S int
declare @discount_2_H_S int
declare @pay_1_H_S  int
declare @pay_2_H_S  int

/* ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * Возврат по ДЯ СРМ
 * -------------------------------------------------------------*/
declare @code_1_SRM int
declare @code_2_SRM int
declare @cnt_1_SRM varchar(100)
declare @cnt_2_SRM varchar(100)
declare @price_1_SRM int
declare @price_2_SRM int
declare @discount_1_SRM int
declare @discount_2_SRM int
declare @pay_1_SRM  int
declare @pay_2_SRM  int
declare @code_2_SRM_1 int
declare @price_2_IMBRIO_ZAM  int
/* -----------------озврат по ВМИ ------------------------------*/
declare @code_1_VMI int
declare @code_2_VMI int
declare @cnt_1_VMI varchar(100)
declare @cnt_2_VMI varchar(100)
declare @price_1_VMI int
declare @price_2_VMI int
declare @discount_1_VMI int
declare @discount_2_VMI int
declare @pay_1_VMI  int
declare @pay_2_VMI  int
declare @code_2_VMI_1 int
declare @price_2_VMI_u1 int
declare @price_2_VMI_u2 int
declare @price_2_VMI_EZ int
declare @discount_2_VMI_EZ int
declare @price_2_VMI_u3 int
declare @discount_2_VMI_u3 int
declare @discount_2_VMI_u2 int
declare @discount_2_VMI_u1 int
/*начало вми часть 1,2*/
declare  @code_2_VMI_2 int
declare  @price_2_VMI_i1  int
declare  @price_2_VMI_i2  int
/*конец вми часть 1,2*/

/* начало Возврат по БЛ25----------------------------------------------*/
declare @price_2_OPL_STIM_D  int
declare @price_2_OPL_OBS_D int
declare @price_2_OPL_PUN_D int
declare @price_2_IMB_RAB_D int
declare @price_2_IMBRIO_D int
declare @discount_2_OPL_STIM_DYA  int
declare @price_2_STIM_SRM  int
 declare @discount_2_STIM_SRM  int
declare  @price_2_PLAN_SRM  int
declare  @price_2_ST_6_SRM  int
declare  @price_2_ST_PR_SRM  int
declare  @price_2_OBSLED_SRM   int
declare  @price_2_OPL_STIM_D_1  int
declare  @price_2_OPL_STIM_D_2   int
/* ------------ конец Возврат по БЛ25------------------------------------------------------------------*/
/* --------------------------------начало Возврат по БЛ24------------------*/

declare  @code_1_KRIO_PL_KRIO   int
declare  @code_2_KRIO_PL_KRIO   int

declare   @cnt_1_KRIO_PL_KRIO   int
declare   @cnt_2_KRIO_PL_KRIO   int

declare   @price_u_KRIO_PL_KRIO   int
declare   @price_1_KRIO_PL_KRIO   int

declare  @discount_1_KRIO_PL_KRIO   int
declare  @discount_2_KRIO_PL_KRIO_IMB_RAB   int
declare  @discount_2_KRIO_PL_KRIO_DON_IMB   int

declare  @price_2_KRIO_PL_KRIO_IMB_RAB   int

declare  @price_2_KRIO_PL_KRIO_PL   int
declare  @price_2_KRIO_PL_KRIO_DON_IMB   int

declare  @price_2_KRIO_PL_KRIO_PER   int

declare   @code_2_KRIO_PL_KRIO_CH    int,
@PERENOS1 int,
@ZAMOROZKA1 int,
@MDF3P int,

/* --------------------------------начало Возврат по БЛТ 25------------------*/
 @code_2_BLT25 int,
 @price_BLT25_OPL int,
 @discount_BLT25 int,
 @price_BLT25_IMB int,
 @price_BLT25_IMBR_RAB int,
 @price_BLT25_ST11 int,
 @price_BLT25_ST12 int

/* -------------------конец Возврат по БЛТ-25 ---------------*/

/* --Начало Возврат по стандартным протоколам-----------*/

declare VOZVRAT_30 cursor LOCAL FORWARD_ONLY for

SELECT 
FM_SERV. FM_SERV_ID, 
 FM_BILLDET_1.CNT, 
FM_BILLDET_PAY_1.PRICE,
FM_BILLDET_1.PRICE_TO_PAY,
FM_BILLDET_1.DISCOUNT,
(FM_INVOICE.TOTAL_AMOUNT-   IsNull((select SUM(P.TRAN_AMOUNT) from FM_PAYMENTS P where P.FM_INVOICE_ID = FM_INVOICE.FM_INVOICE_ID and P.WODOLG = 0), 0)) as OPLATE
FROM
MOTCONSU MOTCONSU  JOIN FM_BILL FM_BILL ON (MOTCONSU.MOTCONSU_ID=FM_BILL.MOTCONSU_ID)
 JOIN FM_BILLDET FM_BILLDET ON (FM_BILL.FM_BILL_ID= FM_BILLDET.FM_BILL_ID)
 JOIN FM_BILLDET_PAY FM_BILLDET_PAY ON (FM_BILLDET.FM_BILLDET_ID =FM_BILLDET_PAY.FM_BILLDET_ID)
 JOIN FM_INVOICE FM_INVOICE ON (FM_BILLDET_PAY.FM_INVOICE_ID=FM_INVOICE.FM_INVOICE_ID)
 JOIN FM_BILLDET_PAY FM_BILLDET_PAY_1 ON FM_INVOICE.FM_INVOICE_ID = FM_BILLDET_PAY_1.FM_INVOICE_ID 
 JOIN FM_BILLDET FM_BILLDET_1 ON FM_BILLDET_1.FM_BILLDET_ID = FM_BILLDET_PAY_1.FM_BILLDET_ID 
 LEFT OUTER JOIN FM_SERV FM_SERV ON FM_SERV.FM_SERV_ID = FM_BILLDET_1.FM_SERV_ID 
 JOIN PATIENTS PATIENTS ON PATIENTS.PATIENTS_ID = MOTCONSU.PATIENTS_ID 
 LEFT OUTER JOIN MOTCONSU MOTCONSU_1 ON (MOTCONSU.MOTCONSU_ID= MOTCONSU_1.MOTCONSU_EV_ID)

where MOTCONSU_1.MOTCONSU_ID= @MOTCONSU_ISHOD_ID

open VOZVRAT_30
fetch NEXT from VOZVRAT_30
into
 @code_1_30,
 @cnt_1_30,
@price_u_30,
 @price_1_30,
@discount_1_30,
@OPLATE
while @@FETCH_STATUS = 0 
   begin
   set @OPLATE1=@OPLATE
      if @code_1_30= '17515'
           begin set @code_2_30_1=0
                      set   @price_2_30= @price_1_30
                      set  @discount_2_30=@discount_1_30
           end

      if @code_1_30='17561'               
           begin set @code_2_30_11=0
                      set   @price_2_30_1= @price_1_30
                      set  @discount_2_30_st=@discount_1_30
           end

  if @code_1_30='17562' 
           begin set @code_2_30_11=1
                      set   @price_2_35_1= @price_1_30
                      set  @discount_2_35_st=@discount_1_30
           end

  if  @code_1_30= '17517'
           begin set @code_2_30_1=1
                      set   @price_2_30= @price_1_30
                      set  @discount_2_30=@discount_1_30
           end
 if @code_1_30='17563' 
           begin set @code_2_30_11=2
                      set   @price_2_36_1= @price_1_30
                      set  @discount_2_36_40_st=@discount_1_30
           end

    if  @code_1_30= '17521'
           begin set @code_2_30_1=2
                      set   @price_2_30= @price_1_30
                      set  @discount_2_30=@discount_1_30
           end
 if @code_1_30='17564'  
           begin set @code_2_30_11=3
                      set   @price_2_41_1= @price_1_30
                      set  @discount_2_41_st=@discount_1_30
           end

   if  @code_1_30= '17522'
           begin set @code_2_30_1=3
                      set   @price_2_30= @price_1_30
                      set  @discount_2_30=@discount_1_30
           end
   if  @code_1_30= '17870'
           begin      set   @price_OM= @price_1_30
           end
/* -----------начало эко стандартный часть 2*/
 if @code_1_30= '17568'
           begin   set @code_2_30_2=0
                       set   @price_2_30_PUN_2= @price_1_30
                        set  @discount_2_30_st=@discount_1_30
           end
 if @code_1_30= '17616' or @code_1_30= '17657'
           begin    set  @price_2_30_IMB_2= @price_1_30
                       
           end
 if @code_1_30= '17619'
           begin    set  @price_2_30_PER_2= @price_1_30
            end
/*конец эко стандартный часть 2*/
  if @code_1_30='17598'  or @code_1_30='17655'
           begin set   @price_2_30_pl= @price_1_30
           end

 if @code_1_30= '17515'
           begin  set   @price_2_30_st= @price_1_30
                      set  @discount_2_30_st=@discount_1_30
           end
  if @code_1_30='17526'  
           begin set   @price_2_30_PUN= @price_1_30
           end
if @code_1_30='17528'  or @code_1_30='17656' or @code_1_30='17870'
           begin set   @price_2_30_IMB= @price_1_30
           end
if @code_1_30='17581'  
           begin set   @price_2_30_ST6= @price_1_30
           end
if @code_1_30='17583'  
           begin set   @price_2_30_PER= @price_1_30
           end
if @code_1_30='17517'  
           begin  set  @discount_2_35_st = @discount_1_30
                       set   @price_2_35_st= @price_1_30
           end
if @code_1_30='17521'  
           begin  set  @discount_2_36_40_st = @discount_1_30
                       set   @price_2_36_40_st= @price_1_30
           end
if @code_1_30='17522'  
           begin  set  @discount_2_41_st = @discount_1_30
                       set   @price_2_41_st= @price_1_30
           end
/* -------- конец вычисляем цену услуг  Возврат по стандартным протоколам -----------------------------------------*/
/* ------------------начало вычисляем цену услуг  Возврат по криоцит. отсроченный перенос---------------------------------------*/

 if  @code_1_30='17634' 
           begin    set @code_2_KR_IM_R=0
                         set   @price_2_O_P_IMB_RAB= @price_1_30
            end
 if  @code_1_30='17594'
           begin  set @code_2_KR_IM_R=1
           end 
 if   @code_1_30 ='17615'
           begin  set @code_2_KR_IM_R=2
                       set   @price_2_KR_IM_R= @price_1_30
           end
 if  @code_1_30='17594'   begin
                      set  @price_2_KR_IM_R= @price_1_30
                      set  @discount_2_KR_IM_R=@discount_1_30
           end
 --if    @code_1_30='17594'   begin
 --                     set  @price_2_KR_IM_R= @price_1_30
 --                     set  @discount_2_KR_IM_R=@discount_1_30
 --          end
  if @code_1_30='17600'  or @code_1_30='17659' 
           begin set   @price_2_KR_IM_PL= @price_1_30
           end
 if @code_1_30='17580'  
           begin set   @price_2_KR_IM_RAZ_O= @price_1_30
           end
 if @code_1_30='17602'  
           begin set   @price_2_KR_IM_PER= @price_1_30
           end
 if @code_1_30='17519'   begin
                       set   @price_2_O_P_IMB= @price_1_30
                      set  @discount_2_O_P_IMB=@discount_1_30
           end
/* -------------конец вычисляем цену услуг  Возврат по криоцит. отсроченный перенос-------------------------------------------*/
/* --------------------Начало Возврат по ДЯ/СРМ БЛ25----------------------------------*/
     if @code_1_30 in ('17547' ,  '17609' )    /*А26.25.005  Оплата за стимуляцию ДЯ 67000 */
           begin set @code_2_SRM_1=0
           end
      if @code_1_30='17547' /*А26.25.005  Оплата за стимуляцию ДЯ 67000 */
           begin set   @price_2_OPL_STIM_D= @code_1_30
                      set  @discount_2_OPL_STIM_DYA = @discount_1_30
           end
      if @code_1_30='17546'                     /*А26.25.001 Оплата за обследование ДЯ 1500*/
           begin    set   @price_2_OPL_OBS_D= @price_1_30
             end
   if @code_1_30='17609'     /*А26.25.005.001.01 Оплата за стимуляцию ДЯ  этап 1 22000*/
           begin 
                   set   @price_2_OPL_STIM_D_1= @price_1_30
                    set   @discount_2_OPL_STIM_DYA = @discount_1_30
             end
   if @code_1_30='17610'  /*А26.25.005.001.02 Оплата за стимуляцию ДЯ  этап 2 45000*/
           begin    set   @price_2_OPL_STIM_D_2= @price_1_30
             end
      if @code_1_30='17541'    /*А26.25.002 Оплата за пункцию ДЯ 35000*/
           begin    set   @price_2_OPL_PUN_D= @price_1_30
             end
     if @code_1_30='17542'   /*u01.12.003 У_Эмбриоработа в ДЯ 15000*/
           begin    set   @price_2_IMB_RAB_D= @price_1_30
             end
      if @code_1_30='17519'    /*u01.011.022  _Эмбриоцит 18000*/
           begin    set   @price_2_IMBRIO_D= @price_1_30
             end
if @code_1_30='17614'    /*u01.011.022.02  Заморозка эмбрионов*/
           begin    set   @price_2_IMBRIO_ZAM= @price_1_30
             end
/* ------------------Начало Возврат по "Эко для программы с суррогатной мамо1" БЛ25------------------------------*/
      if @code_1_30='17514'    /*u01.011.001 _стимуляция ДЯ / Реципиент  45000*/
           begin set @code_2_SRM_1=1
                      set   @price_2_STIM_SRM= @price_1_30
                      set  @discount_2_STIM_SRM=@discount_1_SRM
           end
     if @code_1_30='17598' or @code_1_30='17655'
           begin    set   @price_2_PLAN_SRM= @price_1_30
             end
     if @code_1_30='17581'
           begin    set   @price_2_ST_6_SRM= @price_1_30
             end
     if @code_1_30='17526'
           begin    set   @price_2_ST_PR_SRM= @price_1_30
             end
     if @code_1_30='17606'
           begin    set   @price_2_OBSLED_SRM= @price_1_30
             end
      
/* ----------------------Начало Возврат по Перенос криоэмбрионов СРМ-------------------------*/
  if @code_1_30='17635' /*u01.009.001.04 У_Cтарт 1 дня в крио СРМ архивная услуга*/ or @code_1_30='17659' /*u01.009.001.18 _Старт_предстарт КРИО*/
             begin   
                      set   @price_2_KRIO_PL_SRM= @price_1_30
                      set  @discount_2_KRIO_PL_SRM = @discount_1_30
             end
  if @code_1_30='17636' /**/
            
             begin 
			       set @code_2_KRIO_PL_SRM=0
			       set  @price_2_KRIO_IMB_RAB_SRM= @price_1_30
             end
if @code_1_30='17529' /**/
             begin 
			       set @code_2_KRIO_PL_SRM=1
			       set  @price_2_KRIO_IMB_RAB_SRM= @price_1_30
             end
  if @code_1_30='17637'  or @code_1_30='17602'
           begin    set   @price_2_KRIO_PER_SRM= @price_1_30
           end
/* ------------------------------конец Возврат по Перенос криоэмбрионов СРМ---------------------------------------*/
/* --------------------------Начало Возврат по Перенос криоэмбрионов. донорские эмбрионы---------------------------------*/
/* начало часть 2 */

  if @code_1_30='17570' 
           begin set @code_2_KRIO_PL_KRIO_CH=1
                      set   @price_2_KRIO_PL_KRIO_IMB_RAB=  @price_1_30
                      set  @discount_2_KRIO_PL_KRIO_IMB_RAB = @discount_1_30
                 end

   if @code_1_30='17571'
           begin 
                   set @code_2_KRIO_PL_KRIO_CH=2
                    set   @price_2_KRIO_PL_KRIO_DON_IMB= @price_1_30
                    set  @discount_2_KRIO_PL_KRIO_IMB_RAB = @discount_1_30
             end
  if @code_1_30='17603'
      
           begin    set @code_2_KRIO_PL_KRIO_CH=0
                           set   @price_2_KRIO_PL_KRIO_PL= @price_1_30
                           set  @discount_2_KRIO_PL_KRIO_IMB_RAB = @discount_1_30
             end

if @code_1_30='17621'
           begin    set   @price_2_KRIO_PL_KRIO_PER= @price_1_30
             end

/* конец часть 2 */

      if @code_1_30='17531' 
           begin set @code_2_KRIO_PL_KRIO=0
                      set   @price_2_KRIO_PL_KRIO_IMB_RAB=  @price_1_30
                      set  @discount_2_KRIO_PL_KRIO_IMB_RAB = @discount_1_30
                 end

      if @code_1_30='17600'  or @code_1_30='17659'
           begin    set   @price_2_KRIO_PL_KRIO_PL= @price_1_30
             end

   if @code_1_30='17529'
           begin 
                   set @code_2_KRIO_PL_KRIO=1
                    set   @price_2_KRIO_PL_KRIO_DON_IMB= @price_1_30
                    set   @discount_2_KRIO_PL_KRIO_DON_IMB = @discount_1_30
             end

   if @code_1_30='17602'
           begin    set   @price_2_KRIO_PL_KRIO_PER= @price_1_30
             end

/* ----------------------конец Возврат по Перенос криоэмбрионов. донорские эмбрионы-----------------------------*/
/* -----------------------------Начало Возврат по естествен. вми естест. стимуляция БЛ23--------------------------------------------*/
/* начало ВМИ часть 1*/

  if @code_1_30='17567'  
           begin set @code_2_VMI_2=0
                      set   @price_2_VMI_i1= @price_1_30
                      set  @discount_2_VMI_u1=@discount_1_30
           end
  if @code_1_30='17613'  
           begin set @code_2_VMI_2=1
                      set   @price_2_VMI_i2= @price_1_30
                      set  @discount_2_VMI_u1=@discount_1_30
           end
/* конец ВМИ часть 1*/
      if @code_1_30='17484'  
           begin set @code_2_VMI_1=0
                      set   @price_2_VMI_u1= @price_1_30
                      set  @discount_2_VMI_u1=@discount_1_30
           end

      if @code_1_30='17502' 
           begin set @code_2_VMI_1=1
                      set   @price_2_VMI_EZ= @price_1_30
                      set  @discount_2_VMI_EZ=@discount_1_30
           end
 if @code_1_30='17539'
           begin set @code_2_VMI_1=2
                      set   @price_2_VMI= @price_1_30
                      set  @discount_2_VMI=@discount_1_30
           end
    if @code_1_30='17540' 
          begin  set   @price_2_VMI_u2= @price_1_30
                      set  @discount_2_VMI_u2=@discount_1_30
           end
 if @code_1_30='17598'  or @code_1_30='17655' 
          begin  set   @price_2_VMI_u3= @price_1_30
                      set  @discount_2_VMI_u3=@discount_1_30
           end

/* -------------------------Начало Возврат по БЛ - 22---------------------------------*/
/* начало бл-22 часть 2*/

   if @code_1_30='17617'
           begin 
                   set @code_2_MDF_2=0
                    set   @price_2_es_embr_2= @price_1_30
                    set   @discount_2_es_stim = @discount_1_30
             end
 if @code_1_30='17618'
  begin 
                   set @code_2_MDF_2=1
                    set   @price_2_ms_embr_2= @price_1_30
                    set   @discount_2_ms_stim = @discount_1_30
             end
 if @code_1_30='17569'
           begin    set   @price_2_puction_2= @price_1_30
             end
if @code_1_30='17620'
           begin    set   @price_2_perenos_2= @price_1_30
             end
/*конец бл-22 часть 2*/
      if @code_1_30='17523'  or @code_1_30='17872'
           begin
                      set   @price_2_es_stim=  @price_1_30
                      set  @discount_2_es_stim = @discount_1_30
                 end

      if @code_1_30='17599' or @code_1_30='17658'
           begin    set   @price_2_es_plan= @price_1_30
             end

   if @code_1_30='17516'
           begin 
                   -- set @code_2_MDF=1
                    set   @price_2_ms_stim= @price_1_30
                    set   @discount_2_ms_stim = @discount_1_30
             end
   if @code_1_30='17525'
           begin    set   @price_2_puction= @price_1_30
             end
   if @code_1_30='17530'
           begin  
                   set @code_2_MDF=0
                  set   @price_2_es_embr_rab= @price_1_30
             end
if @code_1_30='17601'
           begin    set   @price_2_perenos= @price_1_30
             end
if @code_1_30='17793'
           begin    set   @price_2_perenos_ms= @price_1_30
             end
if @code_1_30='17524'
           begin  
             set @code_2_MS=0    /*для BL_22_VID_PROTOKOLA_MS*/
             set   @price_2_mc_embr_rab= @price_1_30
             end
if @code_1_30='17519'
           begin    set   @price_2_embriosit= @price_1_30
             end
/*начало мягкая стимуляция 2 попытки*/

if @code_1_30='17790'  /*У_Эмбриоработа МС 2 попытки*/
           begin  
             set @code_2_MS2=0    /*для BL_22_VID_PROTOKOLA_MS2*/
             set   @price_2_mc2_embr_rab= @price_1_30
             end

if @code_1_30='17791'
           begin    set   @price_2_ms2= @price_1_30
             end


/*конец мягкая стимуляция 2 попытки*/

/*возврат часть 1*/
  if @code_1_30='17566'
           begin 
                   set @code_2_MDF_1=1
                    set   @price_2_ms_stim_1= @price_1_30
                    set   @discount_2_ms_stim = @discount_1_30
             end

  if @code_1_30='17565'
           begin 
                   set @code_2_MDF_1=0
                    set    @price_2_es_stim_1= @price_1_30
                    set   @discount_2_es_stim = @discount_1_30
             end

/* ----------------------конец Возврат по  БЛ - 22--------------------------------------*/
/* -----------------Начало Возврат по МДФ 3 попытки-------------------------------------*/
  if @code_1_30='17669' 
      
             begin    set @code_2_MDF3=0
                      set   @price_2_MDF3= @price_1_30
                      set  @discount_2_MDF3 = @discount_1_30
             end

  if @code_1_30='17670' 
             begin
                      set  @price_2_MDF3_1= @price_1_30
             end
/* ----------------конец Возврат по МДФ3 попытки--------------------------------------------*/
/* -------------------Начало Возврат по ЕС 3 цикла-----------------------------------------*/
  if @code_1_30='17761' 
      
             begin    set @code_2_3ES=0
                      set   @price_2_3ES= @price_1_30
                      set  @discount_2_3ES = @discount_1_30
             end
/* ----------конец Возврат по EC 3 цикла -----------------------*/

/* -------------------Начало Возврат по БЛТ 25-----------------------------------------*/
  if @code_1_30='17575'
             begin    set @code_2_BLT25=0
             set   @price_BLT25_OPL= @price_1_30
             set  @discount_BLT25 = @discount_1_30
             end
if  @code_1_30='17568'
             begin    --set @code_2_BLT25=0
             set   @price_BLT25_OPL= @price_1_30
             set  @discount_BLT25 = @discount_1_30
             end
if @code_1_30='17519' or @code_1_30='17614'
             begin
             set   @price_BLT25_IMB= @price_1_30
             end
if @code_1_30='17574' 
                begin
                set   @price_BLT25_IMBR_RAB= @price_1_30
                end

/*Начало ДЯ часть 1 */
if @code_1_30='17611'
             begin    set @code_2_BLT25=2
             set   @price_BLT25_ST11= @price_1_30
             set  @discount_BLT25 = @discount_1_30
             end
if  @code_1_30='17612'
             begin   
			 set   @price_BLT25_ST12= @price_1_30
             
             end
/*Конец ДЯ часть 1 */

/* ----------конец Возврат по БЛТ 25 -----------------------*/




if (SELECT COUNT(DATA_W693_VOZVRAT_DENEG_ID) from DATA_W693_VOZVRAT_DENEG where MOTCONSU_ID=@MOTCONSU_ID)=0
begin
exec up_get_id 'DATA_W693_VOZVRAT_DENEG', 1, @vozvrat_id output

SELECT @PERENOS1=PERENOS,@ZAMOROZKA1=ZAMOROZKA   
FROM DATA_CYCLE_RESULT where motconsu_ID=@MOTCONSU_ISHOD_ID


INSERT INTO DATA_W693_VOZVRAT_DENEG
(DATA_W693_VOZVRAT_DENEG_ID,
PATIENTS_ID,
DATE_CONSULTATION,
MOTCONSU_ID,
ISHOD_PERENOS,
ISHOD_ZAMOROZKA
)
values (@vozvrat_id,
@PACIENT_ID,
GETDATE(),
@MOTCONSU_ID,
@PERENOS1,
@ZAMOROZKA1
)
 end

begin
update DATA_W693_VOZVRAT_DENEG
set  
/* ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 *Начало Возврат по БЛ36
* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
ITOGO_K_OPLATE=@OPLATE1,
BL36_OTSROCH_KRIO_SKIDKA=@discount_2_O_P_IMB,
BL36_OTSROCH_KRIO_CENA_IT=(COALESCE(@price_2_KR_IM_RAZ_O,0)+COALESCE(@price_2_O_P_IMB_RAB,0)+COALESCE(@price_2_O_P_IMB,0)),
BL36_KRIOCIT_SKIDKA=@discount_2_KR_IM_R,
BL36_KRIOCIT_CENA_ITOGO=(COALESCE(@price_2_KR_IM_PL,0)+COALESCE(@price_2_KR_IM_RAZ_O,0)+COALESCE(@price_2_KR_IM_R,0)+COALESCE(@price_2_KR_IM_PER,0)),
BL36_OTSROCH_RAZMOROZKA=@price_2_KR_IM_RAZ_O,
BL36_OTSROCH_EMBR_RAB=@price_2_O_P_IMB_RAB,
BL36_OTSROCH_EMBRIOCIT=@price_2_O_P_IMB,
BL36_KRIOCIT_PLANIROV=@price_2_KR_IM_PL,
BL36_KRIOCIT_EMBR_RAB=@price_2_KR_IM_R,
BL36_KRIOCIT_PERENOS=@price_2_KR_IM_PER,
BL36_VID_PROTOKOLA=@code_2_KR_IM_R,
BL36_KRIOCIT_F_SKIDKA=@discount_2_KR_IM_R,
BL36_KRIOCIT_F_CENA_ITOGO=(COALESCE(@price_2_KR_IM_RAZ_O,0)+COALESCE(@price_2_KR_IM_R,0)+COALESCE(@price_2_KR_IM_PER,0)),
/* ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 *Конец Возврат по БЛ36
* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
ZAMOR_EMBR_1_SOL_1_CENA= @price_3,
HRAN_ZAM_EMBR_1_CENA=@price_3_H_I,
ZAMOR_SPER_1_CENA=@price_3_Z_S,
HRAN_SPERMY_1_CENA= @price_3_H_S,
ZAMOR_EMBR_ZA_1_SOLOMINKU=@cnt_2,
HRAN_ZAM_EMBR_1_MES_KOL_=@cnt_2_H_I,
ZAMOR_SPERMY_KOL_=@cnt_2_Z_S,
HRAN_SPERMY_1_KOL=@cnt_2_H_S,
--ZAMORAZHIVANIE_CENA= @price_2,
--ZAMORAZHIVANIE_SKIDKA=@discount_2,
VID_PROTOKOLA = coalesce(
(CASE WHEN @code_2_30_1 IS NOT NULL AND @price_OM IS NULL THEN @code_2_30_1 
END),NULL), /*@code_2_30_1*/
BL_54_PROTOKOL = coalesce(
(CASE WHEN @code_2_30_1 IS NOT NULL AND @price_OM IS NOT NULL THEN @code_2_30_1 
END),NULL),
BL25_VID_PROTOKOLA=@code_2_SRM_1,
HRANENIE_ZAMOROZHENNYH_E1=@discount_2_H_I,
HRANENIE_ZAMOROZHENNYH_E2=@price_2_H_I,
ZAMORAZHIVANIE_SPERMY_SKI=@discount_2_Z_S,
ZAMORAZHIVANIE_SPERMY_CEN=@price_2_Z_S,
HRANENIE_SPERMY_ZA_1_MES1=@discount_2_H_S,
HRANENIE_SPERMY_ZA_1_MES2= @price_2_H_S,
BL23_VID_PROTOKOLA=@code_2_VMI_1,
BL23_VMI_SKIDKA=@discount_2_VMI_u1,
BL23_VMI_ITOGO=(COALESCE(@price_2_VMI_u1,0)+COALESCE(@price_2_VMI_u2,0)),
BL23_VID_PROT_ETAPY= @code_2_VMI_2, 
BL23_ETAP1=@price_2_VMI_i1,
BL23_ETAP2=@price_2_VMI_i2,

BL23_EST_ZACHATIE_ITOGO=@price_2_VMI_EZ,
BL23_EST_ZACHATIE_SKIDKA=@discount_2_VMI_EZ,
BL23_EST_ZACHATIE_GAN_SKI=@discount_2_VMI_u3,
BL23_EST_ZACHATIE_GAN_ITO=(COALESCE(@price_2_VMI_u3,0)+COALESCE(@price_2_VMI,0)),
ST_EKO_30_SKIDKA= @discount_2_30_st,
ST_EKO_30_ITOGO=(COALESCE(@price_2_30_pl,0)+COALESCE(@price_2_30_st,0)+COALESCE(@price_2_30_PUN,0)+COALESCE(@price_2_30_IMB,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_PER,0)),
ST_EKO_30_PLAN_ITOGO=@price_2_30_pl,
ST_EKO_30_ST30_ITOGO=@price_2_30_st,
ST_EKO_30_ST_CH1=@price_2_30_1,

ST_EKO_31_35_ST_CH1=@price_2_35_1,
ST_EKO_36_40_CH1=@price_2_36_1,
ST_EKO_41_ST_CH1=@price_2_41_1,

/*ST_EKO_30_ST30_ITOGO=@price_2_30_1,*/
ST_EKO_30_ST6_ITOGO=@price_2_30_ST6,
ST_EKO_30_PUNK_ITOGO=@price_2_30_PUN,
/*  */
BL22_PUNKCIYA_CH2=@price_2_30_PUN_2,
BL22_EMBR_EC_CH2=@price_2_30_IMB_2,
BL22_PERENOS_CH2=@price_2_30_PER_2,
--BL_ST_PROTOKOL_CH2=@code_2_30_2,
BL_ST_PROTOKOL_CH2=(COALESCE(CASE WHEN @price_2_30_IMB_2 IS NOT NULL AND @price_2_30_PUN_2 IS not NULL THEN 0 END,NULL)), 

BL_ST_ITOGO_CH2=(COALESCE(@price_2_30_PUN_2,0)+COALESCE(@price_2_30_IMB_2,0)+COALESCE(@price_2_30_PER_2,0)),

/*ST_EKO_30_PUNK_ITOGO=@price_2_30_PUN_2, */
/*ST_EKO_30_EMBRIO_ITOGO=@price_2_30_IMB_2, */
/*ST_EKO_30_PERENOS_ITOGO=@price_2_30_PER_2, */
/*   */

/*начало бл 22 часть2*/
BL_22_PROTOKOL_CH22=@code_2_MDF_2,
BL_22_EMBR_MS_CH22=@price_2_ms_embr_2,
BL_22_EMBR_EC_CH22=@price_2_es_embr_2,
BL_22_EC_PERENOS_CH22=@price_2_perenos_2,
BL_22_PUNKCIYA_CH22=@price_2_puction_2,
BL_22_EC_ITOGO_CH22=(COALESCE(@price_2_es_embr_2,0)+COALESCE(@price_2_puction_2,0)+COALESCE(@price_2_perenos_2,0)),
BL_22_MS_ITOGO_CH22=(COALESCE(@price_2_ms_embr_2,0)+COALESCE(@price_2_puction_2,0)+COALESCE(@price_2_perenos_2,0)),
/*конец бл 22 часть2*/
ST_EKO_30_EMBRIO_ITOGO=@price_2_30_IMB,
ST_EKO_30_PERENOS_ITOGO=@price_2_30_PER,
ST_EKO_30_ITOGO_CH1=(COALESCE(@price_2_30_1,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_pl,0)),
ST_EKO_31_35_ITOGO_CH1=(COALESCE(@price_2_35_1,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_pl,0)),
ST_EKO_36_40_ITOGO_CH1=(COALESCE(@price_2_36_1,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_pl,0)),
ST_EKO_41_ITOGO_CH1=(COALESCE(@price_2_41_1,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_pl,0)),

ST_EKO_35_ST_ITOGO=@price_2_35_st,
ST_EKO_31_35_SKIDKA=@discount_2_35_st,
ST_EKO_31_35_ITOGO=(COALESCE(@price_2_30_pl,0)+COALESCE(@price_2_35_st,0)+COALESCE(@price_2_30_PUN,0)+COALESCE(@price_2_30_IMB,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_PER,0)),
ST_EKO_36_40_SKIDKA=@discount_2_36_40_st ,
ST_EKO_36_40_ST_ITOGO=@price_2_36_40_st,
ST_EKO_36_40_ITOGO=(COALESCE(@price_2_30_pl,0)+COALESCE(@price_2_36_40_st,0)+COALESCE(@price_2_30_PUN,0)+COALESCE(@price_2_30_IMB,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_PER,0)),
ST_EKO_41_SKIDKA=@discount_2_41_st,
ST_EKO_40_ITOGO=(COALESCE(@price_2_30_pl,0)+COALESCE(@price_2_41_st,0)+COALESCE(@price_2_30_PUN,0)+COALESCE(@price_2_30_IMB,0)+COALESCE(@price_2_30_ST6,0)+COALESCE(@price_2_30_PER,0)),
ST_EKO_41_ST_ITOGO= @price_2_41_st,
BLEKO_ST_VID_PROTOKOLA=@code_2_30_11,

/*начало возврат ец мдф ч1*/
BL_PROTOKOL_CH1=@code_2_MDF_1,
BL22_STIM_EC_CH1=@price_2_es_stim_1,
BL22_STIM_MS_CH1=@price_2_ms_stim_1,
BL22_EC_ITOGO_CH1=(COALESCE(@price_2_es_plan,0)+COALESCE(@price_2_es_stim_1,0)),
BL22_MS_ITOGO_CH1=(COALESCE(@price_2_es_plan,0)+COALESCE(@price_2_ms_stim_1,0)),
/*конец возврат ец мдф ч1*/

BL_22_VID_PROTOKOLA_MDF=@code_2_MDF, /*BL22_VID_PROTOKOLA=@code_2_MDF,*/
BL_22_VID_PROTOKOLA_MS=@code_2_MS,
BL_22_PERENOS_MS=@price_2_perenos_ms,
/*начало мягкая стимуляция*/
BL_22_VID_PROTOKOLA_MS_2_=@code_2_MS2,
BL_22_MS_2_POPYTKI=@price_2_ms2,
BL_22_EMBR_RAB_MS_2_POPYT=@price_2_mc2_embr_rab,
/*конец мягкая стимуляция*/
BL22_PLANIROVANIE =@price_2_es_plan,
BL22_STIM_EC=@price_2_es_stim,
BL22_PUNKCIYA=@price_2_puction,
BL22_EMBR_EC=@price_2_es_embr_rab,
BL22_PERENOS=@price_2_perenos,
BL22_STIM_MS =@price_2_ms_stim,
BL22_EMBR_MS=@price_2_mc_embr_rab,
BL22_EC_SKIDKA=@discount_2_es_stim ,
BL22_MS_SKIDKA = @discount_2_ms_stim,
BL22_EMBRIOCIT=@price_2_embriosit,
BL22_EC_ITOGO=COALESCE(@price_2_es_plan,0)+COALESCE(@price_2_es_stim,0)+COALESCE(@price_2_puction,0)+COALESCE(@price_2_es_embr_rab,0)+COALESCE(@price_2_perenos,0),
BL22_MS_ITOGO=COALESCE(@price_2_es_plan,0)+COALESCE(@price_2_ms_stim,0)+COALESCE(@price_2_puction,0)+COALESCE(@price_2_mc_embr_rab,0)+COALESCE(@price_2_embriosit,0)+COALESCE(@price_2_perenos_ms,0),
BL_22_SUMMA_ITOGO_MS2=COALESCE(@price_2_es_plan,0)+COALESCE(@price_2_ms_stim,0)+COALESCE(@price_2_puction,0)+COALESCE(@price_2_mc2_embr_rab,0)+COALESCE(@price_2_perenos_ms,0)+COALESCE(@price_2_ms2,0),
BL24_VID_PROTOKOLA=@code_2_KRIO_PL_KRIO,
BL24_PER_KRIO_SKIDKA=@discount_2_KRIO_PL_KRIO_IMB_RAB,
BL24_PER_KRIO_ITOGO=(COALESCE(@price_2_KRIO_PL_KRIO_IMB_RAB,0)+COALESCE(@price_2_KRIO_PL_KRIO_PL,0)+COALESCE(@price_2_KRIO_PL_KRIO_PER,0)),
BL24_DON_EMBR_SKIDKA=@discount_2_KRIO_PL_KRIO_DON_IMB,
BL24_DON_EMBR_ITOGO=(COALESCE(@price_2_KRIO_PL_KRIO_DON_IMB,0)+COALESCE(@price_2_KRIO_PL_KRIO_PL,0)+COALESCE(@price_2_KRIO_PL_KRIO_PER,0)),
BL24_PER_KRIO_PL_KRIO=@price_2_KRIO_PL_KRIO_PL,
BL24_PER_KRIO_EMBR_RAB=@price_2_KRIO_PL_KRIO_IMB_RAB,
BL24_PER_KRIO_PERENOS=@price_2_KRIO_PL_KRIO_PER,
BL24_PER_KRIO_EMBR_RAB_DO=@price_2_KRIO_PL_KRIO_DON_IMB,
/*начало бл-24 этапы */
BL24_VID_PROT_ETAPY=@code_2_KRIO_PL_KRIO_CH,
BL_24_ITOGO_CH1=@price_2_KRIO_PL_KRIO_PL,
BL_24_ITOGO_K_CH2=(COALESCE(@price_2_KRIO_PL_KRIO_PER,0)+COALESCE(@price_2_KRIO_PL_KRIO_IMB_RAB,0)),
BL_24_ITOGO_DI_CH1=(COALESCE(@price_2_KRIO_PL_KRIO_PER,0)+COALESCE(@price_2_KRIO_PL_KRIO_DON_IMB,0)),
/*конец бл-24 этапы */


BL25_DYA_SKIDKA=@discount_2_OPL_STIM_DYA,
BL25_DYA_STIM_DYA=@price_2_OPL_STIM_D,
BL25_DYA_OBSL_DYA_SRM=@price_2_OPL_OBS_D,
BL25_DYA_OPL_PUNK_DYA=@price_2_OPL_PUN_D,
BL25_DYA_EMBR_RAB_DYA = COALESCE(@price_2_IMBRIO_ZAM,@price_2_IMB_RAB_D,0),
BL25_DYA_EMBRIOCIT_DYA=@price_2_IMBRIO_D,

BL25_DYA_STIM_DYA_1=@price_2_OPL_STIM_D_1 ,
BL25_DYA_STIM_DYA_2=@price_2_OPL_STIM_D_2 ,

BL25_DYA_CENA_ITOGO_1=(COALESCE(@price_2_OPL_STIM_D_1,0)+COALESCE(@price_2_OPL_STIM_D_2,0)+COALESCE(@price_2_OPL_PUN_D,0)+COALESCE(@price_2_IMB_RAB_D,0)+COALESCE(@price_2_IMBRIO_D,0)),
BL25_DYA_CENA_ITOGO=(COALESCE(@price_2_OPL_STIM_D,0)+COALESCE(@price_2_OPL_PUN_D,0)+COALESCE(@price_2_IMB_RAB_D,0)+COALESCE(@price_2_IMBRIO_D,0)),

ZAMORAZHIVANIE_SPERMY_VK1= @discount_2_H_S3_1 , 
ZAM_SPERMY_3_MES_KOL= @cnt_3_H_S3_1,
 ZAMORAZHIVANIE_SPERMY_VK2= @price_2_H_S3_1,

/**/

--IKSI_KOL_=@cnt_2_ICSI,
--IKSI_SKIDKA=@discount_2_ICSI,
--IKSI_CENA=@price_2_ICSI,
--IKSI_CENA_USLUGI=@price_3_ICSI,
/**/
/*DONORSKAYA_SPERMA_CENA_ZA=@code_1_D_S_V,*/
DON_SPERMA_1_SPERM_KOL_=@cnt_2_D_S_V,
DONORSKAYA_SPERMA_CENA_Z1=@discount_2_D_S_V,
DONORSKAYA_SPERMA_CENA_Z2=@price_2_D_S_V,
DON_SPER_1_SP_1_CENA=@price_3_D_S_V,

/**/
PER_KRIOEMBR_SRM_ETAP=@code_2_KRIO_PL_SRM,
PER_KRIOEMBR_SRM_SKIDKA=@discount_2_KRIO_PL_SRM,
PER_KRIOEMBR_SRM_START=@price_2_KRIO_PL_SRM,
PER_KRIOEMBR_SRM_EMBR_RAB=@price_2_KRIO_IMB_RAB_SRM,
PER_KRIOEMBR_SRM_PERENOS=@price_2_KRIO_PER_SRM,
PER_KRIOEMBR_SRM_ITOGO=(COALESCE(@price_2_KRIO_PL_SRM,0)+COALESCE(@price_2_KRIO_IMB_RAB_SRM,0)+COALESCE(@price_2_KRIO_PER_SRM,0)),

/**/

BL25_SRM_SKIDKA=@discount_2_STIM_SRM  ,
BL25_SRM_STIM_DYA=@price_2_STIM_SRM,
BL25_SRM_PLAN=@price_2_PLAN_SRM,
BL25_SRM_STIM_6= @price_2_ST_6_SRM,
 BL25_SRM_PUNKCIYA=@price_2_ST_PR_SRM,
BL25_SRM_OBSLED=@price_2_OBSLED_SRM,
--BL25_DYA_EMBR_RAB_DYA=@price_2_IMBRIO_ZAM,
BL25_SRM_CENA_ITOGO=(COALESCE(@price_2_OBSLED_SRM,0)+COALESCE(@price_2_PLAN_SRM,0)+COALESCE(@price_2_ST_6_SRM,0)+COALESCE(@price_2_STIM_SRM,0)+COALESCE(@price_2_ST_PR_SRM,0)+COALESCE(@price_2_IMB_RAB_D,0)+COALESCE(@price_2_IMBRIO_ZAM,0)),

/* начало МДФ 3 попытки*/
MDF3_ETAP=@code_2_MDF3,
MDF3_SKIDKA=@discount_2_MDF3  ,
MDF3_CHAST_1=@price_2_MDF3,
MDF3_CHAST_2=@price_2_MDF3_1,
MDF3_ITOGO=(COALESCE(@price_2_MDF3,0)+COALESCE(@price_2_MDF3_1,0)),
/*конец МДФ 3 попытки*/
/*начало Ест. зачатие 3 цикла*/
ES_3_ETAP=@code_2_3ES,
ES_3_SKIDKA=@discount_2_3ES ,
ES_3_ITOGO=COALESCE(@price_2_3ES,0),
/*конец Ест. зачатие 3 цикла*/
BLT_25_VID_PROTOKOLA_CH2=(COALESCE(@code_2_BLT25,(CASE WHEN @price_BLT25_OPL IS NOT NULL AND @price_BLT25_IMBR_RAB IS not NULL THEN 1 END),NULL)), 
BLT_25_SKIDKA_CH2=@discount_BLT25,
BLT_25_OPLATA_ZA_PUNKCIYU=@price_BLT25_OPL,
BLT_25_EMBRIOCIT_CH2=@price_BLT25_IMB,
BLT_25_EMBRIORABOTA_DYA_C=@price_BLT25_IMBR_RAB,
BLT_25_STIMULYACIYA_DYA_C=@price_BLT25_ST11,
BLT_25_STIMULYACIYA_DYA_1=@price_BLT25_ST12,
BLT_25_ITOGO_SUMMA_CH2=(COALESCE(@price_BLT25_OPL,0)+COALESCE(@price_BLT25_IMB,0)+COALESCE(@price_BLT25_IMBR_RAB,0)+COALESCE(@price_BLT25_ST11,0)+COALESCE(@price_BLT25_ST12,0))
where MOTCONSU_ID=@MOTCONSU_ID

 end

        fetch NEXT from VOZVRAT_30
into
 @code_1_30,
 @cnt_1_30,
@price_1_30,
 @price_1_30,
@discount_1_30,
@OPLATE
end
close VOZVRAT_30
DEALLOCATE  VOZVRAT_30

BEGIN
DECLARE

@STIM INT,
@PUNK INT,
@VMS INT,
@KULT INT,
@NOTSTAND INT,
@NOTBER INT,
@PLODI INT,
@BEDNII_OTVET INT,

@NOT_PUNKCII INT,
@NOT_IMBRIO INT,
@NOT_PERENOS INT,
@NOT_VMS INT,
@PERENOS INT,
@ZAMOROZKA INT

SELECT 
@STIM=ISHOD_ETAPA_STIMULYACIYA,
@PUNK=ISHOD_ETAPA_PUNKCIYA,
@VMS=ISHOD_VMS,
@KULT=ISHOD_ETAPA_KUL_TIVIROVAN,
@NOTSTAND=NESTANDARTNYY_ISHOD,
@NOTBER=BEREM_NE_NEASTUPILA,
@PLODI=KOLICHESTVO_PLODOV,
@PERENOS=PERENOS,
@ZAMOROZKA=ZAMOROZKA,
@MDF3P=NOMER_POPYTKI_MDF
FROM DATA_CYCLE_RESULT
WHERE MOTCONSU_ID=@MOTCONSU_ISHOD_ID

IF @STIM=0 BEGIN SET @BEDNII_OTVET=1 END
IF @STIM IN ( 1,2,3) OR @KULT=8 BEGIN SET @NOT_PUNKCII=1 END
IF @PUNK=0 BEGIN SET @NOT_IMBRIO=1 END
IF @KULT IN (0,1,5) OR @PUNK=1 BEGIN SET @NOT_PERENOS=1 END
IF @VMS IN (0,1) BEGIN SET @NOT_VMS=1 END

UPDATE DATA_W693_VOZVRAT_DENEG
SET VID_VOZVRATA= coalesce(
(CASE
/*Начало ВСЕ Включено */
WHEN @code_2_30_1 IS NOT NULL AND @BEDNII_OTVET=1 THEN 1 
WHEN @code_2_30_1 IS NOT NULL AND @NOT_PUNKCII=1 THEN 2 
WHEN @code_2_30_1 IS NOT NULL AND @NOT_IMBRIO=1 THEN 3 
WHEN @code_2_30_1 IS NOT NULL AND @NOT_PERENOS=1 THEN 4
/*Конец ВСЕ Включено */
END),NULL),
/*Начало БЛ 54 Отсроченное материнство */
BL_54_VID_VOZVRATA= coalesce(
(CASE
WHEN @code_2_30_1 IS NOT NULL AND @BEDNII_OTVET=1 THEN 1 
WHEN @code_2_30_1 IS NOT NULL AND @NOT_PUNKCII=1 THEN 2 
WHEN @code_2_30_1 IS NOT NULL AND @NOT_IMBRIO=1 THEN 3 
WHEN @code_2_30_1 IS NOT NULL AND @NOT_PERENOS=1 THEN 4
END),NULL),
/*Конец БЛ 54 Отсроченное материнство*/
BL_22_VID_VOZVRATA_MDF = coalesce(
(CASE
--WHEN @code_2_MS=0 AND @STIM =0 THEN 1 
--WHEN @code_2_MS=0 AND @STIM in (1,2,3) THEN 2 
--WHEN @code_2_MS=0 AND @PUNK=0 THEN 3 
--WHEN @code_2_MS=0 AND (@KULT in (0,1) or @PUNK=1) THEN 4
/*@code_2_MS*/
WHEN @code_2_MDF= 0 AND @BEDNII_OTVET=1 THEN 1 
WHEN @code_2_MDF= 0 AND @NOT_PUNKCII=1 THEN 2 
WHEN @code_2_MDF= 0 AND @NOT_IMBRIO=1 THEN 3 
WHEN @code_2_MDF= 0 AND @NOT_PERENOS=1 THEN 4
WHEN @code_2_MDF= 0 AND @PERENOS=1 and @ZAMOROZKA=0 THEN 5
WHEN @code_2_MDF= 0 AND @KULT=7 THEN 6

END),NULL),
BL22_VID_VOZVRATA= coalesce(
(CASE
WHEN @code_2_MS=0 AND @STIM =0 THEN 1 
WHEN @code_2_MS=0 AND @STIM in (1,2,3) THEN 2 
WHEN @code_2_MS=0 AND @PUNK=0 THEN 3 
WHEN @code_2_MS=0 AND (@KULT in (0,1) or @PUNK=1) THEN 4
--/*@code_2_MS*/
--WHEN @code_2_MDF= 1 AND @BEDNII_OTVET=1 THEN 1 
--WHEN @code_2_MDF= 1 AND @NOT_PUNKCII=1 THEN 2 
--WHEN @code_2_MDF= 1 AND @NOT_IMBRIO=1 THEN 3 
--WHEN @code_2_MDF= 1 AND @NOT_PERENOS=1 THEN 4
--WHEN @code_2_MDF= 1 AND @PERENOS=1 and @ZAMOROZKA=0 THEN 5
--WHEN @code_2_MDF= 1 AND @KULT=7 THEN 6

END),NULL)
,
BL24_VID_VOZVRATA = coalesce(
(CASE
WHEN @code_2_KRIO_PL_KRIO_CH IS NOT NULL AND @STIM in (1,2) THEN 1 
WHEN @code_2_KRIO_PL_KRIO_CH IS NOT NULL AND @KULT in (1,5) THEN 2
WHEN @code_2_KRIO_PL_KRIO IS NOT NULL AND  @STIM in (1,2) THEN 1 
WHEN @code_2_KRIO_PL_KRIO IS NOT NULL AND  @KULT in (1,5) THEN 2
END),NULL)
,
PER_KRIOEMBR_SRM_VID=coalesce(
(CASE
WHEN @code_2_KRIO_PL_SRM IS NOT NULL AND @NOT_PUNKCII=1 THEN 0 
WHEN @code_2_KRIO_PL_SRM IS NOT NULL AND @NOT_PERENOS=1 THEN 1
END),NULL),
BL36_VID_VOZVRATA=coalesce(
(CASE
WHEN @code_2_KR_IM_R IS NOT NULL AND (@STIM in (1,2)or @PUNK=0 ) THEN 1 
WHEN @code_2_KR_IM_R IS NOT NULL AND @KULT in (0,1,4,7) THEN 2
END),NULL),
BL25_VID_VOZVRATA=coalesce(
(CASE
/*БЛ-25 */
WHEN @code_2_SRM_1 IS NOT NULL AND @BEDNII_OTVET=1 THEN 1 
WHEN @code_2_SRM_1 IS NOT NULL AND @NOT_PUNKCII=1 THEN 2 
WHEN @code_2_SRM_1 IS NOT NULL AND @NOT_IMBRIO=1 THEN 3 
WHEN @code_2_SRM_1 IS NOT NULL AND @NOT_PERENOS=1 THEN 4
/*Конец БЛ-25 */
END),NULL),
BL23_VID_VOZVRATA=coalesce(
(CASE
/*БЛ-23 */
WHEN @code_2_VMI_1 IS NOT NULL AND (@NOT_VMS=1 OR @STIM in (1))  THEN 1 

/*Конец БЛ-23 */
END),NULL),
/*Начало БЛ-52 */
BL_22_VID_VOZVRATA_MS2=coalesce(
(CASE
WHEN @code_2_MS2 IS NOT NULL AND (@STIM =0 or @KULT =8) THEN 1 
WHEN @code_2_MS2 IS NOT NULL AND @STIM in (1,2,3) THEN 2 
WHEN @code_2_MS2 IS NOT NULL AND @PUNK in (0) THEN 3
WHEN @code_2_MS2 IS NOT NULL AND (@PUNK=1  or  @KULT in (0,1,5) ) THEN 4 
 
END),NULL),
/*Конец БЛ-52 */
/*Начало БЛ-50 */
MDF3_VID=coalesce(
(CASE
/*БЛ-25 */
WHEN  @code_2_MDF3 IS NOT NULL AND @PLODI in (1,2,3) and @MDF3P=3 THEN 0 
 
END),NULL),
/*Конец БЛ-50 */
/*Начало БЛТ 21 Стандартный протокол */
BL_ST_VOZVRAT_CH2= coalesce(
(CASE
WHEN @code_2_30_2 IS NOT NULL AND @STIM in (1,2,3) THEN 0 
WHEN @code_2_30_2 IS NOT NULL AND @PUNK=0 THEN 1
WHEN @code_2_30_2 IS NOT NULL AND (@PUNK in (0,1) or  @KULT in (0,1,5)) THEN 2 
END),NULL),
/*Конец БЛТ 21 Стандартный протокол */
/*Начало БЛТ 22 */
BL_22_VOZVRAT_CH22= coalesce(
(CASE
WHEN @code_2_MDF_2 IS NOT NULL AND (@STIM in (1,2,3)or  @KULT =8) THEN 0 
WHEN @code_2_MDF_2 IS NOT NULL AND @PUNK=0  THEN 1
WHEN @code_2_MDF_2 IS NOT NULL AND (@PUNK in (1) or  @KULT in (0,1,4,5,7)) THEN 2 
END),NULL),
/*Конец БЛТ 22 */
/*Начало БЛТ-22 часть 1 */
BL_22_CHAST_1=coalesce(
(CASE
WHEN @code_2_MDF_1 IS NOT NULL AND @STIM=0 THEN 1 
 END),NULL),
/*Конец БЛТ-22 часть 1*/
/*Начало БЛТ 25 */
BLT_25_VID_VOZVRATA_CH2= coalesce(
(CASE
WHEN (@code_2_BLT25 IS NOT NULL or (@price_BLT25_ST11 IS NOT NULL AND @price_BLT25_ST12 IS not NULL )) AND (@KULT=8 or @STIM=0) THEN 1
WHEN (@code_2_BLT25 IS NOT NULL or (@price_2_30_IMB_2 IS NOT NULL AND @price_2_30_PUN_2 IS not NULL )) AND (@STIM in (1,2) ) THEN 2 
WHEN (@code_2_BLT25 IS NOT NULL or (@price_2_30_IMB_2 IS NOT NULL AND @price_2_30_PUN_2 IS not NULL )) AND (@STIM in (1,2) ) or @PUNK=0 THEN 3
WHEN (@code_2_BLT25 IS NOT NULL or (@price_2_30_IMB_2 IS NOT NULL AND @price_2_30_PUN_2 IS not NULL )) AND (@STIM in (1,2)  or @PUNK =1 or  @KULT in (0,1)) THEN 4
END),NULL)
/*Конец БЛТ 25 */


where MOTCONSU_ID=@MOTCONSU_ID
END


END
go

