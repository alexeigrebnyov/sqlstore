
CREATE FUNCTION [dbo].[countbeds_pol]
-- дата окончания периода, отделение, пол, начало дня в минутах
(@end AS datetime, @dep as int, @pol as int)
RETURNS int
AS
BEGIN
	declare @res int, @ho_room_id int, @room_pol int, @count_beds_M int, @count_beds_G int 

	set @count_beds_M = 0
	set @count_beds_G = 0

	declare cur_room cursor for
		select ho_room_id from ho_room where fm_dep_id = @dep

	open cur_room
	
	fetch cur_room into @ho_room_id
	while @@FETCH_STATUS =0
	begin

		set @room_pol = 0

		select top 1 @room_pol = patients.pol from data_transfers data_transfers
		inner join patients patients on data_transfers.patients_id = patients.patients_id
		where 
		data_transfers.arrive_date <= @end and data_transfers.main_dep_id is not null and ho_room_id = @ho_room_id
		order by data_transfers.arrive_date desc

		IF (@room_pol = 0)
			select @count_beds_M = @count_beds_M + count(*) from ho_bed where ho_room_id = @ho_room_id
			and (((dateadd(day, -1,@end)  >= ISNULL(DATE_START,'1900-01-01') and dateadd(day, -1,@end)  <= ISNULL(DATE_END,'2100-01-01'))
			and @end >= ISNULL(DATE_END,'2100-01-01')) OR (ISNULL(DATE_START,'1900-01-01') >= dateadd(day, -1,@end)  
			and @end > ISNULL(DATE_START,'1900-01-01') and @end >= ISNULL(DATE_END,'2100-01-01')) OR (ISNULL(DATE_START,'1900-01-01') >= dateadd(day, -1,@end)  
			and @end > ISNULL(DATE_START,'1900-01-01') and @end < ISNULL(DATE_END,'2100-01-01')) OR (dateadd(day, -1,@end)  >= ISNULL(DATE_START,'1900-01-01') 
			and @end <= ISNULL(DATE_END,'2100-01-01'))) and ARCHIVE = 0 AND ho_bed.ho_bed_id not in
			( SELECT distinct HO_RESDET_BEDS.HO_BED_ID FROM
			  HO_RESERV HO_RESERV JOIN HO_RESDET HO_RESDET ON HO_RESERV.HO_RESERV_ID = HO_RESDET.HO_RESERV_ID 
			  JOIN HO_RESDET_BEDS HO_RESDET_BEDS ON HO_RESDET.HO_RESDET_ID = HO_RESDET_BEDS.HO_RESDET_ID   
			  WHERE
			  HO_RESERV.HO_RESERV_TYPE_ID IN (3,4) and HO_RESERV.FM_DEP_ID=@dep and HO_RESERV.ARRIVE_DATE < @end
			  and (HO_RESERV.DEPART_DATE >= @end or HO_RESERV.DEPART_DATE is null)
			)

		IF (@room_pol = 1)
			select @count_beds_G = @count_beds_G + count(*) from ho_bed where ho_room_id = @ho_room_id
			and (((dateadd(day, -1,@end)  >= ISNULL(DATE_START,'1900-01-01') and dateadd(day, -1,@end)  <= ISNULL(DATE_END,'2100-01-01'))
			and @end >= ISNULL(DATE_END,'2100-01-01')) OR (ISNULL(DATE_START,'1900-01-01') >= dateadd(day, -1,@end)  
			and @end > ISNULL(DATE_START,'1900-01-01') and @end >= ISNULL(DATE_END,'2100-01-01')) OR (ISNULL(DATE_START,'1900-01-01') >= dateadd(day, -1,@end)  
			and @end > ISNULL(DATE_START,'1900-01-01') and @end < ISNULL(DATE_END,'2100-01-01')) OR (dateadd(day, -1,@end)  >= ISNULL(DATE_START,'1900-01-01') 
			and @end <= ISNULL(DATE_END,'2100-01-01'))) and ARCHIVE = 0 AND ho_bed.ho_bed_id not in
			( SELECT distinct HO_RESDET_BEDS.HO_BED_ID FROM
			  HO_RESERV HO_RESERV JOIN HO_RESDET HO_RESDET ON HO_RESERV.HO_RESERV_ID = HO_RESDET.HO_RESERV_ID 
			  JOIN HO_RESDET_BEDS HO_RESDET_BEDS ON HO_RESDET.HO_RESDET_ID = HO_RESDET_BEDS.HO_RESDET_ID   
			  WHERE
			  HO_RESERV.HO_RESERV_TYPE_ID IN (3,4) and HO_RESERV.FM_DEP_ID=@dep and HO_RESERV.ARRIVE_DATE < @end
			  and (HO_RESERV.DEPART_DATE >= @end or HO_RESERV.DEPART_DATE is null)
			)

	fetch cur_room into @ho_room_id
	end
	
	close cur_room
	deallocate cur_room

	set @res = case when @pol = 1 then @count_beds_G else @count_beds_M end

	RETURN @res
END

go

