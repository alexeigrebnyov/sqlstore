
CREATE FUNCTION [dbo].[countdays]
-- дата начала, дата конца, тип брони, отделение, тип койки, начало дня в минутах, вид ЛПУ
(@beg AS datetime, @end AS datetime, @type as int, @dep as int, @bed as int, @minuta as int, @vid_lpu as varchar(7))
RETURNS int
AS
BEGIN
	declare @res int

--set @beg = DATEADD(mi, @minuta, @beg)
--set @end = DATEADD(mi, @minuta, @end)

  if @bed is not null

if @dep is not null	
set @res = (SELECT sum(
datediff(dd,case when DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE)>@beg then DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) else DATEADD(mi, (-1)*@minuta,@beg) end,
case when HO_RESERV.DEPART_DATE is not null and DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)<@end then DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE) else @end end)
+ case FM_DEP.DEP_TYPE
when 2 then 1 when 3 then 1 else 0 end
+ case when HO_RESERV.DEPART_DATE is not null and datediff(dd,DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE),DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE))=0 then 1
else 0 end)
 FROM
 HO_RESERV HO_RESERV JOIN HO_RESDET HO_RESDET ON HO_RESERV.HO_RESERV_ID = HO_RESDET.HO_RESERV_ID 
 JOIN HO_RESDET_BEDS HO_RESDET_BEDS ON HO_RESDET.HO_RESDET_ID = HO_RESDET_BEDS.HO_RESDET_ID 
 JOIN FM_DEP FM_DEP ON FM_DEP.FM_DEP_ID = HO_RESERV.FM_DEP_ID 
WHERE
 HO_RESERV.HO_RESERV_TYPE_ID=@type and HO_RESERV.FM_DEP_ID=@dep and (HO_RESERV.RES_STATE='E' or HO_RESERV.RES_STATE='D')
and DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) <= @end and (DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)>=@beg or HO_RESERV.DEPART_DATE is null)
and HO_RESDET_BEDS.HO_BED_TYPE_ID=@bed)

else
set @res = (SELECT sum(
datediff(dd,case when DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE)>@beg then DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) else DATEADD(mi, (-1)*@minuta,@beg) end,
case when HO_RESERV.DEPART_DATE is not null and DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)<@end then DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE) else @end end)
+ case FM_DEP.DEP_TYPE
when 2 then 1 when 3 then 1 else 0 end
+ case when HO_RESERV.DEPART_DATE is not null and datediff(dd,DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE),DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE))=0 then 1
else 0 end)
 FROM
 HO_RESERV HO_RESERV JOIN HO_RESDET HO_RESDET ON HO_RESERV.HO_RESERV_ID = HO_RESDET.HO_RESERV_ID 
 JOIN HO_RESDET_BEDS HO_RESDET_BEDS ON HO_RESDET.HO_RESDET_ID = HO_RESDET_BEDS.HO_RESDET_ID 
 JOIN FM_DEP FM_DEP ON FM_DEP.FM_DEP_ID = HO_RESERV.FM_DEP_ID 
WHERE
 HO_RESERV.HO_RESERV_TYPE_ID=@type and (HO_RESERV.RES_STATE='E' or HO_RESERV.RES_STATE='D')
and DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) <= @end and (DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)>=@beg or HO_RESERV.DEPART_DATE is null)
and HO_RESDET_BEDS.HO_BED_TYPE_ID=@bed 
and (@vid_lpu is null or (FM_DEP.DEP_TYPE=1 and @vid_lpu='КС') or (FM_DEP.DEP_TYPE=2 and @vid_lpu='ДС')
 or (FM_DEP.DEP_TYPE in (1,2) and @vid_lpu='КС и ДС' )))

else

if @dep is not null	
set @res = (SELECT sum(
datediff(dd,case when DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE)>@beg then DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) else DATEADD(mi, (-1)*@minuta,@beg) end,
case when HO_RESERV.DEPART_DATE is not null and DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)<@end then DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE) else @end end)
+ case FM_DEP.DEP_TYPE
when 2 then 1 when 3 then 1 else 0 end
+ case when HO_RESERV.DEPART_DATE is not null and datediff(dd,DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE),DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE))=0 then 1
else 0 end)
 FROM
 HO_RESERV HO_RESERV JOIN HO_RESDET HO_RESDET ON HO_RESERV.HO_RESERV_ID = HO_RESDET.HO_RESERV_ID 
 JOIN FM_DEP FM_DEP ON FM_DEP.FM_DEP_ID = HO_RESERV.FM_DEP_ID 
WHERE
 HO_RESERV.HO_RESERV_TYPE_ID=@type and HO_RESERV.FM_DEP_ID=@dep and (HO_RESERV.RES_STATE='E' or HO_RESERV.RES_STATE='D')
and DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) <= @end and (DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)>=@beg 
or HO_RESERV.DEPART_DATE is null))

else
set @res = (SELECT sum(
datediff(dd,case when DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE)>@beg then DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) else DATEADD(mi, (-1)*@minuta,@beg) end,
case when HO_RESERV.DEPART_DATE is not null and DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)<@end then DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE) else @end end)
+ case FM_DEP.DEP_TYPE
when 2 then 1 when 3 then 1 else 0 end
+ case when HO_RESERV.DEPART_DATE is not null and datediff(dd,DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE),DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE))=0 then 1
else 0 end) 
 FROM
 HO_RESERV HO_RESERV JOIN HO_RESDET HO_RESDET ON HO_RESERV.HO_RESERV_ID = HO_RESDET.HO_RESERV_ID 
 JOIN FM_DEP FM_DEP ON FM_DEP.FM_DEP_ID = HO_RESERV.FM_DEP_ID 
WHERE
 HO_RESERV.HO_RESERV_TYPE_ID=@type and (HO_RESERV.RES_STATE='E' or HO_RESERV.RES_STATE='D')
and DATEADD(mi, (-1)*@minuta,HO_RESERV.ARRIVE_DATE) <= @end and (DATEADD(mi, (-1)*@minuta,HO_RESERV.DEPART_DATE)>=@beg 
or HO_RESERV.DEPART_DATE is null)
and (@vid_lpu is null or (FM_DEP.DEP_TYPE=1 and @vid_lpu='КС') or (FM_DEP.DEP_TYPE=2 and @vid_lpu='ДС')
 or (FM_DEP.DEP_TYPE in (1,2) and @vid_lpu='КС и ДС' )))

if @res is null set @res=0

	RETURN @res
END

go

