create function [dbo].[dmGetMeasureFactor](@DM_LOTS_ID int, @DM_MEASURE_ID int)
returns numeric(20,10)
as
begin
    declare @RES numeric(20,10)


    select @RES = convert(numeric(20, 10), 
                case 
                    when m.DM_MEASURE_ID = @DM_MEASURE_ID 
                    then 1.0 
                    else f.MEASURE_FACTOR / f.MEDS_MEASURE_FACTOR 
                end)
    from
                        DM_LOTS                  l 
        join                DM_MEDS              m on m.DM_MEDS_ID    = l.DM_MEDS_ID
        left outer join         DM_MEDS_MEASURES f on f.DM_MEDS_ID    = m.DM_MEDS_ID 
                                                  and f.DM_MEASURE_ID = @DM_MEASURE_ID
    where
        l.DM_LOTS_ID    = @DM_LOTS_ID

    return @RES
end
go

