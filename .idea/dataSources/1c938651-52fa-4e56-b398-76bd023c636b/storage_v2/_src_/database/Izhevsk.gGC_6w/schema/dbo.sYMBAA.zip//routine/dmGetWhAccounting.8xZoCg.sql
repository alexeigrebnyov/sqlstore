create function dbo.dmGetWhAccounting(@WH_ID int)
returns int
as
--75615
begin
    declare @Result int

    select top 1 @Result = w.DM_WAREHOUSES_ID
      from DM_WH_TREE t 
      join DM_WAREHOUSES w on t.PARENT_ID = w.DM_WAREHOUSES_ID
     where t.CHILD_ID = @WH_ID
       and w.ACCOUNTING = 1
    order by RLENGTH 

    set @Result = isnull(@Result, @WH_ID)

    return @Result
end
go

