CREATE PROCEDURE [dbo].[dmWarehouseReportEx](
  @DATE_BEGIN datetime,
  @DATE_END datetime = NULL,
  @WH_ID int,
  @GROUP_FIELDS varchar(200) = NULL,
  @GROUP_FIELDS_MV varchar(200) = NULL,
  @IS_MIXTURE_INCLUDE bit = 1,
  @IS_EMPTY_REMOVE bit = 1,
  @IS_SUBWH_INCLUDE bit = 0,
  @IS_TIME_USE bit = 0,
  @CLEAR_RESULT bit = 1)

AS
BEGIN
--800134
--751048
--751096
--751326
  declare @is_rest_only bit

  set @is_rest_only = 0
  if @DATE_END is null
  begin
    set @is_rest_only = 1 -- нас интересуют только остатки на начало периода
  end

  declare @date_end_bkp datetime

  set @date_end_bkp = @DATE_END

  if @IS_TIME_USE = 0
  begin               
    set @DATE_BEGIN = dateadd(day, datediff(day, 0, @DATE_BEGIN), 0)
    set @DATE_END   = dateadd(day, datediff(day, 0, @DATE_END),   0)
                    
    set @DATE_END = @DATE_END + 1
  end

  /*
    Задание списка допустимых полей группировки
  */

  declare
    @lots_id_mask int,
    @meds_id_mask int,
    @groups_id_mask int,
    @source_fin_mask int,
    @doc_id_mask int,
    @doc_type_id_mask int

  set @lots_id_mask = 1
  set @meds_id_mask = 2
  set @groups_id_mask = 4
  set @source_fin_mask = 8
  set @doc_id_mask = 16
  set @doc_type_id_mask = 32

  declare @idx_fields table (fname varchar(50), alias varchar(50), fmask int, cmask int, cmask_mv int)

  insert @idx_fields values ('dm_lots_id', 'l', @lots_id_mask, 0, 0)
  insert @idx_fields values ('dm_meds_id', 'm', @meds_id_mask, 0, 0)
  insert @idx_fields values ('dm_groups_id', 'g', @groups_id_mask, 0, 0)
  insert @idx_fields values ('fm_source_fin_id', 'f', @source_fin_mask, 0, 0)
  insert @idx_fields values ('dm_doc_id', 'mv', @doc_id_mask, 0, 0)
  insert @idx_fields values ('dm_doc_type_id', 'mv', @doc_type_id_mask, 0, 0)

  declare @idx int
  declare @i int
  declare @fld_name varchar(50)

  /*
    Разбор параметра @GROUP_FIELDS, задающего поля группировки для остатков
  */

  set @GROUP_FIELDS = replace(@GROUP_FIELDS, ' ', '')
  set @idx = isnull(charindex(',', @GROUP_FIELDS, len(@GROUP_FIELDS)), 0)
  if @idx = 0
  begin
    set @GROUP_FIELDS = @GROUP_FIELDS + ','
  end

  set @idx = isnull(charindex(',', @GROUP_FIELDS), 0)
  while @idx <> 0
  begin
    set @fld_name = ''
    if @idx > 1
    begin
      set @fld_name=substring(@GROUP_FIELDS, 1, @idx- 1)
    end
    set @i = len(@GROUP_FIELDS)
    if @idx < @i
    begin
      set @GROUP_FIELDS = substring(@GROUP_FIELDS, @idx+ 1, @i- @idx)
    end
    else
    begin
      set @GROUP_FIELDS = ''
    end
    if len(@fld_name) > 0
    begin
      update @idx_fields set cmask = fmask where fname = @fld_name
      if @@rowcount  = 0
      begin
        raiserror ( 'Недопустимое поле группировки "%s".', 16, 1, @fld_name)
  end
    end
    set @idx = isnull(charindex(',', @GROUP_FIELDS), 0)
  end

  /*
    Разбор параметра @GROUP_FIELDS_MV, задающего поля группировки для движения
  */

  set @GROUP_FIELDS_MV = replace(@GROUP_FIELDS_MV, ' ', '')
  set @idx = isnull(charindex(',', @GROUP_FIELDS_MV, len(@GROUP_FIELDS_MV)), 0)
  if @idx = 0
  begin
    set @GROUP_FIELDS_MV = @GROUP_FIELDS_MV + ','
  end

  set @idx = isnull(charindex(',', @GROUP_FIELDS_MV), 0)
  while @idx <> 0
  begin
    set @fld_name = ''
    if @idx > 1
    begin
      set @fld_name=substring(@GROUP_FIELDS_MV, 1, @idx- 1)
    end
    set @i = len(@GROUP_FIELDS_MV)
    if @idx < @i
    begin
      set @GROUP_FIELDS_MV = substring(@GROUP_FIELDS_MV, @idx+ 1, @i- @idx)
    end
    else
    begin
      set @GROUP_FIELDS_MV = ''
    end
    if len(@fld_name) > 0
    begin
      update @idx_fields set cmask_mv = fmask where fname = @fld_name
      if @@rowcount  = 0
      begin
        raiserror ( 'Недопустимое поле группировки "%s".', 16, 1, @fld_name)
  end
    end
    set @idx = isnull(charindex(',', @GROUP_FIELDS_MV), 0)
  end

  if @GROUP_FIELDS is null
  begin
    /*
      Группировка по всем полям по умолчанию
    */
    update @idx_fields set cmask = fmask
  end

  if @GROUP_FIELDS_MV is null
  begin
    /*
      Копируем поля группировки из остатков
    */
    update @idx_fields set cmask_mv = cmask
  end

  create table #t (DM_LOTS_ID int, Q_WH float, Q_BEG float, Q_END float,
    SUM_WH float, SUM_BEG float, SUM_END float, VAT_WH float, VAT_BEG float, VAT_END float)
  INSERT #t
  SELECT DM_LOTS_ID, IsNull(QUANTITY,0), 0, 0, IsNull(CURRENT_SUM, 0), 0, 0, IsNull(CURRENT_NDS, 0), 0, 0
  FROM DM_WAREHOUSE W JOIN DM_WH_TREE R ON R.CHILD_ID=W.DM_WAREHOUSES_ID
  WHERE (R.PARENT_ID = @WH_ID)
  AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)

  /*  ТИП ДОКУМЕНТА 5- "Приход о созданию прописи"
        НИГДЕ НЕ ОБРАБАТЫВАЕТСЯ !!!
  */

  -- Приходы и инвентаризация (кроме розницы-возврата)
  insert #t
  select t.DM_LOTS_ID, 0, sum(
      0- case when doc.DM_DOC_TYPE_ID = 3 then t.LACK * t.MEASURE_FACTOR else t.QUANTITY * t.MEASURE_FACTOR end),
      sum(case when doc.ACCEPT_DATE >= @DATE_END then
      0- case when doc.DM_DOC_TYPE_ID = 3 then t.LACK * t.MEASURE_FACTOR else t.QUANTITY * t.MEASURE_FACTOR end else 0 end),
      0,
      sum(0- t.transfers_sum),
      sum(case when doc.ACCEPT_DATE >= @DATE_END then 0- t.transfers_sum else 0 end),
      0,
      sum(0- t.transfers_nds),
      sum(case when doc.ACCEPT_DATE >= @DATE_END then 0- t.transfers_nds else 0 end)
    from DM_DOC doc inner loop join DM_TRANSFERS t on t.DM_DOC_ID = doc.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=t.TRANSFER_WH_IN
    where (R.PARENT_ID = @WH_ID)
      and isnull(t.IS_ACPT_RETAIL, 0) = 1 
      and doc.ACCEPT_DATE >= @DATE_BEGIN
      and doc.DM_DOC_TYPE_ID <> 8
      and t.DM_REPRICE_LOTS_ID is null
      AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    group by t.DM_LOTS_ID


  -- Приходы розница-возврат
  insert #t
  select t.DM_LOTS_ID, 0, sum(
      0- case when doc.DM_DOC_TYPE_ID = 3 then t.LACK * t.MEASURE_FACTOR else t.QUANTITY * t.MEASURE_FACTOR end),
      sum(case when t.ACPT_RETAIL_DATE >= @DATE_END then
      0- case when doc.DM_DOC_TYPE_ID = 3 then t.LACK * t.MEASURE_FACTOR else t.QUANTITY * t.MEASURE_FACTOR end else 0 end),
      0,
      sum(0- t.transfers_sum),
      sum(case when t.ACPT_RETAIL_DATE >= @DATE_END then 0- t.transfers_sum else 0 end),
      0,
      sum(0- t.transfers_nds),
      sum(case when t.ACPT_RETAIL_DATE >= @DATE_END then 0- t.transfers_nds else 0 end)
    from DM_DOC doc inner loop join DM_TRANSFERS t on t.DM_DOC_ID = doc.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=t.TRANSFER_WH_IN
    where (R.PARENT_ID = @WH_ID)
      and isnull(t.IS_ACPT_RETAIL, 0) = 1 
      and t.ACPT_RETAIL_DATE >= @DATE_BEGIN
      and doc.DM_DOC_TYPE_ID = 8
      and t.DM_REPRICE_LOTS_ID is null
      AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    group by t.DM_LOTS_ID


  -- Переоценка и перемещения с переоценкой (приходы)
  insert #t
  select t.DM_LOTS_ID, 0, sum(0- t.QUANTITY * t.MEASURE_FACTOR),
      sum(case when doc.ACCEPT_DATE >= @DATE_END then
      0- t.QUANTITY * t.MEASURE_FACTOR else 0 end),
      0,
      sum(0- l.INCOME_SUM),
      sum(case when doc.ACCEPT_DATE >= @DATE_END then 0- l.INCOME_SUM else 0 end),
      0,
      sum(0- l.INCOME_NDS),
      sum(case when doc.ACCEPT_DATE >= @DATE_END then 0- l.INCOME_NDS else 0 end)
    from DM_DOC doc inner loop join DM_TRANSFERS t on t.DM_DOC_ID = doc.DM_DOC_ID
    JOIN DM_LOTS l ON l.DM_LOTS_ID = t.DM_LOTS_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=t.TRANSFER_WH_IN
    where R.PARENT_ID = @WH_ID
      and doc.DM_DOC_TYPE_ID IN (4,9)
      and isnull(t.IS_ACPT_RETAIL, 0) = 1 
      and doc.ACCEPT_DATE >= @DATE_BEGIN
      and t.DM_REPRICE_LOTS_ID is not null
      AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    group by t.DM_LOTS_ID

  -- Расходы без переоценок (кроме розницы)
  insert #t
  select t.DM_LOTS_ID, 0, sum(t.QUANTITY * t.MEASURE_FACTOR),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.QUANTITY * t.MEASURE_FACTOR else 0 end),
    0,
    sum(t.transfers_sum),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.transfers_sum else 0 end),
    0,
    sum(t.transfers_nds),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.transfers_nds else 0 end)
    from DM_DOC doc inner loop join DM_TRANSFERS t on t.DM_DOC_ID = doc.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=t.TRANSFER_WH_OUT
  where R.PARENT_ID = @WH_ID
    and t.DM_REPRICE_LOTS_ID is null
    and isnull(t.IS_ACPT_RETAIL, 0) = 1 
    and  doc.ACCEPT_DATE  >= @DATE_BEGIN
    and doc.DM_DOC_TYPE_ID <> 8
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
  group by t.DM_LOTS_ID

  -- Расходы без переоценок розница
  insert #t
  select t.DM_LOTS_ID, 0, sum(t.QUANTITY * t.MEASURE_FACTOR),
    sum(case when t.ACPT_RETAIL_DATE >= @DATE_END then t.QUANTITY * t.MEASURE_FACTOR else 0 end),
    0,
    sum(t.transfers_sum),
    sum(case when t.ACPT_RETAIL_DATE >= @DATE_END then t.transfers_sum else 0 end),
    0,
    sum(t.transfers_nds),
    sum(case when t.ACPT_RETAIL_DATE >= @DATE_END then t.transfers_nds else 0 end)
    from DM_DOC doc inner loop join DM_TRANSFERS t on t.DM_DOC_ID = doc.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=t.TRANSFER_WH_OUT
  where R.PARENT_ID = @WH_ID
    and t.DM_REPRICE_LOTS_ID is null
    and isnull(t.IS_ACPT_RETAIL, 0) = 1 
    and t.ACPT_RETAIL_DATE >= @DATE_BEGIN
    and doc.DM_DOC_TYPE_ID = 8
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
  group by t.DM_LOTS_ID

  -- Расходы-переоценки
  insert #t
  select t.DM_REPRICE_LOTS_ID, 0, sum(t.QUANTITY * t.MEASURE_FACTOR),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.QUANTITY * t.MEASURE_FACTOR else 0 end),
    0,
    sum(t.transfers_sum),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.transfers_sum else 0 end),
    0,
    sum(t.transfers_nds),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.transfers_nds else 0 end)
    from DM_DOC doc inner loop join DM_TRANSFERS t on t.DM_DOC_ID = doc.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=t.TRANSFER_WH_IN
    where R.PARENT_ID = @WH_ID
      and t.DM_REPRICE_LOTS_ID is not null
      and doc.DM_DOC_TYPE_ID = 9
      and isnull(t.IS_ACPT_RETAIL, 0) = 1 
      and  doc.ACCEPT_DATE  >= @DATE_BEGIN
      AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    group by t.DM_REPRICE_LOTS_ID

  -- Расходы-перемещения с переоценкой
  insert #t
  select t.DM_REPRICE_LOTS_ID, 0, sum(t.QUANTITY * t.MEASURE_FACTOR),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.QUANTITY * t.MEASURE_FACTOR else 0 end),
    0,
    sum(t.transfers_sum),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.transfers_sum else 0 end),
    0,
    sum(t.transfers_nds),
    sum(case when doc.ACCEPT_DATE >= @DATE_END then t.transfers_nds else 0 end)
    from DM_DOC doc inner loop join DM_TRANSFERS t on t.DM_DOC_ID = doc.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=t.TRANSFER_WH_OUT
    where R.PARENT_ID = @WH_ID
      and doc.DM_DOC_TYPE_ID = 4
      and t.DM_REPRICE_LOTS_ID is not null
      and isnull(t.IS_ACPT_RETAIL, 0) = 1 
      and  doc.ACCEPT_DATE  >= @DATE_BEGIN
      AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    group by t.DM_REPRICE_LOTS_ID

  create index idx_t on #t (DM_LOTS_ID)

  create table #whq (DM_LOTS_ID int, Q_BEG float, Q_END float, SUM_BEG float, SUM_END float, VAT_BEG float, VAT_END float)

  insert #whq
  SELECT DM_LOTS_ID, SUM(Q_WH + Q_BEG) Q_BEG, SUM(Q_WH + Q_END) Q_END, SUM(SUM_WH + SUM_BEG) SUM_BEG,
  SUM(SUM_WH + SUM_END) SUM_END, SUM(VAT_WH + VAT_BEG) VAT_BEG, SUM(VAT_WH + VAT_END) VAT_END
  FROM #t GROUP BY DM_LOTS_ID

  create table #mix_comp (DM_LOTS_ID int, DM_LOTS_MIXTURE_ID int, COEFF float, COEFF_SUM float, COEFF_NDS float)

  if @IS_MIXTURE_INCLUDE = 0
  begin
    create table #res (DM_LOTS_ID int, Q_BEG float, Q_END float, DM_LOTS_MIXTURE_ID int, COEFF float,
      SUM_BEG float, SUM_END float, VAT_BEG float, VAT_END float, COEFF_SUM float, COEFF_NDS float)

    /* Разбиение на компоненты */

    insert #res
    SELECT l.DM_LOTS_ID, w.Q_BEG * convert(float,t.QUANTITY) * t.MEASURE_FACTOR / (t_f.QUANTITY * t_f.MEASURE_FACTOR) Q_BEG,
    Q_END * convert(float,t.QUANTITY) * t.MEASURE_FACTOR / (t_f.QUANTITY * t_f.MEASURE_FACTOR) Q_END,
    w.dm_lots_id, convert(float,t.QUANTITY) * t.MEASURE_FACTOR / (t_f.QUANTITY * t_f.MEASURE_FACTOR),
    w.SUM_BEG * (case when abs(t_f.transfers_sum) > 1E-10 then t.transfers_sum/ t_f.transfers_sum else 0.0 end) SUM_BEG,
    w.SUM_END * (case when abs(t_f.transfers_sum) > 1E-10 then t.transfers_sum/ t_f.transfers_sum else 0.0 end) SUM_END,
    w.VAT_BEG * (case when abs(t_f.transfers_nds) > 1E-10 then t.transfers_nds/ t_f.transfers_nds else 0.0 end) VAT_BEG,
    w.VAT_END * (case when abs(t_f.transfers_nds) > 1E-10 then t.transfers_nds/ t_f.transfers_nds else 0.0 end) VAT_END,
    (case when abs(t_f.transfers_sum) > 1E-10 then t.transfers_sum/ t_f.transfers_sum else 0.0 end) COEFF_SUM,
    (case when abs(t_f.transfers_nds) > 1E-10 then t.transfers_nds/ t_f.transfers_nds else 0.0 end) COEFF_NDS
    FROM
      #whq w 
      JOIN dm_lots l_f WITH(NOLOCK) on l_f.dm_lots_id = w.dm_lots_id
      JOIN dm_meds m_f WITH(NOLOCK) on m_f.dm_meds_id = l_f.dm_meds_id and ISNULL(m_f.IS_MIXTURE, 0) = 1
  --    Закомментировано не совсем корректное связывание- как выяснилось DM_CREATE_TRANSFERS_ID у микстуры может указывать
  --      не на приход по производству, а на инвентаризацию, например. Возможно это баг конкретной базы.
  --    JOIN dm_transfers t_f WITH(NOLOCK) on t_f.dm_transfers_id = l_f.DM_CREATE_TRANSFERS_ID
      JOIN dm_transfers t_f WITH(NOLOCK) on t_f.dm_lots_id = l_f.dm_lots_id -- это правильно связывание (вместо предыдущей строки)
      JOIN dm_transfers t WITH(NOLOCK) on t.DM_FACTORING_TRANSFERS_ID = t_f.dm_transfers_id
      JOIN dm_lots l WITH(NOLOCK) on l.dm_lots_id = t.dm_lots_id
      JOIN dm_doc d_f on t_f.dm_doc_id=d_f.dm_doc_id and (d_f.dm_doc_type_id=12)
      JOIN dm_doc d on t.dm_doc_id=d.dm_doc_id and (d.dm_doc_type_id=13)
    UNION ALL
    SELECT l_f.DM_LOTS_ID, w.Q_BEG, w.Q_END, null, null, w.SUM_BEG, w.SUM_END, w.VAT_BEG, w.VAT_END, null, null
    FROM
      #whq w 
      JOIN dm_lots l_f WITH(NOLOCK) on l_f.dm_lots_id = w.dm_lots_id
      JOIN dm_meds m_f WITH(NOLOCK) on m_f.dm_meds_id = l_f.dm_meds_id and ISNULL(m_f.IS_MIXTURE, 0) = 0

    insert #mix_comp (DM_LOTS_ID, DM_LOTS_MIXTURE_ID, COEFF, COEFF_SUM, COEFF_NDS)
      select DM_LOTS_ID, DM_LOTS_MIXTURE_ID, COEFF, COEFF_SUM, COEFF_NDS from #res where not DM_LOTS_MIXTURE_ID is null

    /*
      Добавляем микстуры, для которых не нашлось компонентов.
      ВНИМАНИЕ ! ЭТО НЕШТАТНАЯ СИТУАЦИЯ !!!
    */
    insert #res
    SELECT l_f.DM_LOTS_ID, w.Q_BEG, w.Q_END, null, null, w.SUM_BEG, w.SUM_END, w.VAT_BEG, w.VAT_END, null, null
    FROM
      #whq w 
      JOIN dm_lots l_f WITH(NOLOCK) on l_f.dm_lots_id = w.dm_lots_id
      JOIN dm_meds m_f WITH(NOLOCK) on m_f.dm_meds_id = l_f.dm_meds_id and ISNULL(m_f.IS_MIXTURE, 0) = 1
    where not w.dm_lots_id in (select distinct DM_LOTS_MIXTURE_ID from #mix_comp)

    delete from #whq

    insert #whq
    SELECT DM_LOTS_ID, SUM(Q_BEG) Q_BEG, SUM(Q_END) Q_END,
      SUM(SUM_BEG) SUM_BEG, SUM(SUM_END) SUM_END,
      SUM(VAT_BEG) VAT_BEG, SUM(VAT_END) VAT_END
    FROM #res GROUP BY DM_LOTS_ID
  end

  create table #mv (dm_lots_id int, dm_doc_id int, dm_doc_type_id int, mv_type int, qty float, sum_tot float, vat float)

  if @is_rest_only = 0
  begin
    
    /* Описание типов документов */
    declare @mv_docs table (doc_type_id int, mv_tp int)
    
    insert @mv_docs values (1, 0) -- Приход от поставщика
    insert @mv_docs values (12, 0) -- приход по производству
    
    insert @mv_docs values (2, 1) -- Расход по акту списания
    insert @mv_docs values (6, 1) -- Возврат поставщику
    insert @mv_docs values (7, 1) -- Персонифицированная расходная накладная
    insert @mv_docs values (10, 1) -- Массовое списание на основании оказанных услуг
    insert @mv_docs values (11, 1) -- Персонифицированное списание на основании оказанных услуг
    insert @mv_docs values (13, 1) -- Акт списания в производство
    
    if @IS_MIXTURE_INCLUDE = 0
    begin
      /* Если микстуры исключены, то удаляем */
      delete @mv_docs where doc_type_id = 12 --  приход по производству
      delete @mv_docs where doc_type_id = 13 -- Акт списания в производство
    end
    
    /* Формирование движения*/
    /* Приход от поставщика (1), приход по производству (12)*/
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 2, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d  WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE R.PARENT_ID = @WH_ID AND d.DM_DOC_TYPE_ID IN (select doc_type_id from @mv_docs where mv_tp = 0)
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Приход- перемещения (входящие) (4) */
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 2, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_SOURCE_WH_ID
    WHERE d.DM_DOC_TYPE_ID = 4 AND R.PARENT_ID = @WH_ID
    AND (t.DM_REPRICE_LOTS_ID is NULL)
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN
      (SELECT COUNT(*) FROM DM_WH_TREE where CHILD_ID = d.DM_WAREHOUSES_ID and PARENT_ID = @WH_ID)
      WHEN R.RLENGTH = 0 THEN 0 ELSE 1 END) = 0)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Приход- перемещения с переоценкой (входящие) (4) */
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 2, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(l.INCOME_SUM), SUM(l.INCOME_NDS)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
    JOIN DM_LOTS l ON l.DM_LOTS_ID = t.DM_LOTS_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_SOURCE_WH_ID
    WHERE d.DM_DOC_TYPE_ID = 4 AND R.PARENT_ID = @WH_ID
    AND (t.DM_REPRICE_LOTS_ID is not NULL)
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN
      (SELECT COUNT(*) FROM DM_WH_TREE where CHILD_ID = d.DM_WAREHOUSES_ID and PARENT_ID = @WH_ID)
      WHEN R.RLENGTH = 0 THEN 0 ELSE 1 END) = 0)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Приход- переоценки (9) */
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 2, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(l.INCOME_SUM), SUM(l.INCOME_NDS)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
    JOIN DM_LOTS l ON l.DM_LOTS_ID = t.DM_LOTS_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_SOURCE_WH_ID
    WHERE d.DM_DOC_TYPE_ID = 9 AND R.PARENT_ID = @WH_ID
    AND (t.DM_REPRICE_LOTS_ID is not NULL)
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Приход- розница возврат (8)*/
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 2, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID = 8
    AND R.PARENT_ID = @WH_ID
    AND t.ACPT_RETAIL_DATE >= @DATE_BEGIN
    AND t.ACPT_RETAIL_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ISNULL(t.IS_ACPT_RETAIL, 0) = 1 AND ISNULL(t.RETAIL_ITEM_ID, 0) > 0
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Приход- инвентаризация (3)*/
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 2, SUM(ABS(t.LACK) * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID = 3
    AND R.PARENT_ID = @WH_ID
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND T.LACK > 0
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Расход- 
          Расход по акту списания (2)
          Возврат поставщику (6)
          Персонифицированная расходная накладная (7)
          Массовое списание на основании оказанных услуг (10)
          Персонифицированное списание на основании оказанных услуг (11)
          Акт списания в производство (13)
    */  
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 3, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d  WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID in (select doc_type_id from @mv_docs where mv_tp = 1) 
    AND R.PARENT_ID = @WH_ID
    AND (t.DM_REPRICE_LOTS_ID is NULL)
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Расход- Перемещение между подразделениями (4) */  
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 3, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d  WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID = 4
    AND R.PARENT_ID = @WH_ID
    AND (t.DM_REPRICE_LOTS_ID is NULL)
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN
      (SELECT COUNT(*) FROM DM_WH_TREE where CHILD_ID = d.DM_SOURCE_WH_ID and PARENT_ID = @WH_ID)
      WHEN R.RLENGTH = 0 THEN 0 ELSE 1 END) = 0)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Расход- розница (8)*/
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 3, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID = 8
    AND R.PARENT_ID = @WH_ID
    AND t.ACPT_RETAIL_DATE >= @DATE_BEGIN
    AND t.ACPT_RETAIL_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND ISNULL(t.IS_ACPT_RETAIL, 0) = 1 AND ISNULL(t.RETAIL_ITEM_ID, 0) = 0
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Расход- инвентаризация (3)*/
    INSERT #mv
    SELECT t.dm_lots_id, t.dm_doc_id, d.dm_doc_type_id, 3, SUM(ABS(t.LACK) * t.MEASURE_FACTOR),
    SUM(0- t.transfers_sum), SUM(0- t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID = 3
    AND R.PARENT_ID = @WH_ID
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND ISNULL(d.ACCEPTED, 0) = 1
    AND T.LACK < 0
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    
    /* Формирование движения*/
    /* Расход- Переоценки (9) */
    INSERT #mv
    SELECT t.DM_REPRICE_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id, 3, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID = 9 AND R.PARENT_ID = @WH_ID
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND (NOT t.DM_REPRICE_LOTS_ID IS NULL) AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN 1 WHEN R.RLENGTH = 0 THEN 1 ELSE 0 END) = 1)
    GROUP BY t.DM_REPRICE_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    /* Формирование движения*/
    /* Расход- Перемещения с переоценкой (исходящие) (4) */
    INSERT #mv
    SELECT t.DM_REPRICE_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id, 3, SUM(t.QUANTITY * t.MEASURE_FACTOR),
    SUM(t.transfers_sum), SUM(t.transfers_nds)
    FROM DM_TRANSFERS t JOIN DM_DOC d WITH(NOLOCK) ON D.DM_DOC_ID = t.DM_DOC_ID
      JOIN DM_WH_TREE R ON R.CHILD_ID=d.DM_WAREHOUSES_ID
    WHERE d.DM_DOC_TYPE_ID = 4 AND R.PARENT_ID = @WH_ID
    AND d.ACCEPT_DATE >= @DATE_BEGIN
    AND d.ACCEPT_DATE < @DATE_END
    AND (NOT t.DM_REPRICE_LOTS_ID IS NULL) AND ISNULL(d.ACCEPTED, 0) = 1
    AND ((CASE WHEN @IS_SUBWH_INCLUDE = 1 THEN
      (SELECT COUNT(*) FROM DM_WH_TREE where CHILD_ID = d.DM_SOURCE_WH_ID and PARENT_ID = @WH_ID)
      WHEN R.RLENGTH = 0 THEN 0 ELSE 1 END) = 0)
    GROUP BY t.DM_REPRICE_LOTS_ID, t.dm_doc_id, d.dm_doc_type_id
    
    if @IS_MIXTURE_INCLUDE = 0
    begin
/* Если микстуры исключены, то заменяем */
      insert #mv
        select c.dm_lots_id, v.dm_doc_id, v.dm_doc_type_id, v.mv_type, v.qty*c.coeff,
          v.sum_tot*c.coeff_sum,
          v.vat*c.coeff_nds
          from #mv v join #mix_comp c
          on v.dm_lots_id=c.dm_lots_mixture_id
          join dm_lots l on l.dm_lots_id=c.dm_lots_id
    
      delete #mv from #mv v join #mix_comp c
        on v.dm_lots_id=c.dm_lots_mixture_id
    end
    
  end

  if @IS_EMPTY_REMOVE = 1
  begin
    delete w from #whq w left join #mv t on w.dm_lots_id=t.dm_lots_id
      where t.dm_lots_id is null and abs(w.q_beg) < 0.00001 and abs(w.q_end) < 0.00001
  end

  create table #wh_report (
    id int NOT NULL IDENTITY (1, 1),
    dm_lots_id int,
    dm_meds_id int,
    dm_groups_id int,
    fm_source_fin_id int,
    dm_doc_id int,
    dm_doc_type_id int,
    mv_type int,
    quantity numeric(25,10),
    price numeric(25,10),
    vat numeric(25,10),
    sum_tot numeric(25,10),
    vat_tot numeric(25,10),
    dm_measure_id int,
    dflt_measure_id int,
    measure_factor numeric(20,10)
  )

  declare @gfld_mask int

  declare @lots_id_val varchar(50)
  declare @meds_id_val varchar(50)
  declare @groups_id_val varchar(50)
  declare @source_fin_val varchar(50)

  declare @group_clause_rest varchar(200)

  set @lots_id_val = 'NULL'
  set @meds_id_val = 'NULL'
  set @groups_id_val = 'NULL'
  set @source_fin_val = 'NULL'

  set @group_clause_rest = NULL

  /*
    Вычисление полей группировки для остатков
  */
  select @gfld_mask = sum(cmask) from @idx_fields

  if (@gfld_mask & @lots_id_mask) > 0
  begin
    select @lots_id_val = alias+ '.'+ fname from @idx_fields where cmask = @lots_id_mask
    set @group_clause_rest =
      case when @group_clause_rest is null then 'group by '+ @lots_id_val else @group_clause_rest+ ','+ @lots_id_val end
  end

  if (@gfld_mask & @meds_id_mask) > 0
  begin
    select @meds_id_val = alias+ '.'+ fname from @idx_fields where cmask = @meds_id_mask
    set @group_clause_rest =
      case when @group_clause_rest is null then 'group by '+ @meds_id_val else @group_clause_rest+ ','+ @meds_id_val end
  end

  if (@gfld_mask & @groups_id_mask) > 0
  begin
    select @groups_id_val = alias+ '.'+ fname from @idx_fields where cmask = @groups_id_mask
    set @group_clause_rest =
      case when @group_clause_rest is null then 'group by '+ @groups_id_val else @group_clause_rest+ ','+ @groups_id_val end
  end

  if (@gfld_mask & @source_fin_mask) > 0
  begin
    select @source_fin_val = alias+ '.'+ fname from @idx_fields where cmask = @source_fin_mask
    set @group_clause_rest =
      case when @group_clause_rest is null then 'group by '+ @source_fin_val else @group_clause_rest+ ','+ @source_fin_val end
  end

  /*
    Вычисление полей группировки для движения
  */
  declare @gfld_mask_mv int
  declare @group_clause_mv varchar(200)

  declare @lots_id_val_mv varchar(50)
  declare @meds_id_val_mv varchar(50)
  declare @groups_id_val_mv varchar(50)
  declare @source_fin_val_mv varchar(50)
  declare @doc_id_val_mv varchar(50)
  declare @doc_type_id_val_mv varchar(50)

  set @lots_id_val_mv = 'NULL'
  set @meds_id_val_mv = 'NULL'
  set @groups_id_val_mv = 'NULL'
  set @source_fin_val_mv = 'NULL'
  set @doc_id_val_mv = 'NULL'
  set @doc_type_id_val_mv = 'NULL'
  set @group_clause_mv = 'group by mv.mv_type'

  select @gfld_mask_mv = sum(cmask_mv) from @idx_fields

  if (@gfld_mask_mv & @lots_id_mask) > 0
  begin
    select @lots_id_val_mv = alias+ '.'+ fname from @idx_fields where cmask_mv = @lots_id_mask
    set @group_clause_mv = @group_clause_mv+ ','+ @lots_id_val_mv
  end

  if (@gfld_mask_mv & @meds_id_mask) > 0
  begin
    select @meds_id_val_mv = alias+ '.'+ fname from @idx_fields where cmask_mv = @meds_id_mask
    set @group_clause_mv = @group_clause_mv+ ','+ @meds_id_val_mv
  end

  if (@gfld_mask_mv & @groups_id_mask) > 0
  begin
    select @groups_id_val_mv = alias+ '.'+ fname from @idx_fields where cmask_mv = @groups_id_mask
    set @group_clause_mv = @group_clause_mv+ ','+ @groups_id_val_mv
  end

  if (@gfld_mask_mv & @source_fin_mask) > 0
  begin
    select @source_fin_val_mv = alias+ '.'+ fname from @idx_fields where cmask_mv = @source_fin_mask
    set @group_clause_mv = @group_clause_mv+ ','+ @source_fin_val_mv
  end

  if (@gfld_mask_mv & @doc_id_mask) > 0
  begin
    select @doc_id_val_mv = alias+ '.'+ fname from @idx_fields where cmask_mv = @doc_id_mask
    set @group_clause_mv = @group_clause_mv+ ','+ @doc_id_val_mv
  end

  if (@gfld_mask_mv & @doc_type_id_mask) > 0
  begin
    select @doc_type_id_val_mv = alias+ '.'+ fname from @idx_fields where cmask_mv = @doc_type_id_mask
    set @group_clause_mv = @group_clause_mv+ ','+ @doc_type_id_val_mv
  end

  declare @sql_str nvarchar(4000)

  set @sql_str = 'insert #wh_report (dm_lots_id,dm_meds_id,dm_groups_id,fm_source_fin_id,mv_type,quantity,sum_tot,vat_tot) select '+
  @lots_id_val+ ','+ @meds_id_val+ ','+@groups_id_val+ ','+@source_fin_val+ ','+
  '0, sum(w.q_beg), sum(w.sum_beg), sum(w.vat_beg) from #whq w '+
  'join dm_lots l on w.dm_lots_id=l.dm_lots_id '+
  'join dm_meds m on l.dm_meds_id=m.dm_meds_id '+
  'join dm_groups g on g.dm_groups_id=m.dm_groups_id '+
  'left join fm_source_fin f on f.fm_source_fin_id=l.fm_source_fin_id '+
  'left join dm_transfers t on l.dm_create_transfers_id=t.dm_transfers_id '+ coalesce(@group_clause_rest, '')
  exec sp_executesql @sql_str

  if @is_rest_only = 0
  begin
    set @sql_str = 'insert #wh_report (dm_lots_id,dm_meds_id,dm_groups_id,fm_source_fin_id,mv_type,quantity,sum_tot,vat_tot) select '+
    @lots_id_val+ ','+ @meds_id_val+ ','+@groups_id_val+ ','+@source_fin_val+ ','+
    '1, sum(w.q_end), sum(w.sum_end), sum(w.vat_end) from #whq w '+
    'join dm_lots l on w.dm_lots_id=l.dm_lots_id '+
    'join dm_meds m on l.dm_meds_id=m.dm_meds_id '+
    'join dm_groups g on g.dm_groups_id=m.dm_groups_id '+
    'left join fm_source_fin f on f.fm_source_fin_id=l.fm_source_fin_id '+
    'left join dm_transfers t on l.dm_create_transfers_id=t.dm_transfers_id '+ coalesce(@group_clause_rest, '')
    exec sp_executesql @sql_str
    
    set @sql_str = 'insert #wh_report (dm_lots_id,dm_meds_id,dm_groups_id,fm_source_fin_id,dm_doc_id,dm_doc_type_id,'+
    'mv_type,quantity,sum_tot,vat_tot) select '+
    @lots_id_val_mv+ ','+ @meds_id_val_mv+ ','+@groups_id_val_mv+ ','+@source_fin_val_mv
    + ','+@doc_id_val_mv+ ','+@doc_type_id_val_mv+ ','+
    'mv.mv_type, sum(mv.qty), sum(mv.sum_tot), sum(mv.vat) from #mv mv '+
    'join dm_lots l on mv.dm_lots_id=l.dm_lots_id '+
    'join dm_meds m on l.dm_meds_id=m.dm_meds_id '+
    'join dm_groups g on g.dm_groups_id=m.dm_groups_id '+
    'left join fm_source_fin f on f.fm_source_fin_id=l.fm_source_fin_id '+
    'left join dm_transfers t on l.dm_create_transfers_id=t.dm_transfers_id '+ @group_clause_mv
    exec sp_executesql @sql_str
  end

  if ((@gfld_mask & @lots_id_mask) > 0) or ((@gfld_mask_mv & @lots_id_mask) > 0)
  begin
    update w set 
      price=l.dev_price, vat=l.dev_price*f.TAXE_PERC/(100+f.TAXE_PERC) from #wh_report w
      join dm_lots l on w.dm_lots_id=l.dm_lots_id
      join FM_TAXE_DET f on l.FM_TAXE_DET_IN_ID = f.FM_TAXE_DET_ID

    update w set 
        dm_measure_id = coalesce(t.dm_measure_id, m.dm_measure_id),
        dflt_measure_id = m.dm_measure_id,
        measure_factor = coalesce(t.measure_factor, 1.0) from #wh_report w
      join dm_lots l on w.dm_lots_id=l.dm_lots_id
      join dm_meds m on l.dm_meds_id=m.dm_meds_id
      left join dm_transfers t on l.dm_create_transfers_id=t.dm_transfers_id
  end
  else
    if ((@gfld_mask & @meds_id_mask) > 0) or ((@gfld_mask_mv & @meds_id_mask) > 0)
    begin
      update r set 
        dm_measure_id = m.dm_measure_id, dflt_measure_id = coalesce(s.dm_measure_id, m.dm_measure_id),
        measure_factor = coalesce(s.meds_measure_factor/s.measure_factor, 1.0)
      FROM #wh_report r
      join dm_meds m on r.dm_meds_id=m.dm_meds_id
      left join dm_meds_measures s on m.dm_meds_id=s.dm_meds_id
      and s.is_default=1
    end

  declare @tot_rows int
  declare @tmp_id int

  select @tot_rows = count(*) from #wh_report

  if @CLEAR_RESULT = 1
  begin
    delete from tmp_warehouse_report where session_id = @@SPID
  end

  alter table tmp_warehouse_report disable trigger all

  EXEC up_get_id 'tmp_warehouse_report', @tot_rows, @tmp_id OUTPUT

  set @DATE_END = @date_end_bkp

  insert tmp_warehouse_report (TMP_WAREHOUSE_REPORT, DM_LOTS_ID, DM_MEDS_ID, DM_GROUPS_ID, FM_SOURCE_FIN_ID, DM_DOC_ID,
    DM_DOC_TYPE_ID, DM_WAREHOUSES_ID, MV_TYPE, QUANTITY, PRICE, VAT, SUM_TOT, VAT_TOT, DM_MEASURE_ID, DFLT_MEASURE_ID,
    MEASURE_FACTOR, FIRST_DATE, LAST_DATE, SESSION_ID)
    select 
      id- 1+ @tmp_id, dm_lots_id, dm_meds_id, dm_groups_id, fm_source_fin_id, dm_doc_id,
      dm_doc_type_id, @WH_ID, mv_type, isnull(quantity, 0.0), price, vat, isnull(sum_tot, 0.0), isnull(vat_tot, 0.0),
      dm_measure_id, dflt_measure_id, measure_factor, @DATE_BEGIN, @DATE_END, @@SPID 
    from #wh_report

  alter table tmp_warehouse_report enable trigger all

  if object_id('tempdb..#t') IS NOT NULL
  begin
    drop table #t
  end
  if object_id('tempdb..#whq') IS NOT NULL
  begin
    drop table #whq
  end
  if object_id('tempdb..#mix_comp') IS NOT NULL
  begin
    drop table #mix_comp
  end
  if object_id('tempdb..#res') IS NOT NULL
  begin
    drop table #res
  end
  if object_id('tempdb..#mv') IS NOT NULL
  begin
    drop table #mv
  end
  if object_id('tempdb..#wh_report') IS NOT NULL
  begin
    drop table #wh_report
  end

END
go

