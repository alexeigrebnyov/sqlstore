


CREATE procedure [dbo].[dm_contr_check_allow_update_balance] (
    @DM_CONTRACTS_ID int,
    @ERRMSG  varchar(255) output
    )
as
begin
--800249
--751325_R_209
    set nocount on;
    set @ERRMSG = '';
    
    declare
        @CONTRACTS_USER_STATE        bit;

    select @CONTRACTS_USER_STATE = CONTRACTS_USER_STATE from DM_CONTRACTS where DM_CONTRACTS_ID = @DM_CONTRACTS_ID;

    if @CONTRACTS_USER_STATE = 1 
    begin
        set @ERRMSG = 'dm_contr_check_allow_update_balance_error_01 [' + cast(@DM_CONTRACTS_ID as varchar) + ']';

        return;
    end
end
go

