

create procedure [dbo].[dm_contr_update_balance_sf_contr] (
    @DM_CONTRACTS_ID        int,
    @MAIN_CONTR_ID          int)
as
begin
--800082
--750995
    set nocount on;
    
    declare
        @DM_CONTR_SOURCE_FIN_ID         int,
        @FM_SOURCE_FIN_ID               int,
        @PRC                            numeric(5,2),
        @SUM_CONTR_TOTAL                numeric(20,10),
        @DM_CONTR_SOURCE_FIN_STATE_ID   int,
        @IS_ACTUAL_VER                  bit

    if @DM_CONTRACTS_ID = @MAIN_CONTR_ID -- MAIN_CONTRACT
    begin
        -- Выбираем данные: актуальные позиции контракта и доп.соглашений
        declare CUR cursor local forward_only static for
            select IS_ACTUAL_VER, DM_CONTR_SOURCE_FIN_ID, FM_SOURCE_FIN_ID, PRC, SUM_CONTR
              from DM_CONTR_SOURCE_FIN d
              where 
                    d.DM_CONTRACTS_ID = @DM_CONTRACTS_ID
    end
    else -- ADD_CONTRACT
    begin
        --  Ставшие неактуальными позиции первичного контракта либо ДС по self.DM_CONTRACTS_ID <- удаленные(неактуальные).DELETED_CONTR_ID
        declare CUR cursor local forward_only static for        
            select IS_ACTUAL_VER, DM_CONTR_SOURCE_FIN_ID, FM_SOURCE_FIN_ID, PRC, SUM_CONTR
              from DM_CONTR_SOURCE_FIN d
             where 
                   d.DELETED_CONTR_ID = @DM_CONTRACTS_ID
            union --Актуальные позиции ДС
            select IS_ACTUAL_VER, DM_CONTR_SOURCE_FIN_ID, FM_SOURCE_FIN_ID, PRC, SUM_CONTR
              from DM_CONTR_SOURCE_FIN d
              where
                    d.DM_CONTRACTS_ID = @DM_CONTRACTS_ID
                and DELETION = 0
            order by 1 -- IS_ACTIAL_VER=0 впереди
    end


    open CUR
    while 1 > 0
    begin
        fetch next from CUR into @IS_ACTUAL_VER, @DM_CONTR_SOURCE_FIN_ID, @FM_SOURCE_FIN_ID, @PRC, @SUM_CONTR_TOTAL
        if @@FETCH_STATUS <> 0 break
        
        -- Обновляем строку баланса
        exec dbo.dm_contr_update_balance_sf_row
            0,          -- @DM_DOC_TYPE_ID int 0=CONTRACT
            @IS_ACTUAL_VER,
            @MAIN_CONTR_ID,
            @FM_SOURCE_FIN_ID,
            @PRC,
            @SUM_CONTR_TOTAL,
            0,0,
            @DM_CONTR_SOURCE_FIN_STATE_ID output
        
        -- Обновляем ссылку на позицию баланса
        update DM_CONTR_SOURCE_FIN
           set 
               DM_CONTR_SOURCE_FIN_STATE_ID = @DM_CONTR_SOURCE_FIN_STATE_ID
         where
               DM_CONTR_SOURCE_FIN_ID = @DM_CONTR_SOURCE_FIN_ID
    end
    close CUR
    deallocate CUR
end
go

