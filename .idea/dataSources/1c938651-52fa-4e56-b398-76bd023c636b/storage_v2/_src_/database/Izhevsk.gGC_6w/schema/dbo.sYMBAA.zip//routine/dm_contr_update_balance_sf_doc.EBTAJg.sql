

create procedure [dbo].[dm_contr_update_balance_sf_doc] (
    @DM_DOC_ID          int,
    @DM_DOC_TYPE_ID     int, -- 1=dtSupIncome, 6=dtSupReturn
    @DM_CONTRACTS_ID    int,
    @ACCEPT             bit)
as
begin
--800082
--750995
    set nocount on;

    if @DM_DOC_TYPE_ID not in (1,6)
        return
    
    declare
        @DM_TRANSFERS_ID                int,
        @TRANSFERS_SUM                  numeric(20,10),        
        @FM_SOURCE_FIN_ID               int,
        @SUM_SUP_INC                    numeric(20,10),
        @SUM_SUP_RET                    numeric(20,10),
        @DM_CONTR_SOURCE_FIN_STATE_ID   int

    
    -- Выбираем данные: позиции документа
    declare CUR cursor local forward_only static for
        select t.DM_TRANSFERS_ID, l.FM_SOURCE_FIN_ID, t.TRANSFERS_SUM 
          from DM_TRANSFERS t
          join      DM_LOTS l on t.DM_LOTS_ID = l.DM_LOTS_ID
         where
               t.DM_DOC_ID = @DM_DOC_ID

    open CUR
    while 1 > 0
    begin
        fetch next from CUR into @DM_TRANSFERS_ID, @FM_SOURCE_FIN_ID, @TRANSFERS_SUM
        if @@FETCH_STATUS <> 0 break

        if @DM_DOC_TYPE_ID = 1 -- dtSupIncome
        begin
            set @SUM_SUP_INC = @TRANSFERS_SUM
            set @SUM_SUP_RET = 0
        end
        else -- dtSupReturn
        begin
            set @SUM_SUP_INC = 0
            set @SUM_SUP_RET = @TRANSFERS_SUM
        end
        
        -- Обновляем строку баланса
        exec dbo.dm_contr_update_balance_sf_row
            @DM_DOC_TYPE_ID,
            @ACCEPT,
            @DM_CONTRACTS_ID,
            @FM_SOURCE_FIN_ID,
            0, 0,
            @SUM_SUP_INC, @SUM_SUP_RET,
            @DM_CONTR_SOURCE_FIN_STATE_ID output
        
        -- Обновляем ссылку на позицию баланса
        update DM_TRANSFERS
           set 
               DM_CONTR_SOURCE_FIN_STATE_ID = @DM_CONTR_SOURCE_FIN_STATE_ID
         where
               DM_TRANSFERS_ID = @DM_TRANSFERS_ID
    end
    close CUR
    deallocate CUR
end
go

