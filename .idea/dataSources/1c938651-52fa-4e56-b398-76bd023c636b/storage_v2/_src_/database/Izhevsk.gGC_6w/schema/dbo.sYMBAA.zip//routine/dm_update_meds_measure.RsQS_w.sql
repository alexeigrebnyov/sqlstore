CREATE procedure [dbo].[dm_update_meds_measure](@dm_meds_id int, @new_meas_id int)
as
begin
--800139
--751047
  declare
    @errmes varchar(1000),
    @old_measure_id int,
    @new_meds_measure_factor numeric(20, 6),
    @new_measure_factor numeric(20, 6),
    @is_internal_tran bit

  set @is_internal_tran = 0
  if @@trancount = 0
  begin
    set @is_internal_tran = 1
    begin tran
  end

  select @old_measure_id = dm_measure_id from dm_meds where dm_meds_id = @dm_meds_id

  if @@rowcount = 0
  begin
    set @errmes = '{C6370FA8-22A9-4011-84EA-AFDDD2760875} - Product was not found.'
    goto err
  end

  select
    @new_meds_measure_factor = measure_factor,
    @new_measure_factor = meds_measure_factor 
  from dm_meds_measures
  where dm_meds_id = @dm_meds_id and dm_measure_id = @new_meas_id

  if @@rowcount = 0
  begin
    set @errmes = '{4885F4C0-1CAC-4A24-9A7C-577B44FB28A6} - New measure was not found.'
    goto err
  end

  if (@old_measure_id = @new_meas_id)
  begin
    set @new_meds_measure_factor = 1.0
    set @new_measure_factor = 1.0
  end

  /*
    Запоминаем ед. изм. по умолчанию
  */
  declare @def_meas_id int
  set @def_meas_id = null
  select @def_meas_id = isnull(dm_meds_measures.dm_measure_id, dm_meds.dm_measure_id)
  from dm_meds left outer join dm_meds_measures on dm_meds_measures.dm_meds_id = dm_meds.dm_meds_id and isnull(dm_meds_measures.is_default, 0) = 1
  where dm_meds.dm_meds_id = @dm_meds_id

  /* обновляем учетную единицу измерения товара  */
  update dm_meds set dm_measure_id = @new_meas_id where dm_meds_id = @dm_meds_id

  /* обновляем отношения (measure_factor) для ед.измерения товара  */
  /* добавляем в dm_meds_measures старую учетную единицу (если ее там еще нет) */
  if not exists(select dm_measure_id from dm_meds_measures where dm_meds_id = @dm_meds_id and dm_measure_id = @old_measure_id)
  begin
    declare @dm_meds_measures_id int

    exec dbo.up_get_id 'dm_meds_measures', 1, @dm_meds_measures_id output
    insert dm_meds_measures (dm_meds_measures_id, dm_meds_id, dm_measure_id, measure_factor, is_default, meds_measure_factor)
      values (@dm_meds_measures_id, @dm_meds_id, @old_measure_id, 1, 0, 1)
  end
  else
  begin
  /* А если есть, то это ошибка, которую исправляем */
    update dm_meds_measures set measure_factor=1.0, is_default=0, meds_measure_factor=1.0
      where dm_meds_id = @dm_meds_id and dm_measure_id = @old_measure_id
  end

  update dm_meds_measures set is_default = 0 where dm_meds_id = @dm_meds_id
  update dm_meds_measures set is_default = 1 where dm_meds_id = @dm_meds_id and dm_measure_id = @def_meas_id

  /* удаляем новую уч.единицу из списка алтернативных единиц товара */
  delete dm_meds_measures where dm_meds_id = @dm_meds_id and dm_measure_id = @new_meas_id

  if (@new_meds_measure_factor <> 1.0) or (@new_measure_factor <> 1.0)
  begin

    /* пересчитываем коэффициент для затраты, если товар включен в затрату */
      declare @dm_costs_id int
      select @dm_costs_id = dm_costs_id from dm_meds where dm_meds_id = @dm_meds_id
      if not (@dm_costs_id is null)
      begin
        update dm_meds set cost_pack = cost_pack * @new_meds_measure_factor/ @new_measure_factor where dm_meds_id = @dm_meds_id
      end

    /* прописываем для всех единиц в dm_meds_measures новый measure_factor и meds_measure_factor */
    update dm_meds_measures
      set meds_measure_factor = @new_meds_measure_factor * meds_measure_factor,
        measure_factor = @new_measure_factor * measure_factor
    where dm_meds_id = @dm_meds_id

    /* нормализуем значения measure_factor, предварительно вычисляя НОД */
    declare @gcd table (dm_meds_measures_id int, gcd numeric(20,6))
    insert @gcd select dm_meds_measures_id, [dbo].[CalcGCD](meds_measure_factor, measure_factor)
      from dm_meds_measures
      where dm_meds_id = @dm_meds_id

    update dm_meds_measures
      set meds_measure_factor = s.meds_measure_factor / g.gcd,
        measure_factor = s.measure_factor / g.gcd
    from dm_meds_measures s join @gcd g on s.dm_meds_measures_id = g.dm_meds_measures_id

    /* проверяем, не получилась ли где периодическая дробь */
    declare @err_measure varchar(254)
    set @err_measure = NULL
    select top 1 @err_measure = convert(varchar(254), ltrim(str(s.measure_factor,20,3))+
    ' '+ s0.label+ ' = '+ ltrim(str(s.meds_measure_factor,20,3))+' '+ s1.label+
    ' ('+ ltrim(str(s.measure_factor/s.meds_measure_factor,20,10))+ ').') from dm_meds m
      join dm_meds_measures s on m.dm_meds_id=s.dm_meds_id
      join dm_measure s1 on s.dm_measure_id=s1.dm_measure_id
      join dm_measure s0 on m.dm_measure_id=s0.dm_measure_id
    where m.dm_meds_id=@dm_meds_id 
      and dbo.accIsPeriodic(s.measure_factor, s.meds_measure_factor)=1 -- недопустимая единица
      

    if not (@err_measure is NULL)
    begin
      set @errmes = '{00BA0905-08EB-431B-936A-F4307E772E43}%%s'+ @err_measure
      goto err
    end
  
    /* пересчитываем партии */
    alter table dm_lots disable trigger all
    update dm_lots set
      price = l.price * @new_meds_measure_factor/ @new_measure_factor,
      dev_price = l.dev_price * @new_meds_measure_factor/ @new_measure_factor,
      sale_sum = l.sale_sum * @new_meds_measure_factor/ @new_measure_factor,
      income_mf = @new_measure_factor / @new_meds_measure_factor
    from dm_lots l left outer join dm_transfers t on t.dm_transfers_id = l.dm_create_transfers_id
    where l.dm_meds_id = @dm_meds_id
    alter table dm_lots enable trigger all
  
    /* пересчитываем мин.остатки на складах */
    update dm_med_backlog set quantity = quantity * @new_measure_factor/ @new_meds_measure_factor
    where dm_meds_id = @dm_meds_id
  
    /* пересчитываем документы */
    alter table dm_transfers disable trigger all
    update dm_transfers set
        measure_factor = mm.measure_factor / mm.meds_measure_factor,
        price = t.price * @new_meds_measure_factor/ @new_measure_factor,
        sum_nds = t.sum_nds * @new_meds_measure_factor/ @new_measure_factor,
        nds_in_money = t.nds_in_money * @new_meds_measure_factor/ @new_measure_factor,
        sum_wout_nds = t.sum_wout_nds * @new_meds_measure_factor/ @new_measure_factor,
        sale_sum = t.sale_sum * @new_meds_measure_factor/ @new_measure_factor
    from dm_transfers t join dm_lots l on l.dm_lots_id = t.dm_lots_id
    join dm_meds_measures mm on mm.dm_meds_id = l.dm_meds_id  and mm.dm_measure_id = t.dm_measure_id
    where l.dm_meds_id = @dm_meds_id
  
    update dm_transfers set
        measure_factor = 1.0,
        price = t.price * @new_meds_measure_factor/ @new_measure_factor,
        sum_nds = t.sum_nds * @new_meds_measure_factor/ @new_measure_factor,
        nds_in_money = t.nds_in_money * @new_meds_measure_factor/ @new_measure_factor,
        sum_wout_nds = t.sum_wout_nds * @new_meds_measure_factor/ @new_measure_factor,
        sale_sum = t.sale_sum * @new_meds_measure_factor/ @new_measure_factor
    from dm_transfers t join dm_lots l on l.dm_lots_id = t.dm_lots_id
    where l.dm_meds_id = @dm_meds_id and t.dm_measure_id=@new_meas_id
    alter table dm_transfers enable trigger all
  
    /* пересчитываем заказы - требования */
    alter table dm_dem_goods disable trigger all
    update dm_dem_goods set
        measure_factor = mm.measure_factor / mm.meds_measure_factor,
        price = dg.price * @new_meds_measure_factor/ @new_measure_factor
    from dm_dem_goods dg
      join dm_meds_measures mm on mm.dm_meds_id = dg.dm_meds_id and mm.dm_measure_id = dg.dm_measure_id
    where dg.dm_meds_id = @dm_meds_id
  
    update dm_dem_goods set
        measure_factor = 1.0,
        price = dg.price * @new_meds_measure_factor/ @new_measure_factor
    from dm_dem_goods dg
    where dg.dm_meds_id = @dm_meds_id and dg.dm_measure_id=@new_meas_id
    alter table dm_dem_goods enable trigger all
  
    /* пересчитываем неподтвержденный расход и остатки на складах */
    alter table dm_warehouse disable trigger all
  
    update dm_warehouse set
    quantity = wh.quantity * @new_measure_factor / @new_meds_measure_factor,
    unconfirmed_expense = wh.unconfirmed_expense * @new_measure_factor / @new_meds_measure_factor
    from dm_warehouse wh join dm_lots l on l.dm_lots_id = wh.dm_lots_id
    where l.dm_meds_id = @dm_meds_id
  
    alter table dm_warehouse enable trigger all
  end
  if @is_internal_tran = 1 commit
  goto ret

err:
  raiserror (@errmes, 16, 1)
  if @is_internal_tran = 1 rollback tran

ret:
end
go

