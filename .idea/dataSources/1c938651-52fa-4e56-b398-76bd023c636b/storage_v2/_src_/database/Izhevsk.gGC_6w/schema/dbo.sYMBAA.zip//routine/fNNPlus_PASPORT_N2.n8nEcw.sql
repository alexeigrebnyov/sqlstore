CREATE FUNCTION [dbo].[fNNPlus_PASPORT_N2]
(
	@PatientID int = 0
)
RETURNS varchar(250)
AS BEGIN

RETURN
	(
		SELECT 
			CASE
				WHEN ISNULL(KEM_V_DAN,'')<>'' THEN ' Кем выдан: '+KEM_V_DAN+',' ELSE ''
			END	+
			CASE
				WHEN ISNULL(KOGDA_V_DAN,'')<>'' THEN ' Когда выдан: '+convert(nvarchar(255),KOGDA_V_DAN,104)+',' ELSE ''
			END	

		FROM PATIENTS
		WHERE
			PATIENTS_ID = @PatientID 
	)
END
go

