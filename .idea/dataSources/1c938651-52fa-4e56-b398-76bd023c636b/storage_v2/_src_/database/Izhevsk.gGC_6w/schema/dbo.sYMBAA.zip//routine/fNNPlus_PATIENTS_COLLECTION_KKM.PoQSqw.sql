/*Вахитов Рифнур Райнурович 06.12.2021
Подсчитываем сумму инкассации через кассу по ККМ */

CREATE FUNCTION [dbo].[fNNPlus_PATIENTS_COLLECTION_KKM]
(
	@Date date,
	@fm_org_id int,
	@kkm varchar(20)
)
RETURNS money
AS BEGIN
declare @kkmint int
	set @kkmint = (case when @kkm='Касса 1' then 1 when @kkm='Касса 2' then 2 when @kkm='Касса 3' then 3 end)

RETURN
	(
  SELECT isnull(SUM(SUMMA),0)
  FROM SPR_TRAN_KASSA
  Where FM_ORG_ID=@fm_org_id and dbo.date(DATE_TRAN)=dbo.date(@Date) and PRICHINA in (0) and SPR_KKM_ID= @kkmint		
	)
END


go

