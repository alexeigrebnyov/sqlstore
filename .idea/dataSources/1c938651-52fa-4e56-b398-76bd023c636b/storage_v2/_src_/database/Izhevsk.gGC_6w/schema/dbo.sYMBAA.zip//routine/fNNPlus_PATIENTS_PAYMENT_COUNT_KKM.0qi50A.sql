/*Вахитов Рифнур Райнурович 03.02.2021
Проверяем наличие записей в текщем филиале в таблицеSPR_TRAN_KASSA */

CREATE FUNCTION [dbo].[fNNPlus_PATIENTS_PAYMENT_COUNT_KKM]
(
	@Date date,
	@fm_org_id int,
	@kkm int
)
RETURNS int
AS BEGIN

RETURN
	(
  SELECT COUNT(SPR_TRAN_KASSA_ID)
  FROM SPR_TRAN_KASSA
  Where FM_ORG_ID=@fm_org_id and dbo.date(DATE_TRAN)=dbo.date(@Date) and spr_KKM_ID =@kkm	
	)
END


go

