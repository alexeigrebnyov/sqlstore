/*Вахитов Рифнур Райнуровия 17.12.2020*/
CREATE FUNCTION [dbo].[fNNPlus_Trimestr_VB]
(
	@PatientsID int = 0,
	@Date date
)
RETURNS int
AS BEGIN

RETURN
	(
	select count(PATIENTS_ID) from FM_CLINK_PATIENTS where Patients_id=@PatientsID
and dbo.date(@Date) between DATE_FROM and DATE_TO
and FM_CLINK_ID in (205,206,207,208,209,210,211,212,213,214,215,1348,1349,1347,1350,13251,1352,1353,1354,1355,1356,1357)
		--select top 1 convert (varchar(10),m.DATE_CONSULTATION ,104)
		--from motconsu m 
		--where m.PATIENTS_id=@PatientsID and 	
		--		dbo.date(m.DATE_CONSULTATION) between dateadd(day,1,dbo.date(@Date)) and 
		--		dateadd(MONTH,6,dbo.date(@Date)) and m.models_id in(@modelsID)
		--		order by 1 asc
		
	)
END


go

