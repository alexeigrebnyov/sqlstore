--select dbo.[fnAccountRemain](104795,101)
CREATE function [dbo].[fnAccountRemainNN](
  @FM_ACCOUNT_ID int,
  @FILIAL_ID int
)
returns money  
as
begin
  declare
    @ret money
    
  set @FILIAL_ID = nullif(@FILIAL_ID, 0)
  
  if exists( select 1
               from FM_PARAMS with (nolock) 
               where PRM_NAME = 'CALC_REMAIN_USING_FILIAL'
                 and PRM_VALUE = '0')
  begin               
   
    select @ret = sum(Z.TRAN_SUM)
      from
      (
        select TRAN_SUM = max(T.TRAN_SUM) + isnull(sum(T2.TRAN_SUM), 0)
          from dbo.FM_ACCOUNT_TRAN T with(nolock, index(idxACCOUNT_TYPE_DEP))
          left join FM_DEP D with (nolock, index(PK_FM_DEP))
             on D.FM_DEP_ID = T.FM_DEP_ID
          left join dbo.FM_ACCOUNT_TRAN T2 with (nolock, index(idxFM_MAIN_TRAN_ID))
             on T2.FM_MAIN_TRAN_ID = T.FM_ACCOUNT_TRAN_ID
          where T.FM_ACCOUNT_ID = @FM_ACCOUNT_ID  
            and T.TRAN_TYPE in ('A','X')  
            and (T.WRITTEN_OFF = 0 or T.WRITTEN_OFF is null)
            and (D.MAIN_ORG_ID = @FILIAL_ID or D.MAIN_ORG_ID is null or @FILIAL_ID is null)  
          group by T.FM_ACCOUNT_TRAN_ID  
      ) Z    
      option (force order, maxdop 1, loop join)
  end
  else
  begin
    select @ret = sum(T.TRAN_SUM)
      from dbo.FM_ACCOUNT_TRAN T with(nolock, index(idxACCOUNT_TYPE_DEP))
      where T.FM_ACCOUNT_ID = @FM_ACCOUNT_ID  
  end 
    
  return isnull(@ret, 0)  
end
go

