

CREATE PROCEDURE [dbo].[fnAfterPayingCustom]
	@FM_ACC_CHECK_IDs varchar(max)
AS
BEGIN
	SET NOCOUNT ON;
	declare @err_mess varchar(2048)
	begin try
		begin tran
--------------------------------------------------------------------

--------------------------------------------------------------------
		commit tran
	end try
	begin catch
		select 
			@err_mess = 
			'Error ' + convert(varchar(10) , ERROR_NUMBER()) + 
			', Procedure ' + ISNULL(ERROR_PROCEDURE(), '-') +
			', Line ' + convert(varchar(100) , ERROR_LINE()) + 
			', Message: '+ ERROR_MESSAGE()      
		if @@trancount > 0
			rollback tran  
		raiserror(@err_mess, 16, 10)  
	end catch  
END
go

