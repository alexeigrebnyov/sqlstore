create procedure dbo.getPatDirAnsw @Tasks varchar(max)
as
declare @St varchar(300)
/*declare @Tasks varchar(max)
select
	@Tasks=	'2712285'
*/
select Data as PATDIREC_ID
into #Tasks
from dbo.Split(@Tasks, ',')
--select * from #Tasks

select * 
from (
	select TASK.PATDIREC_ID, CAST(case when ISNULL(TASK.BIO_CODE, '') <> '' then 1
		else ISNULL((select 1
			from DIR_ANSW DA_TASK (nolock)
			where TASK.PATDIREC_ID = DA_TASK.PATDIREC_ID
				and not (DA_TASK.MOTCONSU_RESP_ID is null and DA_TASK.FM_BILL_ID is null)
			group by DA_TASK.PATDIREC_ID), 0)
		end as BIT) PROCESSING
	from PATDIREC TASK (nolock)
	inner join #Tasks t on TASK.PATDIREC_ID=convert(int, t.PATDIREC_ID)
) a
where a.PROCESSING=1
go

