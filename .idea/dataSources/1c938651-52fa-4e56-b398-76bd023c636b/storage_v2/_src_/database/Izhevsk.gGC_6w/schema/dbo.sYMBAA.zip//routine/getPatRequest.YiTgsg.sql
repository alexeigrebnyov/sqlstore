create procedure dbo.getPatRequest @Requests varchar(max), @Tasks varchar(max)
as
declare @St varchar(300)
/*select
	@Requests=	'2712388,2712311',
	@Tasks=		'2712396,2712393'
*/
select Data as PATDIREC_ID
into #Requests
from dbo.Split(@Requests, ',')
--select * from #Requests

select Data as PATDIREC_ID
into #Tasks
from dbo.Split(@Tasks, ',')
--select * from #Tasks

-- Выделенные на удаление задания связанны с не выделенными требованиями
select p2.TASK_ID, p.PATDIREC_ID
from dbo.PATDIREC p with (nolock) 
inner join (
	-- Связанные Требования по Заданию
	select s2.PATDIREC_ID REQUEST_ID, t.PATDIREC_ID TASK_ID
	from dbo.dir_serv s with (nolock)
	inner join dbo.dir_serv s2 with (nolock) on s2.DIR_SERV_TASK_ID=s.DIR_SERV_ID
	inner join #Tasks t on s.PATDIREC_id=convert(int, t.PATDIREC_ID)
	group by s2.PATDIREC_ID, t.PATDIREC_ID
) p2 on p.PATDIREC_ID=p2.REQUEST_ID
  and p.IS_REQUEST=1
left join #Requests r on p.PATDIREC_id=convert(int, r.PATDIREC_ID)
where
	r.PATDIREC_ID is null
go

