create function [dbo].[intlist_to_table] (@list ntext)                   
returns @tbl table (rec_no int IDENTITY(1, 1) NOT NULL,                  
                    id  int NOT NULL) AS                                 
begin                                                                    
  /* функция формирует таблицу из строки целых чисел разделенных ","   */
  declare @pos      int,                                                 
          @textpos  int,                                                 
          @chunklen smallint,                                            
          @str      nvarchar(4000),                                      
          @tmpstr   nvarchar(4000),                                      
          @leftover nvarchar(4000),                                      
          @Value    int                                                  
                                                                         
  set @textpos = 1                                                       
  set @leftover = ''                                                   
  while @textpos <= datalength(@list) / 2                                
  begin                                                                  
    set @chunklen = 4000 - datalength(@leftover) / 2                     
    set @tmpstr = ltrim(@leftover + substring(@list, @textpos, @chunklen))
    set @textpos = @textpos + @chunklen                                  
                                                                         
    set @pos = charindex(',', @tmpstr)                                 
    while @pos > 0                                                       
    begin                                                                
      set @str = substring(@tmpstr, 1, @pos - 1)                         
      set @Value = convert(int, @str)                                    
      if (@Value > 0) and                                                
        not exists(select id from @tbl where id = @Value)                
      begin                                                              
        insert @tbl (id) values(@Value)                                  
      end                                                                
      set @tmpstr = ltrim(substring(@tmpstr, @pos + 1, len(@tmpstr)))    
      set @pos = charindex(',', @tmpstr)                               
    end                                                                  
                                                                         
    set @leftover = @tmpstr                                              
  end                                                                    
                                                                         
  if (ltrim(rtrim(@leftover)) <> '') and                               
    not exists(select id from @tbl where id = convert(int, @leftover))   
    insert @tbl (id) values(convert(int, @leftover))                     
  return                                                                 
end
go

