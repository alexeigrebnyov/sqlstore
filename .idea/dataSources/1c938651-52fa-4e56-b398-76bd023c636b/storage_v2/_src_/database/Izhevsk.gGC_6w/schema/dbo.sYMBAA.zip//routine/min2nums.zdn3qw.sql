create function [dbo].[min2nums] (
    @NUM1   numeric(20,10),
    @NUM2   numeric(20,10)
) returns numeric(20,10)
as
begin
--75713
    declare @RET numeric(20,10)

    if @NUM1 < @NUM2
        set @RET = @NUM1
    else
        set @RET = @NUM2

    return @RET
end
go

