CREATE FUNCTION [dbo].[nnfSMS_GetSMSText_UZI_BER]
(
	@PlanningID int = 0
)
RETURNS varchar(1000)
AS BEGIN
DECLARE
	@Medecin varchar(255),
	@_Medecin varchar(255),
	@visit varchar(255),
	@_visit varchar(255),
	@time varchar(10),
	@Addr varchar(255),
	@_Addr varchar(255),
	@h int,
	@PatientID int,
	@Date datetime,
	@filial int,
	@ID int
	
DECLARE @DataTable TABLE (ID int identity (1,1),Medecin varchar(255),visit varchar(255), [time] varchar(10),Addr varchar(255) )
	
DECLARE DATA CURSOR LOCAL
FOR		
	SELECT DISTINCT
		p.PATIENTS_ID,
		pl.DATE_CONS,
		m.NOM,
		--CASE
		--	WHEN ISNULL(ge.ID,0) = 0 THEN pe.NAME
		--	ELSE ge.GroupName
		--END,
		CASE
			WHEN LEN(CAST(pl.HEURE AS varchar(4)))=3 THEN SUBSTRING(CAST(pl.HEURE AS varchar(4)),1,1)+':'+SUBSTRING(CAST(pl.HEURE AS varchar(4)),2,2)
			ELSE SUBSTRING(CAST(pl.HEURE AS varchar(4)),1,2)+':'+SUBSTRING(CAST(pl.HEURE AS varchar(4)),3,2)
		END,
		CAST(a.ADR AS varchar(255)),
		pl.HEURE,
		PLS.FM_INTORG_ID
	FROM PLANNING pl
	JOIN PATIENTS p ON p.PATIENTS_ID = pl.PATIENTS_ID 
	JOIN PL_SUBJ pls ON pls.PL_SUBJ_ID = pl.PL_SUBJ_ID 
	JOIN MEDECINS m ON m.MEDECINS_ID = pls.MEDECINS_ID 
	JOIN PL_EXAM pe ON pe.PL_EXAM_ID = pl.PL_EXAM_ID 
	--JOIN nntSMS_Exams ne ON pe.PL_EXAM_ID = ne.PL_EXAM_ID 
	--LEFT OUTER JOIN nntSMS_ExamGroups ge ON ge.ID = ne.GroupID
	JOIN FM_ORG o ON o.FM_ORG_ID = pls.FM_INTORG_ID 
	JOIN FM_ORG_ADR oa ON o.FM_ORG_ID = oa.FM_ORG_ID 
	JOIN FM_ADR a ON a.FM_ADR_ID = oa.FM_ADR_ID 
	JOIN 
		(
			SELECT PATIENTS_ID,DATE_CONS
			FROM PLANNING
			WHERE
				PLANNING_ID = @PlanningID
		) t ON pl.PATIENTS_ID = t.PATIENTS_ID AND pl.DATE_CONS = t.DATE_CONS
	WHERE  pl.PLANNING_ID=@PlanningID and
		CANCELLED = 0 
		AND pl.STATUS = 0
	ORDER BY 
		CAST(a.ADR AS varchar(255)),
		--CASE
		--	WHEN ISNULL(ge.ID,0) = 0 THEN pe.NAME
		--	ELSE ge.GroupName
		--END,
		pl.HEURE
			
OPEN DATA

FETCH NEXT FROM DATA
INTO @PatientID,@Date,@Medecin,@time,@addr,@h,@filial

WHILE @@FETCH_STATUS = 0 BEGIN
	INSERT @DataTable
	(Visit,[Time])
	VALUES
	('УЗИ'
		--CASE
		--	WHEN @_Addr<>@Addr THEN 'УЗИ'
			--ELSE
			--	CASE
			--		WHEN @Visit = @_Visit THEN ''
			--		ELSE @Visit
			--	END
		--END
		,
		@Time
	)
	SET @ID = SCOPE_IDENTITY()
	--SET @_visit = @visit
	SET @_Medecin = @Medecin
	SET @_Addr = @addr
	
	FETCH NEXT FROM DATA
	INTO @PatientID,@Date,@Medecin,@time,@addr,@h,@filial

	UPDATE @DataTable
		SET
			Addr = 
				CASE
					WHEN @_addr<>@addr THEN @_Addr
					ELSE Addr
				END,
			Medecin = 
				CASE
					WHEN @_Medecin<>@Medecin OR @_addr<>@addr THEN @_Medecin
					ELSE Medecin
				END
	WHERE
		ID = @ID
END

UPDATE @DataTable
	SET
		Addr =@_Addr,
		Medecin = @_Medecin
WHERE
	ID = @ID

CLOSE DATA
DEALLOCATE DATA

DECLARE @res varchar(max) = '',
@ne_mochit varchar(200),
@new_adress varchar(200)

if @filial=53 set @new_adress='Мы переехали! Новый адрес Бр.Касимовых 38. Ваш приём ' else set @new_adress=''

if @filial=42 set @ne_mochit='' else set @ne_mochit=' Подготовка: за час до УЗИ просим не ходить в туалет, выпить 3-4 стакана воды. Мочевой пузырь должен быть умеренно наполнен'


SELECT 
@res = @res + 
		CASE
			WHEN ISNULL(visit,'')<>'' THEN 
				CASE
					WHEN @res<>'' THEN ','
					ELSE ''
				END
				+visit
			ELSE ''
		END
		+
		CASE
			WHEN ISNULL(Medecin,'')<>'' THEN ' '+Medecin
			ELSE ''
		END
		+
		CASE
			WHEN ISNULL(visit,'')<>'' THEN ' в '
			ELSE ','
		END +[Time]+
		CASE
			WHEN ISNULL(Addr,'')<>'' THEN ' на '+Addr
			ELSE ''
		END
	
FROM @DataTable

RETURN
	(
		SELECT 
			
			--'Здравствуйте!Ваш приём '+
			@new_adress+
			dbo.DateStrShort(@date)+' '+
			--@res+' Не забудьте паспорт! Перезвоните нам, если  не придете'
			--@res+' C паспортом! Если не придете, отправьте слово НЕТ на Ватсап +79872272424.'+@ne_mochit
			@res+' C паспортом! Если не придете, пройдите по ссылке https://wa.me/79872272424?text=отменить и отправьте «Отменить»'+@ne_mochit
	)
END
go

