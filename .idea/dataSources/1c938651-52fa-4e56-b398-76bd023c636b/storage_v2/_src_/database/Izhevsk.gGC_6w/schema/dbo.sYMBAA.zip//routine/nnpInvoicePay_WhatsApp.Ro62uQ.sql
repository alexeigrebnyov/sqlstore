CREATE PROCEDURE [dbo].[nnpInvoicePay_WhatsApp](@FM_INVOICE varchar(30))
AS
DECLARE 
 @obj int, 
 @ret  int, 
 @text varchar(max), 
 @url varchar(max),
 @Body as varchar(8000) 


set @Body= '{"invoice": [{"fmInvoice":"'+@FM_INVOICE+'"}]}'

select @url = 'http://192.168.7.102:8094/invoicePay'

exec @ret = sp_OACreate 'MSXML2.ServerXMLHTTP', @obj out
IF @ret <> 0 exec sp_OAGetErrorInfo @obj

exec @ret = sp_OAMethod @obj, 'Open', null, 'POST', @url, 'false'
if @ret <> 0 exec sp_OAGetErrorInfo @obj

--exec @ret = sp_OAMethod @obj, 'setRequestHeader', null, 'Content-Type', 'text/xml; charset=utf-8'
exec @ret = sp_OAMethod @obj, 'setRequestHeader', null, 'Content-Type', 'application/json'
if @ret <> 0 exec sp_OAGetErrorInfo @obj

exec @ret = sp_OAMethod @obj, 'setOption', null, 2 ,13056  -- игнорировать сертификат
if @ret <> 0 exec sp_OAGetErrorInfo @obj

EXEC @ret = sp_OAMethod @obj, 'SEND', null, @body

go

