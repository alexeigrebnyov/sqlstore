CREATE PROCEDURE [dbo].[nnpSMS_GetRequestList53]
AS
SELECT
(
	SELECT 
		(
			SELECT 
				[dbo].[fNNPlus_SystemParametr](6) AS '@value'
				--[dbo].[fNNPlus_SystemParametr](case when (SELECT FILIAL FROM nntSMS_List WHERE StatusID = 1)=20 then 2 
				         --                           when (SELECT FILIAL FROM nntSMS_List WHERE StatusID = 1)=42 then 5 
													--when (SELECT FILIAL FROM nntSMS_List WHERE StatusID = 1)=43 then 4 else 2 end ) AS '@value'
			FOR XML PATH('token'), ROOT('security'),TYPE
		),
		(
			SELECT
				SMSText AS 'text',
				SMSOwner AS 'sender',
				(
					SELECT
						l.SMSRecipient AS '@phone',
						l.ID+600000 AS '@number_sms',
						l.ID+600000 AS '@client_id_sms'
					FOR XML PATH('abonent'),TYPE
				)
			FROM nntSMS_List l
			WHERE
				l.StatusID = 1 and l.FILIAL=53
			FOR XML PATH('message'),TYPE
		)
	FOR XML PATH('request'),TYPE
) AS XMLDoc


go

