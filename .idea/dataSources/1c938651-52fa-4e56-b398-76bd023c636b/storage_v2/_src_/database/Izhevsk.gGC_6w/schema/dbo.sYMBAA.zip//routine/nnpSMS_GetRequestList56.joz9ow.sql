CREATE PROCEDURE [dbo].[nnpSMS_GetRequestList56]
AS
SELECT
(
	SELECT 
		(
			SELECT 
				[dbo].[fNNPlus_SystemParametr](7) AS '@value'
				--[dbo].[fNNPlus_SystemParametr](case when (SELECT FILIAL FROM nntSMS_List WHERE StatusID = 1)=20 then 2 
				         --                           when (SELECT FILIAL FROM nntSMS_List WHERE StatusID = 1)=42 then 5 
													--when (SELECT FILIAL FROM nntSMS_List WHERE StatusID = 1)=43 then 4 else 2 end ) AS '@value'
			FOR XML PATH('token'), ROOT('security'),TYPE
		),
		(
			SELECT
				SMSText AS 'text',
				SMSOwner AS 'sender',
				(
					SELECT
						l.SMSRecipient AS '@phone',
						l.ID AS '@number_sms',
						l.ID AS '@client_id_sms'
					FOR XML PATH('abonent'),TYPE
				)
			FROM nntSMS_List l
			WHERE
				l.StatusID = 1 and l.FILIAL=56
			FOR XML PATH('message'),TYPE
		)
	FOR XML PATH('request'),TYPE
) AS XMLDoc


go

