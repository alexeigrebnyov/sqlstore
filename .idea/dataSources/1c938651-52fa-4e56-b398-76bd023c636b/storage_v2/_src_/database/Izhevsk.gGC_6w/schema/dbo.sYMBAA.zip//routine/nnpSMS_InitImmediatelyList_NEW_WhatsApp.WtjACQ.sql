CREATE PROCEDURE [dbo].[nnpSMS_InitImmediatelyList_NEW_WhatsApp]
AS
DECLARE 
	@ID int,
	@Phone varchar(11),
	@ErrorCode int,
	@fio varchar(100),
	@tip varchar(11),
	@filial int

DECLARE SMS CURSOR LOCAL
FOR
	SELECT DISTINCT
		MAX(pl.PLANNING_ID) AS PLANNING_ID,--pe.name,
		MAX((CASE WHEN dbo.nnfSMS_PhoneNormilize(TEL) <> '' THEN dbo.nnfSMS_PhoneNormilize(TEL)	ELSE dbo.nnfSMS_PhoneNormilize(MOBIL_TELEFON) END)) tel,
		MAX(([dbo].[fNNPlus_Patient](pl.PATIENTS_ID,2))) fio,
		MAX((CASE WHEN pe.tip_proceduri=0 THEN '89172533261' ELSE '89178921923' END)) tip,
		MAX(pls.FM_INTORG_ID)
		--pl.PLANNING_ID AS PLANNING_ID,--pe.name,
		--(CASE WHEN dbo.nnfSMS_PhoneNormilize(TEL) <> '' THEN dbo.nnfSMS_PhoneNormilize(TEL)	ELSE dbo.nnfSMS_PhoneNormilize(MOBIL_TELEFON) END) tel,
		--([dbo].[fNNPlus_Patient](pl.PATIENTS_ID,2)) fio,
		--(CASE WHEN pe.tip_proceduri=0 THEN '89172533261' ELSE '89178921923' END) tip,
		--pls.FM_INTORG_ID
	FROM PLANNING pl
	JOIN PATIENTS p ON p.PATIENTS_ID = pl.PATIENTS_ID 
	JOIN PL_SUBJ pls ON pls.PL_SUBJ_ID = pl.PL_SUBJ_ID 
	JOIN MEDECINS m ON m.MEDECINS_ID = pls.MEDECINS_ID 
	JOIN PL_EXAM pe ON pe.PL_EXAM_ID = pl.PL_EXAM_ID 
	--JOIN nntSMS_ImmediatelyExams ne ON ne.ExamID = pe.PL_EXAM_ID
	JOIN FM_ORG o ON o.FM_ORG_ID = pls.FM_INTORG_ID 
	JOIN FM_ORG_ADR oa ON o.FM_ORG_ID = oa.FM_ORG_ID 
	JOIN FM_ADR a ON a.FM_ADR_ID = oa.FM_ADR_ID 
	WHERE
		pl.PATIENT_ARRIVEE = 1
    AND 
	pls.FM_INTORG_ID in (53,56)
	AND
	pe.tip_proceduri is not null
	--AND
	--pl.PATIENTS_ID=149419
	AND
		pl.DATE_CONS = dbo.Date(GetDate())
	--AND
		--pl.HEURE BETWEEN 0 AND 2359
	AND
		pl.STATUS = 0
	AND
		pl.CANCELLED <> 1
	AND
		p.ARCHIVE <> 1 
	AND
		m.ARCHIVE <> 1
	AND
		(CASE
			WHEN dbo.nnfSMS_PhoneNormilize(MOBIL_TELEFON) <> '' THEN dbo.nnfSMS_PhoneNormilize(MOBIL_TELEFON)
			ELSE dbo.nnfSMS_PhoneNormilize(TEL)
		END) <> ''
		GROUP BY p.PATIENTS_ID
	
OPEN SMS

FETCH NEXT FROM SMS
INTO @ID,@Phone,@fio,@tip,@filial

WHILE @@FETCH_STATUS = 0 BEGIN

			declare @WA_ID int,
			@text varchar(Max)
			exec up_get_id 'NNTSMS_WHATSAPP', 1, @WA_ID output

			set @text = @fio+', при появлении острых симптомов после процедуры, позвоните по т.'+@tip+' (круглосуточно)'

			INSERT NNTSMS_WHATSAPP
			(Instance
			,[SMSText]
			,[Phone]
			,[Filial]
			,[Instance_Status]
			,[Date_Create]
			,[PLANNING_ID]
			,[INSTANCE_ID]
			,[SMSTextWA]
			)
			VALUES
			([dbo].[fNNPlus_WA_INSTANCE_NUMBER] (1),
			@text,
			@Phone,
			@filial,
			0,
			GETDATE(),
			@ID,
			1,
			@text
			)


	FETCH NEXT FROM SMS
	INTO @ID,@Phone,@fio,@tip,@filial
END


CLOSE SMS
DEALLOCATE SMS
go

