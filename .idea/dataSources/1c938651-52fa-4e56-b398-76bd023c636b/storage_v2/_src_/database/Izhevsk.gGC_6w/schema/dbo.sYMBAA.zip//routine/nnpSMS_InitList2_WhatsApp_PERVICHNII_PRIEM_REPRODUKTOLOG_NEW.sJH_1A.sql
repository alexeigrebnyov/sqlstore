CREATE PROCEDURE [dbo].[nnpSMS_InitList2_WhatsApp_PERVICHNII_PRIEM_REPRODUKTOLOG_NEW]
AS
DECLARE 
	@ID int,
	@ErrorCode int,
	@FM_INTORG_ID int

DECLARE SMS CURSOR LOCAL
FOR
	SELECT
		MAX(pl.PLANNING_ID)
	FROM PLANNING pl
	JOIN PATIENTS p ON p.PATIENTS_ID = pl.PATIENTS_ID 
	JOIN PL_SUBJ pls ON pls.PL_SUBJ_ID = pl.PL_SUBJ_ID 
	JOIN MEDECINS m ON m.MEDECINS_ID = pls.MEDECINS_ID 
	JOIN PL_EXAM pe ON pe.PL_EXAM_ID = pl.PL_EXAM_ID 
	JOIN FM_ORG o ON o.FM_ORG_ID = pls.FM_INTORG_ID 
	JOIN FM_ORG_ADR oa ON o.FM_ORG_ID = oa.FM_ORG_ID 
	JOIN FM_ADR a ON a.FM_ADR_ID = oa.FM_ADR_ID 
	WHERE --p.PATIENTS_ID=149419 and
	    pe.PL_EXAM_ID in (7651,7681,7812,7893,7481,7482,9832,10820,11262,11263,11853,11855,11928,11262,
		12218,12222,12268,12269,12542,12543)
	and 
	    pl.DATE_CONS = dbo.Date(DATEADD(day,1,GetDate())) 
			
	AND
		pl.HEURE BETWEEN 0 AND 2359
	AND
		pl.STATUS = 0
	AND
		pl.CANCELLED <> 1
	AND
		p.ARCHIVE <> 1 
	AND
		m.ARCHIVE <> 1
	AND
		(CASE
			WHEN dbo.nnfSMS_PhoneNormilize(TEL) <> '' THEN dbo.nnfSMS_PhoneNormilize(TEL)
			ELSE dbo.nnfSMS_PhoneNormilize(MOBIL_TELEFON)
		END) <> ''
	GROUP BY pl.PATIENTS_ID
	
DECLARE	@Phone varchar(11)
			
OPEN SMS

FETCH NEXT FROM SMS
INTO @ID

WHILE @@FETCH_STATUS = 0 BEGIN
	IF NOT EXISTS
			(
				SELECT NULL
				FROM nntSMS_List
				WHERE
					EntityDetailID = @ID
				AND
					EntityID = 1
			)
		BEGIN			
			SELECT
				@Phone =
					CASE
			WHEN dbo.nnfSMS_PhoneNormilize(TEL) <> '' THEN dbo.nnfSMS_PhoneNormilize(TEL)
			ELSE dbo.nnfSMS_PhoneNormilize(MOBIL_TELEFON)
		END,
				@FM_INTORG_ID=(PS.FM_INTORG_ID)
			FROM PLANNING pl
			inner join PL_SUBJ PS ON PL.PL_SUBJ_ID=PS.PL_SUBJ_ID
			JOIN PATIENTS p ON p.PATIENTS_ID = pl.PATIENTS_ID 
			WHERE
				pl.PLANNING_ID = @ID

			--declare @WA_ID int
			--exec up_get_id 'NNTSMS_WHATSAPP', 1, @WA_ID output

			INSERT NNTSMS_WHATSAPP
			(
			--wa_id
			--,
			Instance
			,[SMSText]
			,[Phone]
			,[Filial]
			,[Instance_Status]
			,[Date_Create]
			,[PLANNING_ID]
			,[INSTANCE_ID]
			,[SMSTextWA]
			)
			VALUES
			(--@WA_ID,
			[dbo].[fNNPlus_WA_INSTANCE_NUMBER] (1),
			[dbo].[nnfSMS_GetSMSText_PER_REPRODUKTOLOG_NEW](@ID),
			@Phone,
			@FM_INTORG_ID,
			0,
			GETDATE(),
			@ID,
			1,
			[dbo].[nnfSMS_GetSMSText_PER_REPRODUKTOLOG_NEW](@ID)
			)

			END
	FETCH NEXT FROM SMS
	INTO @ID
END


CLOSE SMS
DEALLOCATE SMS
go

