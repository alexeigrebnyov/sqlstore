CREATE PROCEDURE [dbo].[nnpSMS_InitList2_WhatsApp_PRIEMI_VRACHEI_KONSULTATION_IMBRIOLOG]
AS
DECLARE 
	@ID int,
	@name varchar(20),
	@date date,
	@huere varchar(20),
    @Phone varchar(11),
    @med_id varchar(30),
    @PATIENTS_ID int
    	
DECLARE SMS CURSOR LOCAL
FOR
      
     SELECT MIN(PLANNING.PLANNING_ID)
      ,MIN(PL_SUBJ.NAME)
      ,MIN(PLANNING.DATE_CONS)
      ,MIN(PLANNING.HEURE)
      ,MIN(PLANNING.PATIENTS_ID)
     --,MIN(MEDECINS.MOBIL_N_J_TEL)
    -- ,MIN(MEDECINS.MEDECINS_ID)
       
  FROM PLANNING INNER JOIN PL_EXAM on PLANNING.PL_EXAM_ID=PL_EXAM.PL_EXAM_ID
  INNER JOIN PL_SUBJ on PLANNING.PL_SUBJ_ID=PL_SUBJ.PL_SUBJ_ID
  --INNER JOIN MEDECINS on PL_SUBJ.MEDECINS_ID=MEDECINS.MEDECINS_ID
  where PLANNING.DATE_CONS =dbo.Date(GETDATE()+1)
  and PLANNING.STATUS=0 --and MEDECINS.MOBIL_N_J_TEL is not null and PL_SUBJ.NO_SMS_NOTIFY=0 and PL_EXAM.NO_SMS_NOTIFY=0
   and PLANNING.PL_SUBJ_ID=789 and PLANNING.PL_EXAM_ID in (11862)
  group by PLANNING.PL_SUBJ_ID  
    
		
OPEN SMS

FETCH NEXT FROM SMS
INTO @ID,@name,@date ,@huere,@PATIENTS_ID--,@Phone,@med_id

WHILE @@FETCH_STATUS = 0
 begin

 declare @WA_ID int,@textD varchar(MAX)
	--		exec up_get_id 'NNTSMS_WHATSAPP', 1, @WA_ID output

			set @textD =   'Дурандина В.Б. '+ dbo.datestr(@date)+' Консультатция эмбриолога у ЭМК:'+ CAST(@PATIENTS_ID as varchar(10)) +' ' +(CASE
    WHEN LEN(CAST(@huere AS varchar(4)))=3 THEN SUBSTRING(CAST(@huere AS varchar(4)),1,1)+':'+SUBSTRING(CAST(@huere AS varchar(4)),2,2)
	ELSE SUBSTRING(CAST(@huere AS varchar(4)),1,2)+':'+SUBSTRING(CAST(@huere AS varchar(4)),3,2) END  )

			INSERT NNTSMS_WHATSAPP
			(
			--wa_id
			--,
			Instance
			,[SMSText]
			,[Phone]
			,[Filial]
			,[Instance_Status]
			,[Date_Create]
			,[PLANNING_ID]
			,[INSTANCE_ID]
			,[SMSTextWA]
			)
			VALUES
			(--@WA_ID,
			[dbo].[fNNPlus_WA_INSTANCE_NUMBER] (1),
			@textD,
			@Phone,
			53,
			0,
			GETDATE(),
			@ID,
			1,
			@textD
			)
			

	declare @WA_ID1 int, @textA varchar(MAX)
	--		exec up_get_id 'NNTSMS_WHATSAPP', 1, @WA_ID1 output

			set @textA=   'Арефьева М.В. '+ dbo.datestr(@date)+' Консультатция эмбриолога у ЭМК:'+ CAST(@PATIENTS_ID as varchar(10)) +' ' +(CASE
    WHEN LEN(CAST(@huere AS varchar(4)))=3 THEN SUBSTRING(CAST(@huere AS varchar(4)),1,1)+':'+SUBSTRING(CAST(@huere AS varchar(4)),2,2)
	ELSE SUBSTRING(CAST(@huere AS varchar(4)),1,2)+':'+SUBSTRING(CAST(@huere AS varchar(4)),3,2) END  )

			INSERT NNTSMS_WHATSAPP
			(
			--wa_id
			--,
			Instance
			,[SMSText]
			,[Phone]
			,[Filial]
			,[Instance_Status]
			,[Date_Create]
			,[PLANNING_ID]
			,[INSTANCE_ID]
			,[SMSTextWA]
			)
			VALUES
			(--@WA_ID1,
			[dbo].[fNNPlus_WA_INSTANCE_NUMBER] (1),
			@textA,
			@Phone,
			53,
			0,
			GETDATE(),
			@ID,
			1,
			@textA
			)
		
	FETCH NEXT FROM SMS
	INTO @ID,@name,@date ,@huere,@PATIENTS_ID--,@Phone,@med_id

end

CLOSE SMS
DEALLOCATE SMS
go

