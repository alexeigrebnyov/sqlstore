CREATE PROCEDURE [dbo].[nnpSMS_SetResponceList56]
	@XMLString varchar(max) = '',
	@ErrorCode int = 0 output
AS

DECLARE 
	@idoc int,
	@XML XML

SET @XML = @XMLString

EXEC sp_xml_preparedocument @idoc OUTPUT, @xml

SELECT *
INTO #TempResponce
FROM OPENXML( @idoc, 'response/information', 1) 
WITH 
(
	parts int '@parts',
	id_sms decimal(38,0) '@id_sms',
	number_sms int '@number_sms',
	SendComment varchar(255) '.'
) 

UPDATE l
	SET
		sms_ID = t.id_sms,
		SendComment = t.SendComment,
		StatusID = 
				CASE
					WHEN ISNULL(t.id_sms,0) <> 0 THEN 2
					ELSE 3
				END,
		DateSending = 
				CASE
					WHEN ISNULL(t.id_sms,0) <> 0 THEN GetDate()
					ELSE l.DateSending
				END
FROM nntSMS_List l
INNER JOIN #TempResponce t ON t.number_sms = l.ID

IF @@ERROR <> 0
	SET @ErrorCode = 1

exec sp_xml_removedocument @idoc

DROP TABLE #TempResponce

SET @ErrorCode = ISNULL(@ErrorCode,0)
go

