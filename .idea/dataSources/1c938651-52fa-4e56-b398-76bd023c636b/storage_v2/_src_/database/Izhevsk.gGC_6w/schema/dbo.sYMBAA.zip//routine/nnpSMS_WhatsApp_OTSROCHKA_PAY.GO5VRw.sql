CREATE PROCEDURE [dbo].[nnpSMS_WhatsApp_OTSROCHKA_PAY]
AS
DECLARE 
	@ID int,
    @Phone varchar(11),
    @date_otsrochki datetime,
	@FM_ORG_CREATE_ID int	
DECLARE SMS CURSOR LOCAL
FOR
SELECT FM_INVOICE.PATIENTS_ID,dbo.nnfSMS_PhoneNormilize(PATIENTS.TEL) as tel, FM_INVOICE.DATE_OTSROCHKI,FM_INVOICE.FM_ORG_CREATE_ID
  FROM[dbo].[FM_INVOICE]  WITH(NOLOCK)  INNER JOIN PATIENTS  WITH(NOLOCK) 
  ON FM_INVOICE.PATIENTS_ID=PATIENTS.PATIENTS_ID
    where FM_INVOICE.DATE_OTSROCHKI =dateadd(d,3,dbo.DATE(GETDATE())) and FM_INVOICE.INVOICE_STATE<>'D'-- is not null
  and FM_INVOICE.IS_PAY_FULL=0--<=dbo.DATE(GETDATE())
  order by FM_INVOICE.DATE_CREATE desc
 
OPEN SMS

FETCH NEXT FROM SMS
INTO @ID,@Phone,@date_otsrochki,@FM_ORG_CREATE_ID

WHILE @@FETCH_STATUS = 0
 begin

 declare @WA_ID int,@text varchar(MAX)

 set @text='Уважаемый пациент! Срок отсроченного платежа истекает '+CONVERT(nvarchar(30),@date_otsrochki, 4)+'. Пожалуйста погасите свой долг'
			
			--exec up_get_id 'NNTSMS_WHATSAPP', 1, @WA_ID output

			INSERT NNTSMS_WHATSAPP
			(
			--wa_id
			--,
			Instance
			,[SMSText]
			,[Phone]
			,[Filial]
			,[Instance_Status]
			,[Date_Create]
			,[PLANNING_ID]
			,[INSTANCE_ID]
			,[SMSTextWA]
			)
			VALUES
			(--@WA_ID,
			[dbo].[fNNPlus_WA_INSTANCE_NUMBER] (1),
			@text,
			@Phone,
			@FM_ORG_CREATE_ID,
			0,
			GETDATE(),
			@ID,
			1,
			@text
			)
			
			--INSERT nntSMS_List
			--(
			--	SMSText,
			--	SMSOwner,
			--	SMSRecipient,
			--	EntityID,
			--	EntityDetailID,
			--	GroupIndex,
			--	StatusID,
			--	FILIAL
			--)
			--VALUES
	  --       ('Уважаемый пациент! Срок отсроченного платежа истекает '+CONVERT(nvarchar(30),@date_otsrochki, 4)+'. Пожалуйста погасите свой долг',
			--	'Kl.Nurievih',
			--	@Phone,
			--	1,
			--	@ID,
			--	@ID,
			--	1,
			--	@FM_ORG_CREATE_ID
			--)
	
	
		
	FETCH NEXT FROM SMS
	INTO @ID,@Phone,@date_otsrochki,@FM_ORG_CREATE_ID

end

CLOSE SMS
DEALLOCATE SMS
go

