CREATE procedure [dbo].[pNNPlus_fm_cash_balance_KKM](@fm_org_id int,@medecins_id int,@kkm varchar(20))
as
begin
		declare 
		@CASH_BALANCE_ID int,
		@summa money,
		@col_filial int

		
	declare @kkmint int
	set @kkmint = (case when @kkm='Касса 1' then 1 when @kkm='Касса 2' then 2 when @kkm='Касса 3' then 3 end)

		
		--set @CASH_BALANCE_ID =(select CASH_BALANCE_ID from FM_CASH_BALANCE where FM_ORG_ID=@fm_org_id and dbo.date(date_CASH) =dbo.date(getdate()))
		/*вычисляем сумму*/
		set @summa = dbo.fNNPlus_PATIENTS_FM_CASH_BALANCE_TODAY_KKM(@fm_org_id,@kkm)
		/*проверяем запись для текущего филиала в таблице */
		set @col_filial =(select count(CASH_BALANCE_ID) from FM_CASH_BALANCE where FM_ORG_ID=@fm_org_id and SPR_KKM_ID= @kkmint and dbo.date(date_CASH) =dbo.date(getdate()))
		--select count(CASH_BALANCE_ID) from FM_CASH_BALANCE where FM_ORG_ID=53 and dbo.date(date_CASH) =dbo.date(getdate())

	if @col_filial=0
		begin
		exec dbo.pNNPlus_create_fm_cash_balance_KKM @summa,@fm_org_id,@medecins_id,@kkmint
		end
	if @col_filial>0
		begin
		exec dbo.pNNPlus_update_fm_cash_balance_KKM @summa,@fm_org_id,@medecins_id,@kkmint
		end

end

go

