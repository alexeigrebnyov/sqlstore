-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pNNPlus_planning_no_error_multi](@data_zap_ datetime, @subj_ int, @exam_ int, @patient_ int, @comment_ varchar(200),@medecins_ int, @dep_ int,@start int)
AS
BEGIN
declare @ID_ int,
        @count_ int
declare @data1_ datetime
declare @data2_ datetime
declare @planing_id_ int
declare @HEURE_1 int,
        @HEURE_2 int
declare @time int,
        @time1 int,
        @time2 int
declare @FAM_ varchar(10)
declare @NAME_ varchar(10)
declare @PATRNAME_ varchar(10)
declare @DATA_END_1 datetime,
        @Data_start_1 datetime,
		@DATA_END_2 datetime,
        @Data_start_2 datetime,
		@DATA_END_ datetime,
        @Data_start_ datetime
declare @dure_ int,
		@dure1 int,
		@dure2 int,
		@time_strat_ time,
		@data_n_d_ datetime,
		@data_k_d_ datetime,
		@exit_ int,
		@H_ int,
		@Min_ int,
		@Cur_exam1 int,
		@Cur_exam2 int,
		@cur_dure_ int,
		@hour1 int,
		@hour2 int
-------------------------------Константы-------------------------------------------
set @data_zap_=dbo.date(@data_zap_)
set @exit_=0
set @dure_=(select DUREE from PL_EXAM where PL_EXAM_ID=@exam_)
set @time1=@start
if @time1 is null set @time1=800
if @time2 is null set @time2=2000

set @hour1 = convert(int,(case when len(convert(varchar(10),@time1))=3 then substring(convert(varchar(10),@time1),1,1) when len(convert(varchar(10),@time1))=4 then substring(convert(varchar(10),@time1),1,2) end ))
set @hour2 = convert(int,(case when len(convert(varchar(10),@time2))=3 then substring(convert(varchar(10),@time2),1,1) when len(convert(varchar(10),@time2))=4 then substring(convert(varchar(10),@time2),1,2) end ))

if @time1 is null set @data_n_d_=dateadd(hh,8,@data_zap_) else set @data_n_d_=dateadd(hh,@hour1,@data_zap_)
if @time2 is null set @data_k_d_=dateadd(hh,20,@data_zap_) else set @data_k_d_=dateadd(hh,@hour2,@data_zap_)
set @Data_start_=null
set @DATA_END_=NULL
--------------------------------запоминаем фамилию и имя текщего пациента----------------------------
select @FAM_=NOM,@NAME_=PRENOM,@PATRNAME_=PATRONYME
from PATIENTS
where PATIENTS_ID=@patient_

if @time is null and @time1 is null begin
set @time1=800
set @time2=2000
set @data_n_d_=dateadd(hh,@hour1,@data_zap_)
set @data_k_d_=dateadd(hh,@hour2,@data_zap_)
end
if @time is null and @time1 is not null begin
--set @time1=800
--set @time2=2000
--set @data_n_d_=dateadd(hh,@time1/100,@data_zap_)
--set @data_k_d_=dateadd(hh,@time2/100,@data_zap_)
---------------------------------ищем свободное время на дату конца хранения----------------------------------------
declare TIME cursor LOCAL FORWARD_ONLY for
select HEURE,DATE_START,DATE_END,DUREE,PL_EXAM_ID
from PLANNING
where DATE_CONS=@data_zap_ and PL_SUBJ_ID=@subj_ and status=0 and HEURE>=@time1
order by HEURE

open TIME

fetch NEXT from TIME
into @HEURE_1,
     @DATA_START_1,
	 @Data_end_1,
	 @dure1,
	 @Cur_exam1
fetch NEXT from TIME
into @HEURE_2,
     @DATA_START_2,
	 @Data_end_2,
	 @dure2,
	 @Cur_exam2
-----------------------------------Если в расписании вообще нет записей----------------------------
if @HEURE_1 is null or (@HEURE_1>@time1 and @HEURE_1-@time1>=@dure_)
   begin 
      set @time=@time1
	  set @Data_start_=dateadd(hh,@hour1,@data_zap_)
	  set @DATA_END_=dateadd(MINUTE,@dure_,@Data_start_)
	  set @exit_=1
   end
 	
while @exit_ = 0 and @@FETCH_STATUS = 0 begin
---------------------------------------тело цикла----------------------------------
----------------------------ищем свободное врем в середине дня---------------------
if (datediff(minute,@Data_end_1,@DATA_START_2)>=@dure_ and datediff(minute,@Data_end_2,@data_k_d_)-@dure_>0) --or (@HEURE_2 is null)
	begin
		set @cur_dure_= (select DUREE from PL_EXAM where PL_EXAM_ID=@Cur_exam1)
		set @Data_start_=@Data_end_1
		set @DATA_END_=dateadd(MINUTE,@dure_,@Data_start_)
        set @time=dbo.HEURE(@Data_end_1)
		set @exit_=1
 	end

set @HEURE_1=@HEURE_2
set @DATA_START_1=@DATA_START_2
set @Data_end_1=@Data_end_2
set @dure1=@dure2
set @Cur_exam1=@Cur_exam2

-------------------------------------конец тела цикла------------------------------
fetch NEXT from TIME
into @HEURE_2,
     @DATA_START_2,
	 @Data_end_2,
	 @dure2,
	 @Cur_exam2

end
close TIME
-----------------------------запись в конец списка ---------------------------
if ((@HEURE_1=@HEURE_2 or @HEURE_2 is null) and datediff(minute,@Data_end_1,@data_k_d_)-@dure_>0) 
	begin
		set @cur_dure_= (select DUREE from PL_EXAM where PL_EXAM_ID=@Cur_exam1)
		set @Data_start_=@Data_end_1
		set @DATA_END_=dateadd(MINUTE,@dure_,@Data_start_)
        set @time=dbo.HEURE(@Data_end_1)
		set @exit_=1
 	end

-----------------------------------делаем запись в расписание-----------------------------------
set @count_=0
if dbo.Time(@DATA_END_)='19:50:00' begin RAISERROR('На указанный день в поле Конец хранения нет свободного времения для записи. Выберите другой день!',16,1) end
else begin

--if convert(int,right(convert(varchar(6),@time),2))>=60 set @time=@time+40

exec up_get_id 'PLANNING', 1, @planing_id_ output
 insert into PLANNING(
PLANNING_ID,
PL_SUBJ_ID,
DATE_CONS,
HEURE,
DUREE,
PATIENTS_ID,
NOM,
PRENOM,
PATRONYME,
COLOR,
FONT,
DUREE_TEXT,
PATIENT_ARRIVEE,
PL_EXAM_ID,
MEDECINS_CREATOR_ID,
CANCELLED,
DIR_ANSW_LINKED,
STATUS,
CREATE_FM_DEP_ID,
DATE_START,
DATE_END,
COMMENTAIRE,
CREATE_DATE_TIME
)
values (
    @planing_id_,
    @subj_,
    @data_zap_,
    @time,
    @dure_,
    @patient_,
    @FAM_,
    @NAME_,
	@PATRNAME_,
    (select COLOR from PL_EXAM where PL_EXAM_ID=@exam_),
    (select FONT from PL_EXAM where PL_EXAM_ID=@exam_),
    convert(varchar(4),@dure_),
    0,
    @exam_,
    @medecins_,
    0,
    1,
    0,
    @dep_,
    @Data_start_,
    @DATA_END_,
	@comment_,
	GETDATE()
   )
end
end
else 
begin

set @Data_start_=DATEADD(HH,@time/100,@data_zap_)
set @DATA_END_=DATEADD(MINUTE,@dure_,@Data_start_)

--if convert(int,right(convert(varchar(6),@time),2))>=60 set @time=@time+40

exec up_get_id 'PLANNING', 1, @planing_id_ output

 insert into PLANNING(
PLANNING_ID,
PL_SUBJ_ID,
DATE_CONS,
HEURE,
DUREE,
PATIENTS_ID,
NOM,
PRENOM,
PATRONYME,
COLOR,
FONT,
DUREE_TEXT,
PATIENT_ARRIVEE,
PL_EXAM_ID,
MEDECINS_CREATOR_ID,
CANCELLED,
DIR_ANSW_LINKED,
STATUS,
CREATE_FM_DEP_ID,
DATE_START,
DATE_END,
COMMENTAIRE,
CREATE_DATE_TIME
)
values (
    @planing_id_,
    @subj_,
    @data_zap_,
    @time,
    @dure_,
    @patient_,
    @FAM_,
    @NAME_,
	@PATRNAME_,
    (select COLOR from PL_EXAM where PL_EXAM_ID=@exam_),
    (select FONT from PL_EXAM where PL_EXAM_ID=@exam_),
    convert(varchar(4),@dure_),
    0,
    @exam_,
    @medecins_,
    0,
    1,
    0,
    @dep_,
    @Data_start_,
    @DATA_END_,
	@comment_,
	GETDATE()
   )
end
END
go

