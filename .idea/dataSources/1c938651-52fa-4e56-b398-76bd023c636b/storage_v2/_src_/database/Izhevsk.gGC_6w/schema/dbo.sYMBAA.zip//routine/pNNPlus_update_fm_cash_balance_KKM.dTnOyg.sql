CREATE procedure [dbo].[pNNPlus_update_fm_cash_balance_KKM](@summa money,@fm_org_id int ,@medecins_id int,@kkmint int)
as
begin

		declare @CASH_BALANCE_ID int
		set @CASH_BALANCE_ID =(select CASH_BALANCE_ID from FM_CASH_BALANCE where FM_ORG_ID=@fm_org_id and dbo.date(date_CASH) =dbo.date(getdate()) and SPR_KKM_ID=@kkmint)
		
		update FM_CASH_BALANCE
		set CASH = @summa,
		MEDECINS_ID=@medecins_id,
		FM_ORG_ID=@fm_org_id,
		SPR_KKM_ID=@kkmint
		where CASH_BALANCE_ID=@CASH_BALANCE_ID
end
go

