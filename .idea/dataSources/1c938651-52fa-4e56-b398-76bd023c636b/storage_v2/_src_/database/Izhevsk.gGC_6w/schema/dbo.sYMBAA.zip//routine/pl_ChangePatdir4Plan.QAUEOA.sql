

create procedure dbo.pl_ChangePatdir4Plan @PLANNING_ID integer, @PATDIREC_NEW integer, @PLANNING_CR_ID integer, @IS_PAID_MAIN bit, @IS_BILL_MAIN bit
as
set xact_abort on
begin tran
/*declare @PLANNING_ID integer, @PATDIREC_NEW integer, @PLANNING_CR_ID integer, @IS_PAID_MAIN bit, @IS_BILL_MAIN bit
select 
	@PLANNING_ID=645903, 
	@PATDIREC_NEW=2718148, 
	@PLANNING_CR_ID=645903, 
	@IS_PAID_MAIN=0, 
	@IS_BILL_MAIN=1
*/
declare @DIR_ANSW_ID int
set @DIR_ANSW_ID = null
-- Если выбрана строка у которой несколько "свободных" DIR_ANSW, то надо привязывать тот, у которого есть оплаченный талон (если талонов нет, то первый попавшийся).
select @DIR_ANSW_ID=d.DIR_ANSW_ID --, sum(IsNull(cast(b.RENDERED as int), 0)) IS_PAY -- b.RENDERED=1 -- Услуга оплачена
from dbo.DIR_ANSW d
left join FM_BILL f on f.FM_BILL_ID = d.FM_BILL_ID
left join FM_BILLDET b on b.FM_BILL_ID = f.FM_BILL_ID
where d.PATDIREC_ID = @PATDIREC_NEW
group by d.DIR_ANSW_ID
order by sum(IsNull(cast(b.RENDERED as int), 0)) desc, d.DIR_ANSW_ID

if @DIR_ANSW_ID is null
begin
	raiserror('Не найдена запись в Плане назначений', 16, 10) 
	rollback
	return
end
if @PLANNING_CR_ID is not null 
  and exists(
	select *
	from dbo.PATDIREC
	where PATDIREC_ID=@PATDIREC_NEW
		  and PLANNING_CR_ID is not null) 
begin
	raiserror('Выбранное направление не может быть привязанно, Так как уже привязанно к другому расписанию', 16, 10) 
	rollback
	return
end

-- Ответная ЭПМЗ
declare @MOTCONSU_ID int
set @MOTCONSU_ID = null
select @MOTCONSU_ID=m.MOTCONSU_ID
from dbo.DIR_ANSW d
inner join MOTCONSU m on m.PLANNING_ID=d.PLANNING_ID
where d.PLANNING_ID=@PLANNING_ID

declare @PATDIREC_OLD int
select @PATDIREC_OLD=PATDIREC_ID
from dbo.DIR_ANSW
where PLANNING_ID=@PLANNING_ID

declare @INVOICE int
if exists
		(select i.*
		from dbo.FM_BILL f
		inner join dbo.FM_BILLDET b on b.FM_BILL_ID = f.FM_BILL_ID
		inner join DIR_ANSW d on f.FM_BILL_ID = d.FM_BILL_ID
		inner join FM_BILLDET_PAY bp on b.FM_BILLDET_ID = bp.FM_BILLDET_ID
		inner join FM_INVOICE i on bp.FM_INVOICE_ID=i.FM_INVOICE_ID
		where d.PLANNING_ID=@PLANNING_ID)
	set @INVOICE = 1
else
	set @INVOICE = 0

-- Запись без талона когда запись в расписании создает направление (1)
if @PLANNING_CR_ID is not null and @IS_BILL_MAIN=0
begin
	-- Удаляем DIR_ANSW
	select DIR_ANSW_ID, PATDIREC_ID
	into #DIR_ANSW
	from dbo.DIR_ANSW
	where PLANNING_ID=@PLANNING_ID

	update dbo.DIR_ANSW set PATDIREC_ID=null, PLANNING_ID=null, MOTCONSU_RESP_ID=null
	where PLANNING_ID=@PLANNING_ID

	delete d
	from dbo.DIR_ANSW d
	inner join #DIR_ANSW d2 on d.DIR_ANSW_ID=d2.DIR_ANSW_ID

	-- Удаляем PATDIREC
	update p set p.PLANNING_CR_ID=null
	from dbo.PATDIREC p
	inner join #DIR_ANSW d on p.PATDIREC_ID=d.PATDIREC_ID

	delete p
	from dbo.PATDIREC p
	inner join #DIR_ANSW d on p.PATDIREC_ID=d.PATDIREC_ID

	-- Привязываем новый
	update dbo.DIR_ANSW set PLANNING_ID=@PLANNING_ID, MOTCONSU_RESP_ID=@MOTCONSU_ID
	where DIR_ANSW_ID=@DIR_ANSW_ID

	-- Принято решение очищать
	--update dbo.PATDIREC set PLANNING_CR_ID=@PLANNING_ID
	--where PATDIREC_ID=@PATDIREC_NEW
end

-- Запись без талона когда по направлению запланирована запись в расписании (2)
if @PLANNING_CR_ID is null and @IS_BILL_MAIN=0
begin
	-- Отвязать старое направление
	update dbo.DIR_ANSW set PLANNING_ID=NULL, MOTCONSU_RESP_ID=null
	--select * from dbo.DIR_ANSW
	where PLANNING_ID=@PLANNING_ID

	-- Привязать новое направление
	update dbo.DIR_ANSW set PLANNING_ID=@PLANNING_ID, MOTCONSU_RESP_ID=@MOTCONSU_ID
	where DIR_ANSW_ID=@DIR_ANSW_ID
end

-- Запись с талоном (не оплаченным) когда запись в расписании создает направление (1)
if @PLANNING_CR_ID is not null and @IS_BILL_MAIN=1 and @IS_PAID_MAIN=0 and @INVOICE=0
begin
	if exists(
		select b.*
		from dbo.FM_BILL f
		inner join dbo.FM_BILLDET b on b.FM_BILL_ID = f.FM_BILL_ID
		  and b.RENDERED=1
		inner join DIR_ANSW d on f.FM_BILL_ID = d.FM_BILL_ID
		where d.PLANNING_ID=@PLANNING_ID
	) 
	begin
		raiserror('Удалить талон нельзя, так как он оплачен', 16, 10) 
		rollback
		return
	end

	-- Удалить FM_BILLDET
	delete b
	from dbo.FM_BILL f
	inner join dbo.FM_BILLDET b on b.FM_BILL_ID = f.FM_BILL_ID
	inner join DIR_ANSW d on f.FM_BILL_ID = d.FM_BILL_ID
	where d.PLANNING_ID=@PLANNING_ID

	-- Удалить FM_BILL
	delete f
	from dbo.FM_BILL f
	inner join DIR_ANSW d on f.FM_BILL_ID = d.FM_BILL_ID
	where d.PLANNING_ID=@PLANNING_ID

	-- Удалить DIR_ANSW
	select DIR_ANSW_ID, PATDIREC_ID
	into #DIR_ANSW2
	from dbo.DIR_ANSW
	where PLANNING_ID=@PLANNING_ID

	update dbo.DIR_ANSW set PATDIREC_ID=null, PLANNING_ID=null, MOTCONSU_RESP_ID=null
	where PLANNING_ID=@PLANNING_ID

	delete d
	from dbo.DIR_ANSW d
	inner join #DIR_ANSW2 d2 on d.DIR_ANSW_ID=d2.DIR_ANSW_ID

	-- Удаляем PATDIREC
	update p set p.PLANNING_CR_ID=null
	from dbo.PATDIREC p
	inner join #DIR_ANSW2 d on p.PATDIREC_ID=d.PATDIREC_ID

	delete p
	from dbo.PATDIREC p
	inner join #DIR_ANSW2 d on p.PATDIREC_ID=d.PATDIREC_ID

	-- Привязываем новый
	update dbo.DIR_ANSW set PLANNING_ID=@PLANNING_ID, MOTCONSU_RESP_ID=@MOTCONSU_ID
	where DIR_ANSW_ID=@DIR_ANSW_ID

	-- возникает следующая ситуация: если было создано направление из расписания (PLANNING_CR_ID =! NULL), к нему создан талон и счёт, при замене такого направления оно не удаляется, но такое направление не будет вновь доступно для привязки (его не будет в списке предложенных на замену направлений, т.к выполняется условие PLANNING_CR_ID =! NULL).
	if @PLANNING_CR_ID is not null 
	  and @IS_BILL_MAIN=1 and @IS_PAID_MAIN=1 
		update dbo.PATDIREC set PLANNING_CR_ID=null
		where PATDIREC_ID=@PATDIREC_OLD

	if @PLANNING_CR_ID is not null
	  and exists(select 1 from dbo.PATDIREC 
		where PATDIREC_ID=@PATDIREC_NEW and PLANNING_CR_ID IS NOT NULL
	)
		update dbo.PATDIREC set PLANNING_CR_ID=@PLANNING_ID
		where PATDIREC_ID=@PATDIREC_NEW

end

-- Запись с талоном (не оплаченным) когда по направлению запланирована запись в расписании
if  (@PLANNING_CR_ID is null and @IS_BILL_MAIN=1 and @IS_PAID_MAIN=0) 
-- Запись с талоном (не оплаченным) когда запись в расписании создает направление
  or (@PLANNING_CR_ID is not null and @IS_BILL_MAIN=1 and @IS_PAID_MAIN=0) 
-- оплаченный талон
  or (@IS_BILL_MAIN=1 and @IS_PAID_MAIN=1) 
  or (@PLANNING_CR_ID is not null and @IS_BILL_MAIN=1 and @IS_PAID_MAIN=0 and @INVOICE=1)
begin
	-- Отвязать старое направление
	update dbo.DIR_ANSW set PLANNING_ID=NULL, MOTCONSU_RESP_ID=null
	--select * from dbo.DIR_ANSW
	where PLANNING_ID=@PLANNING_ID

	-- Привязать новое направление
	update dbo.DIR_ANSW set PLANNING_ID=@PLANNING_ID, MOTCONSU_RESP_ID=@MOTCONSU_ID
	where DIR_ANSW_ID=@DIR_ANSW_ID

	-- возникает следующая ситуация: если было создано направление из расписания (PLANNING_CR_ID =! NULL), к нему создан талон и счёт, при замене такого направления оно не удаляется, но такое направление не будет вновь доступно для привязки (его не будет в списке предложенных на замену направлений, т.к выполняется условие PLANNING_CR_ID =! NULL).
	if @PLANNING_CR_ID is not null 
	  and ((@IS_BILL_MAIN=1 and @IS_PAID_MAIN=1) or (@INVOICE=1))
		update dbo.PATDIREC set PLANNING_CR_ID=null
		where PATDIREC_ID=@PATDIREC_OLD

	if @PLANNING_CR_ID is not null
	  and exists(select 1 from dbo.PATDIREC 
		where PATDIREC_ID=@PATDIREC_NEW and PLANNING_CR_ID IS NOT NULL
	)
		update dbo.PATDIREC set PLANNING_CR_ID=@PLANNING_ID
		where PATDIREC_ID=@PATDIREC_NEW

end

commit
--rollback
go

