CREATE PROCEDURE [dbo].[pl_CheckNewPlanning]( @PlanningID int, @State int output, @Msg varchar(2048) output)  AS
BEGIN
declare @PL_SUBJ_ID int,@PL_EXAM_ID int,@PATIENTS_ID int,@date_CONS datetime,@Zapisan int ,@NeotlozkaGin int,@filial int
  set @State=0;
  set @Msg='';
  set @PL_SUBJ_ID=(SELECT PL_SUBJ_ID FROM PLANNING where PLANNING_ID=@PlanningID)
  set @PL_EXAM_ID=(SELECT PL_EXAM_ID FROM PLANNING where PLANNING_ID=@PlanningID)
  set @PATIENTS_ID=(SELECT PATIENTS_ID FROM PLANNING where PLANNING_ID=@PlanningID)
  set @date_CONS=(SELECT date_CONS FROM PLANNING where PLANNING_ID=@PlanningID)
  set @Zapisan=(
  SELECT COUNT(*) FROM PLANNING inner join PL_EXAM 
  ON PLANNING.PL_EXAM_ID=PL_EXAM.PL_EXAM_ID where PLANNING.PL_SUBJ_ID=@PL_SUBJ_ID and PLANNING.PL_EXAM_ID=@PL_EXAM_ID 
  and PATIENTS_ID=@PATIENTS_ID and date_CONS=@date_CONS 
  and (PLANNING.STATUS=0 or PLANNING.STATUS=4) and 
  PL_EXAM.WARN_ACTIVE_DIR_EXISTS = 1 and PL_EXAM.FORBIDDEN = 1
  )
  set @filial =(select FM_INTORG_ID from PLANNING P Inner join PL_SUBJ PL ON P.PL_SUBJ_ID=PL.PL_SUBJ_ID where p.PLANNING_ID=@PlanningID)

  /*Начало после данных приемов добавляется событие мониторинг если есть место для записи*/

 -- if (@PL_EXAM_ID in(
 -- 7481 /*Первичный приём репродуктолога*/
 -- ,8098 /*Онлайн консультация репродуктолога*/
 -- ,7618 /*Консультация по результатам анализов/процедур*/
 -- ,7631 /*Консультация перед эко*/
 -- ,11910 /*Приём фомс*/
 -- ,11911 /*Приём фомс крио*/
 -- ,7616 /*Обсуждение итогов протокола*/
 -- ,10798 /*Онлайн обсуждение итогов протокола*/
 -- ,10664 /*Завести/Утвердить протокол*/
 -- ,7916 /*После пункции фолликул*/
 -- ,7615 /*Исключить гидросальпинкс*/
 -- ,7614 /*Оценка овариального резерва*/
 -- ,7617 /*Оценка эндометрия*/
 -- ,7625 /*Определение сердцебиение плода*/
 -- ,12235 /*Скрининг репродуктивного здоровья*/
 -- ,11853 /*_Акция репродуктолог -100*/
 -- ,12235 /*Скрининг репродуктивного здоровья*/
 -- ) 
 -- and @filial=53)
 -- begin
	--declare @TO_TIME int, @FROM_TIME int, @DATE_START datetime, @DATE_END datetime
 
	--set @FROM_TIME = (select dbo.HEURE(CONVERT(VARCHAR(5),DATE_END,108)) FROM PLANNING where PLANNING_ID=@PlanningID)
	--set @TO_TIME= (select dbo.HEURE(CONVERT(VARCHAR(5),dateadd(mi,10,DATE_END),108)) FROM PLANNING where PLANNING_ID=@PlanningID)
  
	--set @DATE_START = (select DATE_END FROM PLANNING where PLANNING_ID=@PlanningID)
	--set @DATE_END = (select dateadd(mi,10,DATE_END) FROM PLANNING where PLANNING_ID=@PlanningID)
	--set @date_CONS=(SELECT date_CONS FROM PLANNING where PLANNING_ID=@PlanningID)
	--set @PL_SUBJ_ID=(SELECT PL_SUBJ_ID FROM PLANNING where PLANNING_ID=@PlanningID)
	
	--declare @PL_EXCL_ID   int exec up_get_id  'PL_EXCL', 1, @PL_EXCL_ID output 
    
	--if ( select count(Planning_ID) from PLanning where PL_SUBJ_ID=@PL_SUBJ_ID and date_cons=@date_CONS and STATUS=0 and DATE_START between @DATE_START and @DATE_END )=0
	--	begin
	--		insert into PL_EXCL
	--		(PL_EXCL_ID, 
	--		OWNER_TYPE,
	--		NAME, 
	--		USE_TIME,
	--		FROM_DATE,
	--		FROM_TIME, 
	--		TO_DATE, 
	--		TO_TIME, 
	--		PL_LEG_ID, 
	--		CREATE_DATE_TIME, 
	--		MODIFY_DATE_TIME, 
	--		MEDECINS_CREATE_ID, 
	--		MEDECINS_MODIFY_ID, 
	--		KRN_CREATE_USER_ID, 
	--		PL_SUBJ_ID, 
	--		DATE_START, 
	--		DATE_END)
	--		values( 
	--		@PL_EXCL_ID , 
	--		2, 
	--		'Мониторинг', 
	--		1, 
	--		@date_CONS,--{ts '2021-06-21 00:00:00.000'}, 
	--		@FROM_TIME,--730, 
	--		@date_CONS,--{ts '2021-06-21 00:00:00.000'}, 
	--		@TO_TIME,--805, 
	--		24, 
	--		Getdate(), 
	--		Getdate(), 
	--		399, 
	--		399, 
	--		399, 
	--		@PL_SUBJ_ID, 
	--		@DATE_START, 
	--		@DATE_END )
	--	end

 -- end
  /**/

  /**/
  if (@PL_EXAM_ID in(
  11080 /*_Передняя кольпорафия*/
  ,11081 /*_Передняя и задняя кольпорафия*/
  ,11297 /*_Задняя кольпорафия*/
  ) 
  and (@filial=53 or @filial=56) )
  begin
  declare @data_zap_k datetime, @subj_k int, @patient_k int, @comment_k varchar(200), @medecins_k int, @dep_k int, @exam_k int

  set @data_zap_k = dateadd(day,1,dbo.date(getdate()))
  set @subj_k = 464
  set @patient_k = (SELECT PATIENTS_ID FROM PLANNING where PLANNING_ID=@PlanningID)
  set @comment_k = ''
  set @medecins_k =(SELECT MEDECINS_CREATOR_ID FROM PLANNING where PLANNING_ID=@PlanningID)
  set @dep_k = (SELECT CREATE_FM_DEP_ID FROM PLANNING where PLANNING_ID=@PlanningID)
  set @exam_k = 12547

	exec  dbo.pNNPlus_planning_no_error @data_zap_k , @subj_k , @exam_k , @patient_k , @comment_k ,@medecins_k , @dep_k

  end
  /**/

  if @Zapisan>1 
  begin
  set @Msg='Пациентка уже записана на прием'
  set @State=2
  end

    set @NeotlozkaGin=(
  SELECT COUNT(*) FROM PLANNING inner join PL_EXAM 
  ON PLANNING.PL_EXAM_ID=PL_EXAM.PL_EXAM_ID 
  where PLANNING_id=@PlanningID and PLANNING.PL_EXAM_ID=8461 and DATE_CONS>dbo.date(getdate()) 
  --and (PLANNING.STATUS=0 or PLANNING.STATUS=4) and   PL_EXAM.WARN_ACTIVE_DIR_EXISTS = 1 and PL_EXAM.FORBIDDEN = 1
  )

  if @NeotlozkaGin>0 
  begin
  set @Msg='Пациента можно записывать только на сегодняшний день'
  set @State=2
  end

  /* начало информирование согласие - предупреждение*/
  if @PL_EXAM_ID in(8005) and @PL_SUBJ_ID=362
  begin
  set @Msg='Не забыть сказать информацию о справке об эпидокружении!'
  set @State=1
  end
  /* конец информирование согласие - предупреждение*/

--  set @State=0;
--  set @Msg='';
  --тут надо вставить код вычисления статуса 
  --пример
  --select @State=status from planning_user_ext
  --where planning_id=@PlanningID;
  --set @Msg='Вы действительно хотите создать запись?';

END
go

