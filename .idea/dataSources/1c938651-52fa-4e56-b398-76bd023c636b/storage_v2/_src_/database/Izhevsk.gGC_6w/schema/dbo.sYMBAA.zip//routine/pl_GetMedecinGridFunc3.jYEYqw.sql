

create function [dbo].[pl_GetMedecinGridFunc3] (
    @SubjID int
    ,@DateFrom datetime
    ,@DateTo datetime
    ,@ShowCancelled bit
    )
returns @table table (
    D1 datetime
    ,D2 datetime
    ,EType int
    ,RecID int
    )
begin
    declare @t1 table (
        D1 datetime
        ,D2 datetime
        ,EType int
        ,RecID int
        )
    declare @t2 table (
        D1 datetime
        ,D2 datetime
        ,EType int
        ,RecID int
        )
    declare @day_from datetime
        ,@day_to datetime
        ,@interval int
        ,@DayEnabled int
        ,@SubjAgenda int
        ,@PlDay int

    while @DateFrom <= @DateTo
    begin
        set @SubjAgenda = dbo.pl_GetSubjAgenda(@SubjID, @DateFrom);
        set @PlDay = dbo.pl_GetPlDay(@SubjAgenda, @DateFrom, @SubjID);

        select @day_from = @DateFrom + DayStart
            ,@day_to = @DateFrom + DayEnd
            ,@interval = DATEDIFF(minute, 0, DayInterval)
            ,@DayEnabled = ActiveDay
        from dbo.pl_GetSubjDayParamFunc(@SubjID, @DateFrom, @SubjAgenda, @PlDay)
        
        if (@interval > 0) and (@DayEnabled = 1)
        begin
            insert into @t1
            select *
            from pl_GetMedecinGridFunc(@SubjID, @DateFrom, @ShowCancelled, @SubjAgenda, @PlDay);

            /*
            while @day_from < @day_to
            begin
                if not exists (
                        select *
                        from @t1
                        where d1 <= @day_from
                            and d2 > @day_from
                        )
                    insert @t1
                    values (
                        @day_from
                        ,@day_from + @interval
                        ,0
                        ,null
                        )

                set @day_from = @day_from + @interval
            end
            */
            with CTE
            as (
                select D1 BOTH
                    ,1 INC_VALUE
                from @t1
                
                union all
                
                select D2
                    ,-1
                from @t1
                )
                ,CTE2
            as (
                select BOTH
                    ,INC_VALUE
                    ,ROW_NUMBER() over (
                        order by BOTH, INC_VALUE desc
                        ) ROW_NUM
                from CTE
                )
                ,CTE3
            as (
                /*
                select BOTH
                    ,ROW_NUM
                    ,SUM(INC_VALUE) over (
                        order by ROW_NUM
                        ) SUM_VALUE
                from CTE2
                */
                select CTE2.BOTH
                    ,CTE2.ROW_NUM
                    ,SUM(CTE2_CUMUL.INC_VALUE) SUM_VALUE
                from CTE2
                join CTE2 CTE2_CUMUL on CTE2_CUMUL.ROW_NUM <= CTE2.ROW_NUM
                group by CTE2.BOTH, CTE2.ROW_NUM
                )
                ,CTE4
            as (
                select CTE3.BOTH LEFT_BOUND
                    ,CTE3.ROW_NUM
                from CTE3
                left join CTE3 CTE3_LAG on CTE3.ROW_NUM = CTE3_LAG.ROW_NUM + 1
                where CTE3.SUM_VALUE = 1 and ISNULL(CTE3_LAG.SUM_VALUE, 0) = 0
                )
                ,CTE5
            as (
                select (select top 1 CTE4_LAG.LEFT_BOUND
                        from CTE4 CTE4_LAG
                        where CTE4_LAG.ROW_NUM < CTE3.ROW_NUM
                        order by CTE4_LAG.ROW_NUM desc) LEFT_BOUND
				,BOTH RIGHT_BOUND
                from CTE3
                where SUM_VALUE = 0
                )
            insert into @t2
            select *, 1, null
            from CTE5;

            insert into @t1
            select case when DATEADD(minute, -DATEDIFF(minute, @day_from, T1.D1) % @interval, T1.D1) < (select top 1 T2.D2
                        from @t2 T2
                        where T2.D2 > DATEADD(minute, -DATEDIFF(minute, @day_from, T1.D1) % @interval, T1.D1) and T2.D2 < T1.D1
                        order by T2.D2 desc)
                    then (select top 1 T2.D2
                        from @t2 T2
                        where T2.D2 > DATEADD(minute, -DATEDIFF(minute, @day_from, T1.D1) % @interval, T1.D1) and T2.D2 < T1.D1
                        order by T2.D2 desc)
                    else DATEADD(minute, -DATEDIFF(minute, @day_from, T1.D1) % @interval, T1.D1)
                end LEFT_BOUND
                ,T1.D1 RIGHT_BOUND
                ,0
                ,null
            from @t2 T1
            where ISNULL(T1.EType, 0) <> 0
                and T1.D1 > @day_from and T1.D1 < @day_to
                and DATEDIFF(minute, @day_from, T1.D1) % @interval <> 0;

            insert into @t1
            select T1.D2 LEFT_BOUND
                ,case when DATEADD(minute, DATEDIFF(minute, T1.D2, @day_from) % @interval + @interval, T1.D2) > (select top 1 T2.D1
                        from @t2 T2
                        where T2.D1 < DATEADD(minute, DATEDIFF(minute, T1.D2, @day_from) % @interval + @interval, T1.D2) and T2.D1 > T1.D2
                        order by T2.D1 desc)
                    then (select top 1 T2.D1
                        from @t2 T2
                        where T2.D1 < DATEADD(minute, DATEDIFF(minute, T1.D2, @day_from) % @interval + @interval, T1.D2) and T2.D1 > T1.D2
                        order by T2.D1 desc)
                    else case when DATEADD(minute, DATEDIFF(minute, T1.D2, @day_from) % @interval + @interval, T1.D2) > @day_to
                        then @day_to
                        else DATEADD(minute, DATEDIFF(minute, T1.D2, @day_from) % @interval + @interval, T1.D2)
                    end
                end RIGHT_BOUND
                ,0
                ,null
            from @t2 T1
            where  ISNULL(T1.EType, 0) <> 0
                and T1.D2 > @day_from and T1.D2 < @day_to
                and DATEDIFF(minute, T1.D2, @day_to) % @interval <> 0;

            with CTE(N) as (select 1
                union all
                select N + 1
                from CTE
                    where N < 100),
            S as (select (A.N - 1) * 100 + B.N Z
                from CTE A, CTE B)
            insert into @t1
            select DATEADD(minute, @interval * (Z - 1), @day_from) LEFT_BOUND
                ,case when DATEADD(minute, @interval * Z, @day_from) > @day_to
                    then @day_to
                    else DATEADD(minute, @interval * Z, @day_from)
                end RIGHT_BOUND
                ,0
                ,null
            from S
                where Z <= DATEDIFF(minute, @day_from, @day_to) / @interval + 1
                    and not exists (select 1
                        from @t2
                        where D1 >= DATEADD(minute, @interval * (Z - 1), @day_from)
                            and D1 < case when DATEADD(minute, @interval * Z, @day_from) > @day_to
                                then @day_to
                                else DATEADD(minute, @interval * Z, @day_from)
                            end
                            or D1 <= DATEADD(minute, @interval * (Z - 1), @day_from)
                            and D2 > DATEADD(minute, @interval * (Z - 1), @day_from))

            insert into @table
            select distinct *
            from @t1
            where D1 <> D2

            delete
            from @t1

            delete
            from @t2
        end

        set @DateFrom = @DateFrom + 1
    end

    return
end
go

