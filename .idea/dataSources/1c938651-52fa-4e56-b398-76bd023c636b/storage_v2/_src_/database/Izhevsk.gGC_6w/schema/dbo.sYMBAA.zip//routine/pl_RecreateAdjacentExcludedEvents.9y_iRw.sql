
CREATE procedure dbo.pl_RecreateAdjacentExcludedEvents
    @PL_SUBJ_ID int,
    @DONT_CREATE bit = 0
as
begin
    declare @ERROR_MESSAGE varchar(2048), @P_MEDECINS_ID int, @COUNT_PL_EXCL_ID int, @FIRST_PL_EXCL_ID int

    set @P_MEDECINS_ID = 0
    set @COUNT_PL_EXCL_ID = 0
    set @FIRST_PL_EXCL_ID = 0

/*    begin try
        begin tran*/

	   --TT#37873: 1а
	   /*select PL_EXCL.PL_EXCL_ID
	   from PL_EXCL
	   where 1 = 1
		  and PL_EXCL.PL_SUBJ_ID = @PL_SUBJ_ID
		  and PL_EXCL.PL_EXCL_ID <> PL_EXCL.PARENT_PL_EXCL_ID*/

	   delete PL_EXCL
	   where 1 = 1
		  and PL_EXCL.PL_SUBJ_ID = @PL_SUBJ_ID
		  and PL_EXCL.PL_EXCL_ID <> PL_EXCL.PARENT_PL_EXCL_ID
	   --/TT#37873: 1а

	   --TT#37873: 1б
	   select PL_EXCL.PL_EXCL_ID
	   into #PARENT_PL_EXCL
	   from PL_EXCL with (nolock)
	   where 1 = 1
		  and PL_EXCL.PL_SUBJ_ID = @PL_SUBJ_ID
		  and PL_EXCL.PL_EXCL_ID = PL_EXCL.PARENT_PL_EXCL_ID
	   union
	   select PL_EXCL.PL_EXCL_ID
	   from PL_EXCL with (nolock)
	   where 1 = 1
		  and PL_EXCL.PL_SUBJ_ID = @PL_SUBJ_ID
		  and PL_EXCL.PARENT_PL_EXCL_ID is null
		  and exists(select 1
			 from PL_EXCL E with (nolock)
			 where 1 = 1
				and E.PL_SUBJ_ID <> @PL_SUBJ_ID
				and E.PARENT_PL_EXCL_ID = PL_EXCL.PL_EXCL_ID)

	   --select #PARENT_PL_EXCL.PL_EXCL_ID
	   --from #PARENT_PL_EXCL

	   delete PL_EXCL
	   from PL_EXCL
	   join #PARENT_PL_EXCL on #PARENT_PL_EXCL.PL_EXCL_ID = PL_EXCL.PARENT_PL_EXCL_ID
	   where 1 = 1
		  and PL_EXCL.PL_SUBJ_ID <> @PL_SUBJ_ID
	   --/TT#37873: 1б

	   if @DONT_CREATE = 0
	   begin
		  --TT#37873: 1в
		  select @P_MEDECINS_ID = PL_SUBJ.MEDECINS_ID
		  from PL_SUBJ with (nolock)
		  where PL_SUBJ.PL_SUBJ_ID = @PL_SUBJ_ID
            		  
		  select PL_SUBJ.PL_SUBJ_ID
		  into #ADJACENT_PL_SUBJ
		  from PL_SUBJ with (nolock)
		  where 1 = 1
			 and PL_SUBJ.PL_SUBJ_ID <> @PL_SUBJ_ID
			 and PL_SUBJ.MEDECINS_ID = @P_MEDECINS_ID

		  --select #ADJACENT_PL_SUBJ.PL_SUBJ_ID
		  --from #ADJACENT_PL_SUBJ

		  select ROW_NUMBER() over (order by #ADJACENT_PL_SUBJ.PL_SUBJ_ID, PL_EXCL.PL_EXCL_ID) - 1 PL_EXCL_ID
			 ,PL_EXCL.OWNER_TYPE
			 ,PL_EXCL.OWNER_ID
			 ,PL_EXCL.NAME
			 ,PL_EXCL.EXCL_MEMO
			 ,PL_EXCL.USE_TIME
			 ,PL_EXCL.FROM_DATE
			 ,PL_EXCL.FROM_TIME
			 ,PL_EXCL.TO_DATE
			 ,PL_EXCL.TO_TIME
			 ,PL_EXCL.PL_LEG_ID
			 ,#ADJACENT_PL_SUBJ.PL_SUBJ_ID
			 ,PL_EXCL.PL_PATGR_ID
			 ,PL_EXCL.DATE_START
			 ,PL_EXCL.DATE_END
			 ,PL_EXCL.PL_EXCL_ID PARENT_PL_EXCL_ID
		  into #ADJACENT_PL_EXCL
		  from PL_EXCL with (nolock)
		  join #PARENT_PL_EXCL on #PARENT_PL_EXCL.PL_EXCL_ID = PL_EXCL.PL_EXCL_ID
		  cross join #ADJACENT_PL_SUBJ

		  --select #ADJACENT_PL_EXCL.*
		  --from #ADJACENT_PL_EXCL

		  select @COUNT_PL_EXCL_ID = COUNT(*) from #ADJACENT_PL_EXCL

		  --select @COUNT_PL_EXCL_ID COUNT_PL_EXCL_ID

		  exec dbo.up_get_id @KeyName = 'PL_EXCL', @Shift = @COUNT_PL_EXCL_ID, @ID = @FIRST_PL_EXCL_ID output

		  --select @FIRST_PL_EXCL_ID FIRST_PL_EXCL_ID, 1 DONE

		  insert into PL_EXCL (PL_EXCL.PL_EXCL_ID
			 ,PL_EXCL.OWNER_TYPE
			 ,PL_EXCL.OWNER_ID
			 ,PL_EXCL.NAME
			 ,PL_EXCL.EXCL_MEMO
			 ,PL_EXCL.USE_TIME
			 ,PL_EXCL.FROM_DATE
			 ,PL_EXCL.FROM_TIME
			 ,PL_EXCL.TO_DATE
			 ,PL_EXCL.TO_TIME
			 ,PL_EXCL.PL_LEG_ID
			 ,PL_EXCL.PL_SUBJ_ID
			 ,PL_EXCL.PL_PATGR_ID
			 ,PL_EXCL.DATE_START
			 ,PL_EXCL.DATE_END
			 ,PL_EXCL.PARENT_PL_EXCL_ID)
		  select #ADJACENT_PL_EXCL.PL_EXCL_ID + @FIRST_PL_EXCL_ID
			 ,#ADJACENT_PL_EXCL.OWNER_TYPE
			 ,#ADJACENT_PL_EXCL.OWNER_ID
			 ,#ADJACENT_PL_EXCL.NAME
			 ,#ADJACENT_PL_EXCL.EXCL_MEMO
			 ,#ADJACENT_PL_EXCL.USE_TIME
			 ,#ADJACENT_PL_EXCL.FROM_DATE
			 ,#ADJACENT_PL_EXCL.FROM_TIME
			 ,#ADJACENT_PL_EXCL.TO_DATE
			 ,#ADJACENT_PL_EXCL.TO_TIME
			 ,#ADJACENT_PL_EXCL.PL_LEG_ID
			 ,#ADJACENT_PL_EXCL.PL_SUBJ_ID
			 ,#ADJACENT_PL_EXCL.PL_PATGR_ID
			 ,#ADJACENT_PL_EXCL.DATE_START
			 ,#ADJACENT_PL_EXCL.DATE_END
			 ,#ADJACENT_PL_EXCL.PARENT_PL_EXCL_ID
		  from #ADJACENT_PL_EXCL

		  /*select PL_EXCL.*
		  from PL_EXCL
		  where PL_EXCL.PL_EXCL_ID >= @FIRST_PL_EXCL_ID*/
		  --/TT#37873: 1в

		  --TT#37873: 1г
		  select PL_EXCL.PL_EXCL_ID
		  into #ADJACENT_PARENT_PL_EXCL
		  from PL_EXCL with (nolock)
		  join #ADJACENT_PL_SUBJ on #ADJACENT_PL_SUBJ.PL_SUBJ_ID = PL_EXCL.PL_SUBJ_ID
		  where 1 = 1
			 and PL_EXCL.PL_EXCL_ID = PL_EXCL.PARENT_PL_EXCL_ID
		  union
		  select PL_EXCL.PL_EXCL_ID
		  from PL_EXCL with (nolock)
		  join #ADJACENT_PL_SUBJ on #ADJACENT_PL_SUBJ.PL_SUBJ_ID = PL_EXCL.PL_SUBJ_ID
		  where 1 = 1
			 and PL_EXCL.PARENT_PL_EXCL_ID is null
			 and exists(select 1
				from PL_EXCL E with (nolock)
				where 1 = 1
				    and E.PL_EXCL_ID <> PL_EXCL.PL_EXCL_ID
				    and E.PARENT_PL_EXCL_ID = PL_EXCL.PL_EXCL_ID)

		  --select #ADJACENT_PARENT_PL_EXCL.PL_EXCL_ID
		  --from #ADJACENT_PARENT_PL_EXCL

		  select ROW_NUMBER() over (order by PL_EXCL.PL_EXCL_ID) - 1 PL_EXCL_ID
			 ,PL_EXCL.OWNER_TYPE
			 ,PL_EXCL.OWNER_ID
			 ,PL_EXCL.NAME
			 ,PL_EXCL.EXCL_MEMO
			 ,PL_EXCL.USE_TIME
			 ,PL_EXCL.FROM_DATE
			 ,PL_EXCL.FROM_TIME
			 ,PL_EXCL.TO_DATE
			 ,PL_EXCL.TO_TIME
			 ,PL_EXCL.PL_LEG_ID
			 ,@PL_SUBJ_ID PL_SUBJ_ID
			 ,PL_EXCL.PL_PATGR_ID
			 ,PL_EXCL.DATE_START
			 ,PL_EXCL.DATE_END
			 ,PL_EXCL.PL_EXCL_ID PARENT_PL_EXCL_ID
		  into #PL_EXCL
		  from PL_EXCL with (nolock)
		  join #ADJACENT_PARENT_PL_EXCL on #ADJACENT_PARENT_PL_EXCL.PL_EXCL_ID = PL_EXCL.PL_EXCL_ID

		  --select #PL_EXCL.*
		  --from #PL_EXCL

		  select @COUNT_PL_EXCL_ID = COUNT(*) from #PL_EXCL

		  --select @COUNT_PL_EXCL_ID COUNT_PL_EXCL_ID

		  exec dbo.up_get_id @KeyName = 'PL_EXCL', @Shift = @COUNT_PL_EXCL_ID, @ID = @FIRST_PL_EXCL_ID output

		  --select @FIRST_PL_EXCL_ID FIRST_PL_EXCL_ID, 2 DONE

		  insert into PL_EXCL (PL_EXCL.PL_EXCL_ID
			 ,PL_EXCL.OWNER_TYPE
			 ,PL_EXCL.OWNER_ID
			 ,PL_EXCL.NAME
			 ,PL_EXCL.EXCL_MEMO
			 ,PL_EXCL.USE_TIME
			 ,PL_EXCL.FROM_DATE
			 ,PL_EXCL.FROM_TIME
			 ,PL_EXCL.TO_DATE
			 ,PL_EXCL.TO_TIME
			 ,PL_EXCL.PL_LEG_ID
			 ,PL_EXCL.PL_SUBJ_ID
			 ,PL_EXCL.PL_PATGR_ID
			 ,PL_EXCL.DATE_START
			 ,PL_EXCL.DATE_END
			 ,PL_EXCL.PARENT_PL_EXCL_ID)
		  select #PL_EXCL.PL_EXCL_ID + @FIRST_PL_EXCL_ID
			 ,#PL_EXCL.OWNER_TYPE
			 ,#PL_EXCL.OWNER_ID
			 ,#PL_EXCL.NAME
			 ,#PL_EXCL.EXCL_MEMO
			 ,#PL_EXCL.USE_TIME
			 ,#PL_EXCL.FROM_DATE
			 ,#PL_EXCL.FROM_TIME
			 ,#PL_EXCL.TO_DATE
			 ,#PL_EXCL.TO_TIME
			 ,#PL_EXCL.PL_LEG_ID
			 ,#PL_EXCL.PL_SUBJ_ID
			 ,#PL_EXCL.PL_PATGR_ID
			 ,#PL_EXCL.DATE_START
			 ,#PL_EXCL.DATE_END
			 ,#PL_EXCL.PARENT_PL_EXCL_ID
		  from #PL_EXCL

		  /*select PL_EXCL.*
		  from PL_EXCL
		  where PL_EXCL.PL_EXCL_ID >= @FIRST_PL_EXCL_ID*/
		  --/TT#37873: 1г
	   end

/*	   commit tran
    end try
    begin catch
	   select  @ERROR_MESSAGE =
		  'Error: ' + convert(varchar(10) , ERROR_NUMBER()) +
		  ', Procedure: ' + ISNULL(ERROR_PROCEDURE(), '-') +
		  ', Line: ' + convert(varchar(100) , ERROR_LINE()) +
		  ', Message: '+ ERROR_MESSAGE()

	   if @@trancount > 0
		  rollback tran

	   raiserror(@ERROR_MESSAGE, 16, 10)
    end catch*/
end
go

