
CREATE procedure dbo.pl_UpdateAdjacentExcludedEvents
    @PL_EXCL_ID int
as
begin
    declare @ERROR_MESSAGE varchar(2048)

/*    begin try
        begin tran*/
		  update PL_EXCL
		  set PL_EXCL.FROM_TIME = PARENT_PL_EXCL.FROM_TIME
			 ,PL_EXCL.TO_TIME = PARENT_PL_EXCL.TO_TIME
			 ,PL_EXCL.FROM_DATE = PARENT_PL_EXCL.FROM_DATE
			 ,PL_EXCL.TO_DATE = PARENT_PL_EXCL.TO_DATE
			 ,PL_EXCL.NAME = PARENT_PL_EXCL.NAME
			 ,PL_EXCL.USE_TIME = PARENT_PL_EXCL.USE_TIME
			 ,PL_EXCL.PL_LEG_ID = PARENT_PL_EXCL.PL_LEG_ID
			 ,PL_EXCL.EXCL_MEMO = PARENT_PL_EXCL.EXCL_MEMO
			 ,PL_EXCL.DATE_START = PARENT_PL_EXCL.DATE_START
			 ,PL_EXCL.DATE_END = PARENT_PL_EXCL.DATE_END
		  from PL_EXCL
		  join PL_EXCL PARENT_PL_EXCL on PARENT_PL_EXCL.PL_EXCL_ID = PL_EXCL.PARENT_PL_EXCL_ID
		  where PARENT_PL_EXCL.PL_EXCL_ID = @PL_EXCL_ID
    		  and PL_EXCL.PL_EXCL_ID <> @PL_EXCL_ID
/*	   commit tran
    end try
    begin catch
	   select  @ERROR_MESSAGE =
		  'Error: ' + convert(varchar(10) , ERROR_NUMBER()) +
		  ', Procedure: ' + ISNULL(ERROR_PROCEDURE(), '-') +
		  ', Line: ' + convert(varchar(100) , ERROR_LINE()) +
		  ', Message: '+ ERROR_MESSAGE()

	   if @@trancount > 0
		  rollback tran

	   raiserror(@ERROR_MESSAGE, 16, 10)
    end catch*/
end
go

