
CREATE procedure dbo.spAddKrnSysTraceLog 
  @TABLE_NAME varchar(30)  = null, 
  @KEY_VALUES varchar(max) = null, 
  @ACTION char(1)          = null,
  @EXTERNAL_USER_ID int    = null,
  @HOST_NAME varchar(100)  = null
  
as
begin  

  declare
    @fieldList varchar(max),
    @unpivotList varchar(max),
    @sql varchar(max),
    @keyField varchar(50),
    @idValue int,
    @log varchar(max),
    @dt datetime
    
  declare @c cursor  

  select @keyField = nullif(rtrim(KEY_FIELDS), '')
    from dbo.METATABLE with (nolock)
    where TABLE_NAME = @TABLE_NAME
      and TRACE_LOG = 'T'

  if @TABLE_NAME is null
  begin
    raiserror('Error! Required parametr @TABLE_NAME is empty', 16, 1)    
    return
  end  

  if nullif(rtrim(@KEY_VALUES), '') is not null
    and @keyField is not null
  begin
    create table #tmp_log (ID_VALUE int not null, STR_VALUE varchar(max) null)
    select 
      @fieldList = '',
      @unpivotList = ''

    select
        @fieldList = @fieldList + ', ' + FIELD_NAME + '=convert(varchar(4000), ' + FIELD_NAME + ', 121)',
        @unpivotList = @unpivotList + ', ' + FIELD_NAME
      from dbo.METAFIELD with (nolock)
      where TABLE_NAME = @TABLE_NAME
        and FIELD_NAME <> @keyField
        and FIELD_NAME not like 'KRN_%'

    select 
      @fieldList = @keyField + @fieldList,
      @unpivotList = substring(@unpivotList, 2, len(@unpivotList))
      
    set @sql = 'select ' + @keyField + ', ColName + ''='' + ColValue
    from (select ' + @fieldList + ' from ' + @TABLE_NAME + ' with(nolock) where ' + @keyField + ' in (' + @KEY_VALUES + ')) p
  unpivot
    (ColValue for ColName in (' + @unpivotList + ')
  ) u'  

    insert into #tmp_log
      exec(@sql)

    set @dt = current_timestamp  

    set @c = cursor static read_only for
      select ID_VALUE
        from #tmp_log
        group by ID_VALUE
    
    open @c
    while 1=1
    begin
      fetch from @c into @idValue
      
      if @@Fetch_status <> 0
        break
        
      set @log = 'UserID=' + convert(varchar, user_id()) +
        ' ExternalUserID=' + isnull(convert(varchar, @EXTERNAL_USER_ID), '') +
        ' HostName=' + isnull(@HOST_NAME, '') +
        ' DateTime=' + convert(varchar, @dt, 121) + 
        ' Action=' + case @action
                       when 'I' then 'INSERT'
                       when 'U' then 'UPDATE'
                       when 'D' then 'DELETE'
                       else '!UNKNOWN!'
                     end  
      select
          @log = @log + ' ' + STR_VALUE
        from #tmp_log
        where ID_VALUE = @idValue               

      insert into dbo.KRN_SYS_TRACE_LOG (TABLE_NAME, REC_ID, [USER_ID], DATE_CHANGE, ACTION, [LOG], LOG_DATA, [HOST_NAME], EXTERNAL_USER_ID, KRN_GUID)
        values(@TABLE_NAME, @idValue, user_id(), @dt, @ACTION, @log, '', @HOST_NAME, @EXTERNAL_USER_ID, convert(varchar(36), dbo.pmt_guid()))
      
    end  
    close @c
    deallocate @c
    drop table #tmp_log
  end              
  
  return
end
go

