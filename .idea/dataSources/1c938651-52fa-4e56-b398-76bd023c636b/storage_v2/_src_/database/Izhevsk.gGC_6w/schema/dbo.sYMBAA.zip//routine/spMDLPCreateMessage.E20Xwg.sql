

CREATE procedure [dbo].[spMDLPCreateMessage](@mdlp_id int, @msg varchar(max) output, @err varchar(max) output, @type_id int = NULL, @dm_doc_id int = NULL ) as
begin
--800419
DECLARE @version varchar(10);

  set @version='1.34'

  select @type_id = isnull(@type_id, [TYPE_ID]), @dm_doc_id =  isnull(@dm_doc_id, REC_ID) from MDLP_REQUEST where MDLP_REQUEST_ID = @mdlp_id


  if @type_id = 2101 --210, вариант 1 (по SGTIN)
  begin
      set @msg = (
      select 
        @version as '@version',
        @type_id/10 as 'query_kiz_info/@action_id', -- чтобы получить 210
        h.RECEIVER_ID as 'query_kiz_info/subject_id',
        d.SGTIN as 'query_kiz_info/sgtin'
      from
        MDLP_415_DETAILS d 
        join MDLP_415_HEADER h on d.MDLP_415_HEADER_ID= h.MDLP_415_HEADER_ID
      where
        d.MDLP_415_DETAILS_ID = @dm_doc_id
      for xml path ('documents')
      )
   end

  if @type_id = 2102 --210, вариант 2 ( по SSCC)
  begin
    set @msg = (
      select 
      @version as '@version',  
      @type_id/10 as 'query_kiz_info/@action_id',    -- чтобы получить 210
  --    '00000000109209' as 'query_kiz_info/subject_id',
      h.RECEIVER_ID as 'query_kiz_info/subject_id',
      d.SSCC as 'query_kiz_info/sscc_down'
    from
      MDLP_415_DETAILS d 
    join MDLP_415_HEADER h on d.MDLP_415_HEADER_ID = h.MDLP_415_HEADER_ID
    where
      d.MDLP_415_DETAILS_ID = @dm_doc_id
    for xml path ('documents')
    )
  end
  --select @type_id, @dm_doc_id

  if @type_id = 250 --recall
  begin
    set @msg = (
    select 
      @type_id as 'recall/@action_id',
      111 as 'recall/subject_id',
      replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'recall/operation_date',
      newid() as 'recall/operation_id',
      363 as 'recall/recall_action_id',
      'Не правильно переданы сведения' as 'recall/reason'
    for xml path ('documents'))
  end

------------------------------------------------------------ 416

  if @type_id in (416) --recieve_order
  begin
    set @type_id = 416
    set @err = (
    select top 1
      char(10) + 'Ошибка по DM_DOC_ID = ' + cast(d.DM_DOC_ID as varchar(10)) + char(10) + 
      --case when fo_s.MDLP_VENDOR_ID is null then 'Не найдена организация - отправитель' + char(10) else '' end + 
      case when adr_w.PLACE_OF_BUSINESS is null then 'Не найдена организация - отправитель' + char(10) else '' end + 
      case when adr_d.PLACE_OF_BUSINESS is null then 'Не найдена организация - получатель' + char(10) else '' end + 
      case when w.DM_WAREHOUSES_ID is null then 'Не найден склад документа' + char(10) else '' end + 
      case when fd.FM_DEP_ID is null then 'Не найдено отделение склада' + char(10) else '' end + 
      case when fo_r.FM_ORG_ID is null then 'Не найден филиал получателя' + char(10) else '' end + 
      case when dt.DM_TRANSFERS_ID is null then 'Не найдены данные о движении партии'+ char(10) else '' end + 
      case when not exists(select 1 from DM_LOTS dl with (nolock) left join DM_MEDS dm with (nolock) on dm.DM_MEDS_ID = dl.DM_MEDS_ID where dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1) then 'Не найдены данные о медикаменте партии партии'+ char(10) else '' end + 
      case when not exists(select 1 from DM_LOTS dl with (nolock) where dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1) then 'Не найдены данные о партии'+ char(10) else '' end

    from 
      DM_DOC d with (nolock)
      left join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
      left join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      left join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
      left join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID

      left join FM_ORG_ADR adr_w with (nolock) on w.FM_ORG_ADR_ID= adr_w.FM_ORG_ADR_ID
      left join FM_ORG_ADR adr_d with (nolock) on d.FM_ORG_ADR_ID = adr_d.FM_ORG_ADR_ID
      
    where
      d.DM_DOC_ID = @dm_doc_id

    )
    
    if replace(@err, char(10), '') = 'Ошибка по DM_DOC_ID = ' + cast(@dm_doc_id as varchar(10)) set @err = null

    if @err is null 
    set @msg = (
    select
      @version as '@version',
      @type_id as 'receive_order/@action_id',
      adr_w.PLACE_OF_BUSINESS as 'receive_order/subject_id',
      adr_d.PLACE_OF_BUSINESS as 'receive_order/shipper_id',
      --stuff(stuff(SYSDATETIMEOFFSET(), 20, 9, ''), 11, 1, 'T') as 'receive_order/operation_date',
      replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'receive_order/operation_date',
      d.DOC_NUM as 'receive_order/doc_num',
      convert(varchar(10), d.ACCEPT_DATE, 104) as 'receive_order/doc_date',
      1 as 'receive_order/receive_type',
/*
Значения: 
  1 (продажа); 
  2 (возврат)
*/
      1 as 'receive_order/source',
/*
Значения: 
  1 (собственные средства); 
  2 (средства федерального бюджета 
  3 (средства регионального бюджета)
*/
      1 as 'receive_order/contract_type',
/*
Значения: 
  1 (купля продажа); 
  2 (комиссия); 
  3 (агентский договор); 
  4 (передача на безвозмездной основе); 
  5 (возврат контрактному производителю); 
  6 (государственное лекарственное обеспечение); 
  7 (договор консигнации); 
  8 (собственные стредства)
*/
      NULL as 'receive_order/contract_num', --Реестровый номер контракта (договора) в Единой информационной системе в сфере закупок
      (select distinct
        case when dl.SSCC is null then 
          stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '') 
        else NULL end  as 'union/sgtin',
        dl.SSCC as 'union/sscc_detail/sscc',
        cast(dl.PRICE as numeric(16, 2)) as 'union/cost',
        ISNULL(fm.TAXE_PERC,0)  as 'union/vat_value'
      from 
        DM_DOC dd with (nolock)
        join DM_TRANSFERS dt with (nolock) on dd.DM_DOC_ID = dt.DM_DOC_ID
        join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
        join DM_LOTS_DETAIL dld with (nolock) on dld.DM_LOTS_ID = dl.DM_LOTS_ID
        left join FM_TAXE_DET fm with (nolock) on fm.FM_TAXE_DET_ID=dl.FM_TAXE_DET_IN_ID
      where 
        dd.DM_DOC_ID = d.DM_DOC_ID
        and dl.MDLP = 1
      for xml path ('')) as 'receive_order/order_details'
    from 
      DM_DOC d with (nolock)
      join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
      join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
      left join FM_ORG_ADR adr_w with (nolock) on w.FM_ORG_ADR_ID= adr_w.FM_ORG_ADR_ID
      left join FM_ORG_ADR adr_d with (nolock) on d.FM_ORG_ADR_ID = adr_d.FM_ORG_ADR_ID
    where
      d.DM_DOC_ID = @dm_doc_id
    for xml path ('documents'))
  end


------------------------------------------------------------ 431
  if @type_id = 431 --move_place
  begin
    set @err = (
    select 
      'Ошибка по DM_DOC_ID = ' + cast(d.DM_DOC_ID as varchar(10)) + char(10) + 
      --case when fo_s.FM_ORG_ID is null then 'Не найдена организация - отправитель' + char(10) else '' end + 
      case when w.DM_WAREHOUSES_ID is null then 'Не найден склад - отправитель' + char(10) else '' end + 
      case when wp.DM_WAREHOUSES_ID is null then 'Не найден склад - получатель' + char(10) else '' end + 
      case when adrw.PLACE_OF_BUSINESS is null then 'Не задан идентификатор МД для склада - отправителя' + char(10) else '' end +
      case when adrwp.PLACE_OF_BUSINESS is null then 'Не задан идентификатор МД для склада - получателя' + char(10) else '' end +
      --case when fd.FM_DEP_ID is null then 'Не найдено отделение склада' + char(10) else '' end + 
      --case when fo_r.FM_ORG_ID is null then 'Не найден филиал получателя' + char(10) else '' end + 
      case when dt.DM_TRANSFERS_ID is null then 'Не найдены данные о движении партии'+ char(10) else '' end + 
      case when dl.DM_LOTS_ID is null then 'Не найдены данные о партии'+ char(10) else '' end + 
      case when not exists (select 1 from DM_LOTS_DETAIL dld with (nolock) where dld.DM_LOTS_ID = dl.DM_LOTS_ID) and dl.DM_LOTS_ID is not null then 'Не найдены данные о SGTIN' else '' end

    from 
      DM_DOC d with (nolock)
      left join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
      left join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join DM_WAREHOUSES wp with (nolock) on wp.DM_WAREHOUSES_ID = d.DM_SOURCE_WH_ID
      left join FM_ORG_ADR adrw with (nolock) on adrw.FM_ORG_ADR_ID = w.FM_ORG_ADR_ID
      left join FM_ORG_ADR adrwp with (nolock) on adrwp.FM_ORG_ADR_ID = wp.FM_ORG_ADR_ID
      --left join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      --left join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      --left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
      left join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID
      left join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1
    where
      d.DM_DOC_ID = @dm_doc_id


    )
    if replace(@err, char(10), '') = 'Ошибка по DM_DOC_ID = ' + cast(@dm_doc_id as varchar(10)) set @err = null
    
    if @err is null 
    set @msg = (
    select
      @version as '@version',
      @type_id as 'move_place/@action_id',
      adrw.PLACE_OF_BUSINESS as 'move_place/subject_id',
      adrwp.PLACE_OF_BUSINESS as 'move_place/receiver_id',
      --stuff(stuff(SYSDATETIMEOFFSET(), 20, 9, ''), 11, 1, 'T') as 'move_place/operation_date',
      replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'move_place/operation_date',
      d.DOC_NUM as 'move_place/doc_num',
      convert(varchar(10), d.INVOICE_DATE, 104) as 'move_place/doc_date',
     -- (select 
    --  dl.sscc as 'sscc',
    --  dld.SGTIN as 'sgtin'
    (select 
        stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '') as 'sgtin' -- ???? должен быть SGTIN, а не SSCC
      from 
        DM_DOC dd with (nolock)
        join DM_TRANSFERS dt with (nolock) on dd.DM_DOC_ID = dt.DM_DOC_ID
        join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
        join DM_LOTS_DETAIL dld with (nolock) on dld.DM_LOTS_ID = dl.DM_LOTS_ID
      where 
        dd.DM_DOC_ID = d.DM_DOC_ID
        and dl.MDLP = 1
      group by 
        dl.sscc,
        dld.SGTIN
      for xml path ('')) as 'move_place/order_details'
    from 
      DM_DOC d with (nolock)
      --join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
      join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join DM_WAREHOUSES wp with (nolock) on wp.DM_WAREHOUSES_ID = d.DM_SOURCE_WH_ID
      left join FM_ORG_ADR adrw with (nolock) on adrw.FM_ORG_ADR_ID = w.FM_ORG_ADR_ID
      left join FM_ORG_ADR adrwp with (nolock) on adrwp.FM_ORG_ADR_ID = wp.FM_ORG_ADR_ID
      --join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      --join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      --left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
    where
      d.DM_DOC_ID = @dm_doc_id
    for xml path ('documents'))

    
  end
  if @type_id = 531 --health_care
  begin
    set @err = (
    select distinct
      'Ошибка по DM_DOC_ID = ' + cast(d.DM_DOC_ID as varchar(10)) + char(10) + 
      case when foa_s.PLACE_OF_BUSINESS is null then 'Не найдена организация - отправитель' + char(10) else '' end + 
      case when w.DM_WAREHOUSES_ID is null then 'Не найден склад документа' + char(10) else '' end + 
      case when fd.FM_DEP_ID is null then 'Не найдено отделение склада' + char(10) else '' end + 
      case when fo_r.FM_ORG_ID is null then 'Не найден филиал получателя' + char(10) else '' end + 
      case when dt.DM_TRANSFERS_ID is null then 'Не найдены данные о движении партии'+ char(10) else '' end + 
      case when dl.DM_LOTS_ID is null then 'Не найдены данные о партии'+ char(10) else '' end

    from 
      DM_DOC d with (nolock)
      left join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join FM_ORG_ADR foa_s with (nolock) on foa_s.FM_ORG_ADR_ID = w.FM_ORG_ADR_ID
      left join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      left join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
      left join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID
      left join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1
    where
      d.DM_DOC_ID = @dm_doc_id


    )
    if replace(@err, char(10), '') = 'Ошибка по DM_DOC_ID = ' + cast(@dm_doc_id as varchar(10)) set @err = null
    
    if @err is null 
    set @msg = (
    select
      @version as '@version',
      @type_id as 'health_care/@action_id',
      foa_s.PLACE_OF_BUSINESS as 'health_care/subject_id',
      --stuff(stuff(SYSDATETIMEOFFSET(), 20, 9, ''), 11, 1, 'T') as 'health_care/operation_date',
      replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'health_care/operation_date',
      convert(varchar(10), d.INVOICE_DATE, 104) as 'health_care/doc_date',
      isnull(nullif(d.DOC_NUM, ''), d.INVOICE_NUM) as 'health_care/doc_num',
      (select 
        stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '') as 'union/sgtin' -- ???? должен быть SGTIN, а не SSCC
      from 
        DM_DOC dd with (nolock)
        join DM_TRANSFERS dt with (nolock) on dd.DM_DOC_ID = dt.DM_DOC_ID
        join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
        join DM_LOTS_DETAIL dld with (nolock) on dl.DM_LOTS_ID = dld.DM_LOTS_ID
      where 
        dd.DM_DOC_ID = d.DM_DOC_ID
        and dl.MDLP = 1
      group by 
        stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '') 
      for xml path ('')) as 'health_care/order_details'
    from 
      DM_DOC d with (nolock)
     -- left join DM_WAREHOUSES wh_s with (nolock) on wh_s.DM_WAREHOUSES_ID = d.DM_SOURCE_WH_ID
      join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join FM_ORG_ADR foa_s with (nolock) on foa_s.FM_ORG_ADR_ID = w.FM_ORG_ADR_ID
      --join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      --join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      --left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
    where
      d.DM_DOC_ID = @dm_doc_id
    for xml path ('documents'))
  end
  
  if @type_id = 541 --move_destruction
  begin
    set @err = (
    select 
      'Ошибка по DM_DOC_ID = ' + cast(d.DM_DOC_ID as varchar(10)) + char(10) + 
      case when fo_s.FM_ORG_ID is null then 'Не найдена организация - отправитель' + char(10) else '' end + 
      case when w.DM_WAREHOUSES_ID is null then 'Не найден склад документа' + char(10) else '' end + 
      case when fd.FM_DEP_ID is null then 'Не найдено отделение склада' + char(10) else '' end + 
      case when fo_r.FM_ORG_ID is null then 'Не найден филиал получателя' + char(10) else '' end + 
      case when dt.DM_TRANSFERS_ID is null then 'Не найдены данные о движении партии'+ char(10) else '' end + 
      case when dl.DM_LOTS_ID is null then 'Не найдены данные о партии'+ char(10) else '' end

    from 
      DM_DOC d with (nolock)
      left join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
      left join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      left join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
      left join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID
      left join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1
    where
      d.DM_DOC_ID = @dm_doc_id


    )
    if replace(@err, char(10), '') = 'Ошибка по DM_DOC_ID = ' + cast(@dm_doc_id as varchar(10)) set @err = null
    
    if @err is null 
    set @msg = (
    select
      @type_id as 'move_destruction/@action_id',
      fo_s.MDLP_VENDOR_ID as 'move_destruction/subject_id',
--    stuff(stuff(SYSDATETIMEOFFSET(), 20, 9, ''), 11, 1, 'T') as 'move_destruction/operation_date',
      replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'move_destruction/operation_date', 
      d.DOC_NUM as 'move_destruction/doc_num',
      convert(varchar(10), d.INVOICE_DATE, 104) as 'move_destruction/doc_date',
      (select 
        dld.SGTIN as 'union/sgtin' 
      from 
        DM_DOC dd with (nolock)
        join DM_TRANSFERS dt with (nolock) on dd.DM_DOC_ID = dt.DM_DOC_ID
        join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
        join DM_LOTS_DETAIL dld with (nolock) on dld.DM_LOTS_ID = dl.DM_LOTS_ID
      where 
        dd.DM_DOC_ID = d.DM_DOC_ID
        and dl.MDLP = 1
      group by 
        dld.SGTIN
      for xml path ('')) as 'move_destruction/order_details'
    from 
      DM_DOC d with (nolock)
      join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
      join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
      join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
      left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
    where
      d.DM_DOC_ID = @dm_doc_id
    for xml path ('documents'))
  end
  --if @type_id = 542  --destruction
  --begin

  --end
  if @type_id = 552 --withdrawal ВЫВОД из Оборота
  begin
    set @err = (
    select 
      'Ошибка по DM_DOC_ID = ' + cast(d.DM_DOC_ID as varchar(10)) + char(10) + 
      case when w.DM_WAREHOUSES_ID is null then 'Не найден склад документа' + char(10) else '' end + 
      case when adrw.PLACE_OF_BUSINESS is null then 'Не задан идентификатор МД для склада' + char(10) else '' end +
      case when dt.DM_TRANSFERS_ID is null then 'Не найдены данные о движении партии'+ char(10) else '' end + 
      case when dl.DM_LOTS_ID is null then 'Не найдены данные о партии'+ char(10) else '' end
from 
      DM_DOC d with (nolock)
      left join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join FM_ORG_ADR adrw with (nolock) on w.FM_ORG_ADR_ID= adrw.FM_ORG_ADR_ID
      left join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID
      left join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1
    where
      d.DM_DOC_ID = @dm_doc_id
    )
    if replace(@err, char(10), '') = 'Ошибка по DM_DOC_ID = ' + cast(@dm_doc_id as varchar(10)) set @err = null
    
    if @err is null 
    set @msg = (
    select
      @version as '@version',
      @type_id as 'withdrawal/@action_id',
      adrw.PLACE_OF_BUSINESS as 'withdrawal/subject_id',
    --stuff(stuff(SYSDATETIMEOFFSET(), 20, 9, ''), 11, 1, 'T') as 'withdrawal/operation_date',
      replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'withdrawal/operation_date',
      d.DOC_NUM as 'withdrawal/doc_num',
      convert(varchar(10), d.INVOICE_DATE, 104) as 'withdrawal/doc_date',
      wi.WITHDRAWAL_TYPE_ENUM as 'withdrawal/withdrawal_type', 
(select 
        stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '') as 'sgtin' -- ???? должен быть SGTIN, а не SSCC
      from 
        DM_DOC dd with (nolock)
        join DM_TRANSFERS dt with (nolock) on dd.DM_DOC_ID = dt.DM_DOC_ID
        join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
        join DM_LOTS_DETAIL dld with (nolock) on dl.DM_LOTS_ID = dld.DM_LOTS_ID
      where 
        dd.DM_DOC_ID = d.DM_DOC_ID
        and dl.MDLP = 1
      group by 
        stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '') 
      for xml path ('')) as 'withdrawal/order_details'

    from 
      DM_DOC d with (nolock)
      join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
      left join FM_ORG_ADR adrw with (nolock) on w.FM_ORG_ADR_ID= adrw.FM_ORG_ADR_ID
      left join WITHDRAWAL_TYPE wi with (nolock) on wi.WITHDRAWAL_TYPE_ID=d.WITHDRAWAL_TYPE_ID
    where
      d.DM_DOC_ID = @dm_doc_id
    for xml path ('documents'))
  end




  if @type_id = 701 --accept
  begin
    if (select 
          avg(h.SSCC_TYPE)
        from 
          MDLP_REQUEST r with (nolock)
          join DM_DOC d with (nolock) on d.DM_DOC_ID = r.REC_ID
          join DM_TRANSFERS t with (nolock) on t.DM_DOC_ID = d.DM_DOC_ID
          join DM_LOTS l with (nolock) on l.DM_LOTS_ID = t.DM_LOTS_ID
          join MDLP_415_DETAILS md with (nolock) on md.DM_LOTS_ID = l.DM_LOTS_ID
          join MDLP_415_HEADER h with (nolock) on h.MDLP_415_HEADER_ID = md.MDLP_415_HEADER_ID
        where 
         r.MDLP_REQUEST_ID = @mdlp_id) = 0
    begin
--      set @type_id = 912
--      update MDLP_REQUEST set TYPE_ID = 9121 where MDLP_REQUEST_ID = @mdlp_id
        set @msg = (
        select
          @version as '@version',
          @type_id as 'accept/@action_id',
          adr_w.PLACE_OF_BUSINESS as 'accept/subject_id',
          adr_d.PLACE_OF_BUSINESS as 'accept/counterparty_id',
         -- stuff(stuff(SYSDATETIMEOFFSET(), 20, 9, ''), 11, 1, 'T') as 'accept/operation_date',
          replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'accept/operation_date',
          (select distinct
            case 
              when md.SSCC is null then stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '')
              else NULL
            end  as 'sgtin',
            md.SSCC  as 'sscc'
          from 
            DM_DOC dd with (nolock)
            join DM_TRANSFERS dt with (nolock) on dd.DM_DOC_ID = dt.DM_DOC_ID
            join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
            join DM_LOTS_DETAIL dld with (nolock) on dld.DM_LOTS_ID = dl.DM_LOTS_ID
            left join MDLP_415_DETAILS md with (nolock) on md.DM_LOTS_ID = dl.DM_LOTS_ID
          where 
            dd.DM_DOC_ID = d.DM_DOC_ID
            and dl.MDLP = 1
          for xml path ('')) as 'accept/order_details'
        from 
          DM_DOC d with (nolock)
          join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
          join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
          join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
          join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
          left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
          left join FM_ORG_ADR adr_w with (nolock) on w.FM_ORG_ADR_ID= adr_w.FM_ORG_ADR_ID
          left join FM_ORG_ADR adr_d with (nolock) on d.FM_ORG_ADR_ID = adr_d.FM_ORG_ADR_ID
        where
          d.DM_DOC_ID = @dm_doc_id
        for xml path ('documents'))


    end
    else
    begin
        set @err = (
        select top 1
          char(10) + 'Ошибка по DM_DOC_ID = ' + cast(d.DM_DOC_ID as varchar(10)) + char(10) + 
          --case when fo_s.MDLP_VENDOR_ID is null then 'Не найдена организация - отправитель' + char(10) else '' end + 
          case when adr_w.PLACE_OF_BUSINESS is null then 'Не найдена организация - отправитель' + char(10) else '' end + 
          case when adr_d.PLACE_OF_BUSINESS is null then 'Не найдена организация - получатель' + char(10) else '' end + 
          case when w.DM_WAREHOUSES_ID is null then 'Не найден склад документа' + char(10) else '' end + 
          case when fd.FM_DEP_ID is null then 'Не найдено отделение склада' + char(10) else '' end + 
          case when fo_r.FM_ORG_ID is null then 'Не найден филиал получателя' + char(10) else '' end + 
          case when dt.DM_TRANSFERS_ID is null then 'Не найдены данные о движении партии'+ char(10) else '' end + 
          case when not exists(select 1 from DM_LOTS dl with (nolock) left join DM_MEDS dm with (nolock) on dm.DM_MEDS_ID = dl.DM_MEDS_ID where dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1) then 'Не найдены данные о медикаменте партии партии'+ char(10) else '' end + 
          case when not exists(select 1 from DM_LOTS dl with (nolock) where dt.DM_LOTS_ID = dl.DM_LOTS_ID and dl.MDLP = 1) then 'Не найдены данные о партии'+ char(10) else '' end

        from 
          DM_DOC d with (nolock)
          left join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
          left join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
          left join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
          left join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
          left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
          left join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID

          left join FM_ORG_ADR adr_w with (nolock) on w.FM_ORG_ADR_ID= adr_w.FM_ORG_ADR_ID
          left join FM_ORG_ADR adr_d with (nolock) on d.FM_ORG_ADR_ID = adr_d.FM_ORG_ADR_ID
      
        where
          d.DM_DOC_ID = @dm_doc_id

        )
    
        if replace(@err, char(10), '') = 'Ошибка по DM_DOC_ID = ' + cast(@dm_doc_id as varchar(10)) set @err = null

        if @err is null 
        set @msg = (
        select
          @version as '@version',
          @type_id as 'accept/@action_id',
          adr_w.PLACE_OF_BUSINESS as 'accept/subject_id',
          adr_d.PLACE_OF_BUSINESS as 'accept/counterparty_id',
         -- stuff(stuff(SYSDATETIMEOFFSET(), 20, 9, ''), 11, 1, 'T') as 'accept/operation_date',
          replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'accept/operation_date',
          (select distinct
            stuff(stuff(left(replace(dld.SGTIN, char(29), ascii(29)), 31), 1, 2, ''), 15, 2, '')  as 'sgtin'
          from 
            DM_DOC dd with (nolock)
            join DM_TRANSFERS dt with (nolock) on dd.DM_DOC_ID = dt.DM_DOC_ID
            join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
            join DM_LOTS_DETAIL dld with (nolock) on dld.DM_LOTS_ID = dl.DM_LOTS_ID
          where 
            dd.DM_DOC_ID = d.DM_DOC_ID
            and dl.MDLP = 1
          for xml path ('')) as 'accept/order_details'
        from 
          DM_DOC d with (nolock)
          join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
          join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
          join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
          join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
          left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
          left join FM_ORG_ADR adr_w with (nolock) on w.FM_ORG_ADR_ID= adr_w.FM_ORG_ADR_ID
          left join FM_ORG_ADR adr_d with (nolock) on d.FM_ORG_ADR_ID = adr_d.FM_ORG_ADR_ID
        where
          d.DM_DOC_ID = @dm_doc_id
        for xml path ('documents'))
    end
  end
  
  if @type_id in (9121)
  begin
        set @msg = (
            select distinct
              @version as '@version',
              912 as 'unit_unpack/@action_id',
              adr_w.PLACE_OF_BUSINESS as 'unit_unpack/subject_id',
              replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'unit_unpack/operation_date',
              ml.SSCC as 'unit_unpack/sscc',
              1 as 'unit_unpack/is_recursive'
            from 
              DM_DOC d with (nolock)
              join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID
              join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
              join MDLP_415_DETAILS ml   with (nolock) on ml.DM_LOTS_ID = dl.DM_LOTS_ID
              join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
              join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
              join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
              join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
              left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
              left join FM_ORG_ADR adr_w with (nolock) on w.FM_ORG_ADR_ID= adr_w.FM_ORG_ADR_ID
              left join FM_ORG_ADR adr_d with (nolock) on d.FM_ORG_ADR_ID = adr_d.FM_ORG_ADR_ID
            where
              d.DM_DOC_ID = @dm_doc_id
            for xml path ('documents'))
  end 

  if @type_id in (912)
  begin
        set @msg = (
            select distinct
              @version as '@version',
              912 as 'unit_unpack/@action_id',
              adr_w.PLACE_OF_BUSINESS as 'unit_unpack/subject_id',
              replace(convert(nvarchar(MAX), getdate(), 20),' ','T')+'+0'+convert(varchar,DateDiff(hh,GetUTCDate(),GetDate()))+':00' as 'unit_unpack/operation_date',
              isnull(dl.SSCC, md.SSCC) as 'unit_unpack/sscc',
              1 as 'unit_unpack/is_recursive'
            from 
              DM_DOC d with (nolock)
              join DM_TRANSFERS dt with (nolock) on d.DM_DOC_ID = dt.DM_DOC_ID
              join DM_LOTS dl with (nolock) on dt.DM_LOTS_ID = dl.DM_LOTS_ID
              left join MDLP_415_DETAILS md with (nolock) on md.DM_LOTS_ID = dl.DM_LOTS_ID
              join FM_ORG fo_s with (nolock) on fo_s.FM_ORG_ID = d.FM_ORG_ID
              join DM_WAREHOUSES w with (nolock) on w.DM_WAREHOUSES_ID = d.DM_WAREHOUSES_ID
              join FM_DEP fd with (nolock) on fd.FM_DEP_ID = w.FM_DEP_ID
              join FM_ORG fo_r with (nolock) on fo_r.FM_ORG_ID = fd.MAIN_ORG_ID
              left join FM_ORG fo_rm with (nolock) on fo_rm.FM_ORG_ID = fo_r.FM_ORG_MAIN_ID
              left join FM_ORG_ADR adr_w with (nolock) on w.FM_ORG_ADR_ID= adr_w.FM_ORG_ADR_ID
              left join FM_ORG_ADR adr_d with (nolock) on d.FM_ORG_ADR_ID = adr_d.FM_ORG_ADR_ID
            where
              d.DM_DOC_ID = @dm_doc_id
            for xml path ('documents'))
  end 


  set @msg = replace(replace(replace(@msg, '&amp;', '&'), '&gt;','>'), '&lt;','<')

  
  set @msg = '<?xml version="1.0" encoding="UTF-8"?>'--+ char(10)
     + @msg


  --set @msg ='PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPGRvY3VtZW50cyB2ZXJzaW9uPSIxLjM0IiB4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KCTxhY2NlcHQgYWN0aW9uX2lkPSI3MDEiPgoJCTxzdWJqZWN0X2lkPjAwMDAwMDAwMTA5MjA5PC9zdWJqZWN0X2lkPgoJCTxjb3VudGVycGFydHlfaWQ+MDAwMDAwMDAxMDQ0OTQ8L2NvdW50ZXJwYXJ0eV9pZD4KCQk8b3BlcmF0aW9uX2RhdGU+MjAxOS0xMS0xOVQwODowNzowMCswNDowMDwvb3BlcmF0aW9uX2RhdGU+CgkJPG9yZGVyX2RldGFpbHM+CQkKCQkJPHNndGluPjUwNzU0MDQxMzk4NzY1ODg4MDAwMDA4ODg4NTwvc2d0aW4+CgkJPC9vcmRlcl9kZXRhaWxzPgoJPC9hY2NlcHQ+CjwvZG9jdW1lbnRzPg=='

--  set @msg = dbo.Base64Encode(@msg)
end
go

