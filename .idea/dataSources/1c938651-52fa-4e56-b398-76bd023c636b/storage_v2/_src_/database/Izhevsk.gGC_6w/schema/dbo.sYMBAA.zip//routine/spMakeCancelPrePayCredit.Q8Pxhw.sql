

CREATE PROCEDURE [dbo].[spMakeCancelPrePayCredit]
	@FM_PM_IDs varchar(max),
	@accOper int,
	@accCheckId int,
	@checkStatus varchar(1),
	@meddep_id int,
	@usrEmailOrPhone int, 
	@EmailOrPhone varchar(255)
AS
BEGIN
	SET NOCOUNT ON;
	set @FM_PM_IDs = nullif(@FM_PM_IDs, '')
	set @accOper = nullif(@accOper, 0)
	set @accCheckId = nullif(@accCheckId, 0)

	if @FM_PM_IDs is null
	begin
		select 0 FM_ACCOUNT_TRAN_ID
		return
	end

	declare @medecins_id int, @fm_dep_id int
	declare @err_mess varchar(2048)
	begin try
		begin tran
			select @medecins_id = medecins_id, @fm_dep_id = fm_dep_id from meddep with(nolock) where meddep_id = @meddep_id
			select distinct 1 newFM_ACCOUNT_TRAN_ID, p.FM_ACCOUNT_TRAN_ID, p.FM_PAYMENTS_ID, p.TRAN_AMOUNT + isnull(p.DISCOUNT_AMOUNT, 0) TRAN_SUM
			       , case when @accCheckId is null then t.FM_ACC_CHECK_ID else @accCheckId end FM_ACC_CHECK_ID, ac.EMAIL_PHONE_CLIENT
				into #selU
				from FM_ACCOUNT_TRAN t with (nolock)
				left join FM_ACC_CHECK ac with (nolock)
					on t.FM_ACC_CHECK_ID = ac.FM_ACC_CHECK_ID
				join FM_PAYMENTS p with (nolock)
					on p.FM_ACCOUNT_TRAN_ID = t.FM_ACCOUNT_TRAN_ID
				left join FM_ACCOUNT_TRAN tc with (nolock)
					on tc.FM_MAIN_TRAN_ID = t.FM_ACCOUNT_TRAN_ID and tc.TRAN_TYPE in ('G','H','L','M')
				left join FM_PAYMENTS pc with (nolock)
					on pc.FM_ACCOUNT_TRAN_ID = tc.FM_ACCOUNT_TRAN_ID and p.FM_BILLDET_PAY_ID = pc.FM_BILLDET_PAY_ID
				where pc.FM_PAYMENTS_ID is null and p.FM_PAYMENTS_ID in (select id from dbo.intlist_to_table(@FM_PM_IDs))

			declare @cntAT int, @cntPay int, @firstACCOUNT_TRAN_ID int, @firstPAYMENTS_ID int, @cntCheck int, @firstCHECK_ID int

			select @cntAT = count(*) from 
				(select FM_ACCOUNT_TRAN_ID from #selU
					group by FM_ACCOUNT_TRAN_ID) a

			select @cntPay = count(*) from #selU

			if @cntAT > 0
			begin
				exec dbo.up_get_id @KeyName = 'FM_ACCOUNT_TRAN', @Shift = @cntAT, @ID = @firstACCOUNT_TRAN_ID output 
				exec dbo.up_get_id @KeyName = 'FM_PAYMENTS', @Shift = @cntPay, @ID = @firstPAYMENTS_ID output 


				update p
					set 
						 newFM_ACCOUNT_TRAN_ID = newI + @firstACCOUNT_TRAN_ID - 1
					from #selU p
				join (select *, dense_rank() over (order by FM_ACCOUNT_TRAN_ID) newI from #selU) pp
					on p.FM_ACCOUNT_TRAN_ID = pp.FM_ACCOUNT_TRAN_ID


				if @accCheckId is NULL
				BEGIN
					select @cntCheck = count(distinct FM_ACC_CHECK_ID) from #selU

					exec dbo.up_get_id @KeyName = 'FM_ACC_CHECK', @Shift = @cntCheck, @ID = @firstCHECK_ID output 

					update p
						set 
							 FM_ACC_CHECK_ID = newI + @firstCHECK_ID - 1
						from #selU p
					join (select *, dense_rank() over (order by FM_ACC_CHECK_ID) newI from #selU) pp
						on p.FM_ACCOUNT_TRAN_ID = pp.FM_ACCOUNT_TRAN_ID

					INSERT INTO [dbo].[FM_ACC_CHECK]
							   ([FM_ACC_CHECK_ID]
							   ,[FM_ACC_CHECK_STATUS]
							   ,[OPERATION_TYPE]
							   ,[EMAIL_PHONE_CLIENT]
							   ,[MEDDEP_ID])
						SELECT FM_ACC_CHECK_ID, @checkStatus, 2, case when @usrEmailOrPhone =1 then @EmailOrPhone else min(EMAIL_PHONE_CLIENT) end, @meddep_id
							FROM #selU
							GROUP BY FM_ACC_CHECK_ID
				END

------------------------------------------------------------
				INSERT INTO [dbo].[FM_ACCOUNT_TRAN]
						   ([FM_ACCOUNT_TRAN_ID]
						   ,[FM_ACCOUNT_ID]
						   ,[TRAN_DATE]
						   ,[MEDECINS_ID]
						   ,[TRAN_SUM]
						   ,[TRAN_SUM_DEV]
						   ,[FM_DEVISE_ID]
						   ,[FM_PAYMODE_ID]
						   ,[PAY_INFO]
						   ,[TRAN_TYPE]
						   ,[FM_MAIN_TRAN_ID]
						   ,[CASH]
						   ,[DEVERS_ID]
						   ,[FM_TRAN_DEBIT_ID]
						   ,[FM_TRAN_CREDIT_ID]
						   ,[ECR_NUM]
						   ,[SHIFT_CLOSED]
						   ,[WODOLG]
						   ,[CHECK_NUM]
						   ,[DM_DOC_ID]
						   ,[DATE_CREATE]
						   ,[MEDECINS_MODIFY_ID]
						   ,[DATE_MODIFY]
						   ,[FM_CONTR_ID]
						   ,[FM_DEP_ID]
						   ,[RETAIL_NUM]
						   ,[WRITTEN_OFF]
						   ,[AUTOCREATED]
						   ,[FROM_INCOME]
						   ,[CASH_SUM]
						   ,[CHANGE_SUM]
						   ,[CHECK_TRAN_ID]
						   ,[LOYALITY_TRAN_ID]
						   ,[LY_FLAYERS]
						   ,[LY_CARD]
						   ,[EXT_ID]
						   ,[MEDDEP_ID]
						   ,[FFD_COMPATIBLE]
						   ,[ACC_OPERATION]
						   ,[FM_ACC_CHECK_ID])
					 SELECT
							newFM_ACCOUNT_TRAN_ID
						   ,[FM_ACCOUNT_ID]
						   ,dbo.fnGetDateLocal()
						   ,@medecins_id
						   ,pat.sm
						   ,pat.sm
						   ,[FM_DEVISE_ID]
						   ,[FM_PAYMODE_ID]
						   ,[PAY_INFO]
						   ,case [TRAN_TYPE] when '3' then 'H' when '4' then 'G' when '5' then 'L' when '6' then 'M' end
						   ,pat.FM_ACCOUNT_TRAN_ID
						   ,[CASH]
						   ,[DEVERS_ID]
						   ,[FM_TRAN_DEBIT_ID]
						   ,[FM_TRAN_CREDIT_ID]
						   ,[ECR_NUM]
						   ,[SHIFT_CLOSED]
						   ,[WODOLG]
						   ,[CHECK_NUM]
						   ,[DM_DOC_ID]
						   ,dbo.fnGetDateLocal()
						   ,@medecins_id
						   ,dbo.fnGetDateLocal()
						   ,[FM_CONTR_ID]
						   ,@fm_dep_id
						   ,[RETAIL_NUM]
						   ,[WRITTEN_OFF]
						   ,[AUTOCREATED]
						   ,[FROM_INCOME]
						   ,[CASH_SUM]
						   ,[CHANGE_SUM]
						   ,[CHECK_TRAN_ID]
						   ,[LOYALITY_TRAN_ID]
						   ,[LY_FLAYERS]
						   ,[LY_CARD]
						   ,[EXT_ID]
						   ,@meddep_id
						   ,[FFD_COMPATIBLE]
						   ,@accOper
						   ,pat.FM_ACC_CHECK_ID
						from FM_ACCOUNT_TRAN a with (nolock)
        				join (select FM_ACCOUNT_TRAN_ID, newFM_ACCOUNT_TRAN_ID, FM_ACC_CHECK_ID, sum(TRAN_SUM) sm from #selU
								group by FM_ACCOUNT_TRAN_ID, newFM_ACCOUNT_TRAN_ID, FM_ACC_CHECK_ID) pat
							on a.FM_ACCOUNT_TRAN_ID = pat.FM_ACCOUNT_TRAN_ID
					
					INSERT INTO [dbo].[FM_PAYMENTS]
							   ([FM_PAYMENTS_ID]
							   ,[FM_BILLDET_PAY_ID]
							   ,[FM_ACCOUNT_TRAN_ID]
							   ,[TRAN_AMOUNT]
							   ,[TAXE_PERC]
							   ,[TAXE_AMOUNT]
							   ,[TAXE_VAT_PERC]
							   ,[FM_INVOICE_ID]
							   ,[TAXE_VAT_AMOUNT]
							   ,[WODOLG]
							   ,[UNDO_AMOUNT]
							   ,[MAIN_PAYMENTS_ID]
							   ,[FM_PAY_SECTION_ID]
							   ,[DM_TRANSFERS_ID]
							   ,[FM_DISCOUNT_ID]
							   ,[DISCOUNT_PERC]
							   ,[DISCOUNT_AMOUNT]
							   ,[IS_DEBT]
							   ,[FM_PAYMENT_TAG])
					select 
								row_number() over (order by pat.FM_PAYMENTS_ID) + @firstPAYMENTS_ID - 1
							   ,[FM_BILLDET_PAY_ID]
							   ,pat.newFM_ACCOUNT_TRAN_ID
							   ,-1 * p.[TRAN_AMOUNT]
							   ,[TAXE_PERC]
							   ,[TAXE_AMOUNT]
							   ,[TAXE_VAT_PERC]
							   ,[FM_INVOICE_ID]
							   ,-1 * [TAXE_VAT_AMOUNT]
							   ,[WODOLG]
							   ,null --[UNDO_AMOUNT]
							   ,p.FM_PAYMENTS_ID
							   ,[FM_PAY_SECTION_ID]
							   ,[DM_TRANSFERS_ID]
							   ,[FM_DISCOUNT_ID]
							   ,-1 * [DISCOUNT_PERC]
							   ,-1 * [DISCOUNT_AMOUNT]
							   ,[IS_DEBT]
							   ,[FM_PAYMENT_TAG]
						from FM_PAYMENTS p with (nolock)
        				join #selU pat
							on p.FM_PAYMENTS_ID = pat.FM_PAYMENTS_ID

				update p
					set p.UNDO_AMOUNT = p.TRAN_AMOUNT
					from FM_PAYMENTS p
					join #selU s
						on p.FM_PAYMENTS_ID = s.FM_PAYMENTS_ID

				SELECT newFM_ACCOUNT_TRAN_ID FM_ACCOUNT_TRAN_ID, FM_ACC_CHECK_ID from #selU
				
			end
			else
				select 0 FM_ACCOUNT_TRAN_ID, 0 FM_ACC_CHECK_ID
		commit tran
	end try
	begin catch
		select 
			@err_mess = 
			'Error ' + convert(varchar(10) , ERROR_NUMBER()) + 
			', Procedure ' + ISNULL(ERROR_PROCEDURE(), '-') +
			', Line ' + convert(varchar(100) , ERROR_LINE()) + 
			', Message: '+ ERROR_MESSAGE()      
		if @@trancount > 0
			rollback tran  
		raiserror(@err_mess, 16, 10)  
	end catch  
END
go

