CREATE procedure [dbo].[spRebuildDemandDirAnsws]
  @PATIENTS_ID int = null,
  @PATDIREC_ID int = null,
  @FM_BILL_ID  int = null

as
begin
  declare
    @DirAnswCount INT,
    @TaskCount INT,
    @DemandId INT

  if IsNull(@PATDIREC_ID, 0) > 0 
  begin
	-- По требованию получаем количество его заданий и имеющееся на данный момент количеством DIR_ANSW
	select 
	  @DirAnswCount = count(da.patdirec_id), 
	  @TaskCount = count(dst.patdirec_id) 
	from dir_serv dsd
	  join fm_billdet_task bdt on bdt.demand_dir_serv_id = dsd.dir_serv_id
	  join dir_serv dst on dst.dir_serv_id = bdt.dir_serv_id
	  left join dir_answ da on da.patdirec_id = dsd.patdirec_id 
    join patdirec d on d.patdirec_id = dsd.patdirec_id
	where dsd.patdirec_id = @PATDIREC_ID and d.PATDIREC_TYPE = 3
	group by dsd.patdirec_id 
	
	if @DirAnswCount <> @TaskCount
	begin
      exec RebuildPatdirecDirAnsws @PATDIREC_ID, 1, 0, 0, @TaskCount
	end
  end
  else
  if IsNull(@FM_BILL_ID, 0) > 0 
  begin
    -- По смете получаем список требований с количеством его заданий и имеющимся на данный момент количеством DIR_ANSW
    declare Demands cursor static read_only forward_only for
    select dsd.patdirec_id, count(distinct da.dir_answ_id) answ_count, count(distinct dst.patdirec_id) task_count 
    from fm_bill b
      join fm_billdet bd on bd.fm_bill_id = b.fm_bill_id
      join fm_billdet_task bdt on bdt.fm_billdet_id = bd.fm_billdet_id
      join dir_serv dst on dst.dir_serv_id = bdt.dir_serv_id
      join dir_serv dsd on dsd.dir_serv_id = bdt.demand_dir_serv_id
      join patdirec d on d.patdirec_id = dsd.patdirec_id
      left join dir_answ da on da.patdirec_id = dsd.patdirec_id 
    where b.fm_bill_id = @FM_BILL_ID and d.PATDIREC_TYPE = 3
    group by dsd.patdirec_id 
    having count(distinct da.dir_answ_id) <> count(distinct dst.patdirec_id)

    open Demands
    while (1 = 1)
    begin
      fetch next
      from Demands
      into @DemandId,
           @DirAnswCount,
           @TaskCount

      if @@Fetch_Status <> 0 
        break 
        
      exec RebuildPatdirecDirAnsws @DemandId, 1, 0, 0, @TaskCount
    end

    close Demands
    deallocate Demands
  end 
end
go

