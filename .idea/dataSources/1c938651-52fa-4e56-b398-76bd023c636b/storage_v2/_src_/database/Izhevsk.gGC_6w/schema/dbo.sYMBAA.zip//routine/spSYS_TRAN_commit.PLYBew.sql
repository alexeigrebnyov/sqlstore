CREATE procedure [dbo].[spSYS_TRAN_commit]
  @SYS_TRAN_ID int = null,
  @ERR_MESS    varchar(255) = null output
as
begin
  set nocount on
  
  declare 
    @ErrorMessage    varchar(4000),
    @ErrorNumber     int,
    @ErrorSeverity   int,
    @ErrorState      int,
    @ErrorLine       int,
    @ErrorProcedure  varchar(200),
    @cur             cursor,
    @PatdirecID      int,
    @ret             int,
    @insertPart      varchar(4000),
    @selectPart      varchar(4000),
    @dynamicSQL      varchar(8000),
    @tranState       char(1)   
    
  declare @deleted_dir_servs table (DIR_SERV_ID int null)    

  select
    @ERR_MESS = null,
    @ret = 0

  select
      @tranState = [STATE]
    from dbo.SYS_TRAN with (nolock)
    where SYS_TRAN_ID = @SYS_TRAN_ID
   
  select 
    @ERR_MESS = case
                  when nullif(@SYS_TRAN_ID, 0) is null then '@SYS_TRAN_ID is null'
                  when @tranState = 'C' then 'Logical transaction ' + convert(varchar, @SYS_TRAN_ID) + ' already commited'
                  when @tranState = 'R' then 'Logical transaction ' + convert(varchar, @SYS_TRAN_ID) + ' already rollbacked'
                end  
  if @ERR_MESS is not null
  begin
    set @ret = -1 
    goto err_label
  end                   
  
  begin try
    begin transaction
  
-- Монопольная блокировка таблицы до конца транзакции
    select
        @tranState = [STATE]
      from dbo.SYS_TRAN with (TABLOCKX, SERIALIZABLE)
      where SYS_TRAN_ID = @SYS_TRAN_ID
  
    insert into dbo.PATDIREC (
      PATDIREC_ID,
      PATIENTS_ID,
      MOTCONSU_ID,
      MEDECINS_ID,
      BEGIN_DATE_TIME,
      END_DATE_TIME,
      CP_ITEM_ID, 
      CP_STAGE_ITEM_ID,  
      MEDECINS_CREATOR_ID,
      CREATE_DATE_TIME,
      VIP_GROUPS_ID,
      PL_EXAM_ID,
      FM_INTORG_ID,
      QUANTITY,
      DIR_STATE,
      MANIPULATIVE,
      FM_BILLDET_CR_ID,
      BIO_TYPE,
      COMMENTAIRE,
      [DESCRIPTION],
      PATDIREC_KIND,
      MEDDEP_ID,
      PLANNING_CR_ID,
      CANCELLED,
      STANDARTED,
      CITO,
      NEED_OPEN_EDITOR,
      KEEP_INTAKE_TIME,
      AUTO_CITO
    )
    select
        PATDIREC_ID,
        PATIENTS_ID,
        MOTCONSU_ID,
        MEDECINS_ID,
        BEGIN_DATE_TIME,
        END_DATE_TIME,
        CP_ITEM_ID, 
        CP_STAGE_ITEM_ID,  
        MEDECINS_CREATOR_ID,
        CREATE_DATE_TIME,
        VIP_GROUPS_ID,
        PL_EXAM_ID,
        FM_INTORG_ID,
        QUANTITY,
        DIR_STATE,
        MANIPULATIVE,
        FM_BILLDET_CR_ID,
        BIO_TYPE,
        COMMENTAIRE,
        [DESCRIPTION],
        PATDIREC_KIND,
        MEDDEP_ID,
        PLANNING_CR_ID,
        0,
        0,
        0,
        0,
        0,
        0
      from dbo.SYS_TMP_PATDIREC with (nolock)
      where SYS_TRAN_ID = @SYS_TRAN_ID

    insert into @deleted_dir_servs (DIR_SERV_ID)
      select
          DS.DIR_SERV_ID
        from
        (
          select
              P.PATDIREC_ID
            from dbo.SYS_TMP_PATDIREC P with (nolock, index(PK_SYS_TMP_PATDIREC))
            where P.SYS_TRAN_ID = @SYS_TRAN_ID
          union 
          select
              D.PATDIREC_ID
            from dbo.SYS_TMP_DIR_SERV D with (nolock, index(PK_SYS_TMP_DIR_SERV))
            where D.SYS_TRAN_ID = @SYS_TRAN_ID
        ) P
        inner loop join dbo.DIR_SERV DS with (nolock, index(idxPATDIREC_ID))
           on DS.PATDIREC_ID = P.PATDIREC_ID
        inner join dbo.PATDIREC PD with (nolock, index(PK_PATDIREC))   
           on PD.PATDIREC_ID = DS.PATDIREC_ID
        inner join dbo.FM_BILLDET BD with (nolock, index(PK_FM_BILLDET))
           on BD.FM_BILLDET_ID = PD.FM_BILLDET_CR_ID
        inner join dbo.FM_BILL B with (nolock, index(PK_FM_BILL))
           on B.FM_BILL_ID = BD.FM_BILL_ID
          and B.BILL_TYPE = 1 -- только для сметы 
        left hash join dbo.SYS_TMP_DIR_SERV T with (nolock, index(PK_SYS_TMP_DIR_SERV))
           on T.SYS_TRAN_ID = @SYS_TRAN_ID
          and T.DIR_SERV_ID = DS.DIR_SERV_ID
        where T.DIR_SERV_ID is null        
        option (force order, maxdop 1)
        
    update BD
        set BD.DIR_SERV_ID = null
      from @deleted_dir_servs T
      inner join dbo.FM_BILLDET BD with (index(idxDIR_SERV_ID))
         on BD.DIR_SERV_ID = T.DIR_SERV_ID

    delete DS
      from @deleted_dir_servs T
      inner join dbo.DIR_SERV DS with (index(PK_DIR_SERV))
         on DS.DIR_SERV_ID = T.DIR_SERV_ID
           
    update DS
        set DS.CNT = T.CNT
      from dbo.SYS_TMP_DIR_SERV T with (nolock, index(PK_SYS_TMP_DIR_SERV))
      inner join dbo.DIR_SERV DS with (index(PK_DIR_SERV))
         on DS.DIR_SERV_ID = T.DIR_SERV_ID
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
        
    insert into dbo.DIR_SERV (
      DIR_SERV_ID,
      PATDIREC_ID,
      PATIENTS_ID,
      FM_SERV_ID,
      CNT,
      PAYER,
      FREE_PAY
    )
    select
        T.DIR_SERV_ID,
        T.PATDIREC_ID,
        T.PATIENTS_ID,
        T.FM_SERV_ID,
        T.CNT,
        T.PAYER,
        T.FREE_PAY
      from dbo.SYS_TMP_DIR_SERV T with (nolock, index(PK_SYS_TMP_DIR_SERV))
      left hash join dbo.DIR_SERV DS with (nolock, index(PK_DIR_SERV))
         on DS.DIR_SERV_ID = T.DIR_SERV_ID      
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
        and DS.DIR_SERV_ID is null



    set @cur = cursor static read_only forward_only for
      select 
          PATDIREC_ID 
        from dbo.SYS_TMP_PATDIREC with (nolock)
        where SYS_TRAN_ID = @SYS_TRAN_ID
      union  
      select 
          PATDIREC_ID 
        from dbo.SYS_TMP_DIR_SERV with (nolock)
        where SYS_TRAN_ID = @SYS_TRAN_ID
    open @cur
    
    while 1=1 
    begin
      fetch next from @cur
        into @PatdirecID
        
      if @@Fetch_Status <> 0 
        break  

      exec dbo.RebuildPatdirecDirAnsws
        @APatdirId = @PatdirecID,
        @AMsgKind = 2,
        @APlaneDate = null,
        @APlanningId = null             
    end
    close @cur
    deallocate @cur
    
    delete BD
      from dbo.SYS_TMP_BILLDET T with (nolock, index(PK_SYS_TMP_BILLDET))
      inner join dbo.FM_BILLDET BD with (updlock, index(PK_FM_BILLDET))
         on BD.FM_BILLDET_ID = T.FM_BILLDET_ID
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
        and isnull(T.DEL, '') = 'Y'

    update BD
        set BD.CANCEL = T.CANCEL,
            BD.BLOCKED = T.BLOCKED,
            BD.CNT = T.CNT,
            BD.PRICE = SBD.PRICE,
            BD.TOTAL_PRICE = SBD.TOTAL_PRICE * T.CNT / SBD.CNT,
            BD.PRICE_TO_PAY = SBD.PRICE_TO_PAY * T.CNT / SBD.CNT,
            BD.DISCOUNT_AMOUNT = SBD.DISCOUNT_AMOUNT * T.CNT / SBD.CNT,
            BD.FRANCHISE = SBD.FRANCHISE * T.CNT / SBD.CNT,
            BD.ORG_FIXED_AMOUNT = SBD.ORG_FIXED_AMOUNT * T.CNT / SBD.CNT,
            BD.ORG_FIXED_CNT = convert(int, SBD.ORG_FIXED_CNT * T.CNT / SBD.CNT),
            BD.PRICE_PAT = SBD.PRICE_PAT * T.CNT / SBD.CNT,
            BD.RENDER_DATE_BEGIN = case
                                     when B.MOTCONSU_ID is not null then coalesce(BD.RENDER_DATE_BEGIN, T.RENDER_DATE_BEGIN)
                                     when T.DONE = 1 then coalesce(T.RENDER_DATE_BEGIN, BD.RENDER_DATE_BEGIN)
                                   end,
            BD.RENDER_DATE_END = case
                                   when B.MOTCONSU_ID is not null then coalesce(BD.RENDER_DATE_END, T.RENDER_DATE_END)
                                   when T.DONE = 1 then coalesce(T.RENDER_DATE_END, BD.RENDER_DATE_END)
                                 end,
            BD.DONE = case when B.MOTCONSU_ID is null then T.DONE else BD.DONE end,
            BD.FORCE_DONE = case when B.MOTCONSU_ID is null then 1 else BD.FORCE_DONE end
      from dbo.SYS_TMP_BILLDET T with (nolock, index(PK_SYS_TMP_BILLDET))
      inner join dbo.FM_BILLDET BD with (updlock, index(PK_FM_BILLDET))
         on BD.FM_BILLDET_ID = T.FM_BILLDET_ID
      inner join dbo.FM_BILL B with (nolock, index(PK_FM_BILL))
         on B.FM_BILL_ID = BD.FM_BILL_ID
      inner join dbo.FM_BILLDET SBD with (updlock, index(PK_FM_BILLDET))
         on SBD.FM_BILLDET_ID = BD.SMETA_BILLDET_ID
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
        and isnull(T.DEL, '') <> 'Y'
      option (force order, loop join, maxdop 1)

  select
    @insertPart = '',
    @selectPart = '' 
   
  select 
      @insertPart = @insertPart + ',' + char(13) + char(10) + name,
      @selectPart  = @selectPart + ',' + char(13) + char(10) + 
        case
          when name in ('FM_BILLDET_ID','FM_BILL_ID','SMETA_BILLDET_ID','CANCEL','BLOCKED','CNT','TOTAL_PRICE','PRICE_TO_PAY',
                        'MAIN_BILLDET_ID','FRANCHISE','ORG_FIXED_AMOUNT','ORG_FIXED_CNT','PRICE_PAT','PATDIREC_QUANTITY',
                        'PATDIREC_DONE_CNT','PATDIREC_CANCEL_CNT','DIR_SERV_ID','DM_SERVPRICE_ID','MEDECINS_DONE_ID','DONE','FORCE_DONE',
                        'MEDECINS2_DONE_ID','DISCOUNT','DISCOUNT_AMOUNT','FREE_PAY','PROVIDED','IS_MAIN_SERV','RENDER_DATE_BEGIN','RENDER_DATE_END')
            then '  T.' + name
          else '  BD.' + name              
        end  
    from sys.columns 
    where object_id = object_id('dbo.FM_BILLDET') 
      and name not like 'KRN_%'
      
  set @dynamicSQL = 'insert into dbo.FM_BILLDET (' + substring(@insertPart, 3, 4000) + ')' + char(13) + char(10) + 'select ' +
     + substring(@selectPart, 3, 4000) + char(13) + char(10) +    
    'from
    (
      select
          T.FM_BILLDET_ID,
          T.FM_BILL_ID,
          T.MAIN_BILLDET_ID,
          T.SMETA_BILLDET_ID,
          T.CANCEL,
          T.BLOCKED,
          T.CNT,
          TOTAL_PRICE = SBD.TOTAL_PRICE * T.CNT / SBD.CNT,
          PRICE_TO_PAY = SBD.PRICE_TO_PAY * T.CNT / SBD.CNT,
          FRANCHISE = SBD.FRANCHISE * T.CNT / SBD.CNT,
          ORG_FIXED_AMOUNT = SBD.ORG_FIXED_AMOUNT * T.CNT / SBD.CNT,
          ORG_FIXED_CNT = convert(int, SBD.ORG_FIXED_CNT * T.CNT / SBD.CNT),
          PRICE_PAT = SBD.PRICE_PAT * T.CNT / SBD.CNT,
          PATDIREC_QUANTITY = null,
          PATDIREC_DONE_CNT = null,
          PATDIREC_CANCEL_CNT = null,
          DIR_SERV_ID = null,
          DM_SERVPRICE_ID = null,
          MEDECINS_DONE_ID = null,
          MEDECINS2_DONE_ID = null,
          DISCOUNT = null,
          DISCOUNT_AMOUNT = SBD.DISCOUNT_AMOUNT * T.CNT / SBD.CNT,
          FREE_PAY = cast(1 as bit),
          PROVIDED = cast(0 as bit),
          IS_MAIN_SERV = case
                           when T.FM_BILLDET_ID = T.MAIN_BILLDET_ID then 1
                           else 0
                         end,
          RENDER_DATE_BEGIN = case
                                when B.MOTCONSU_ID is not null then coalesce(BD.RENDER_DATE_BEGIN, T.RENDER_DATE_BEGIN)
                                when T.DONE = 1 then coalesce(T.RENDER_DATE_BEGIN, BD.RENDER_DATE_BEGIN)
                              end,                   
          RENDER_DATE_END = case
                              when B.MOTCONSU_ID is not null then coalesce(BD.RENDER_DATE_END, T.RENDER_DATE_END)
                              when T.DONE = 1 then coalesce(T.RENDER_DATE_END, BD.RENDER_DATE_END)
                            end,
          DONE = case when B.MOTCONSU_ID is null then T.DONE else BD.DONE end,
          FORCE_DONE = case when B.MOTCONSU_ID is null then 1 else BD.FORCE_DONE end                                     
        from dbo.SYS_TMP_BILLDET T with (nolock, index(PK_SYS_TMP_BILLDET))
        inner join dbo.FM_BILLDET SBD with (updlock, index(PK_FM_BILLDET))
           on SBD.FM_BILLDET_ID = T.SMETA_BILLDET_ID
        left join FM_BILLDET BD with (updlock, index(PK_FM_BILLDET))   
           on BD.FM_BILLDET_ID = T.FM_BILLDET_ID
        left join FM_BILL B with (nolock, index(PK_FM_BILL))   
           on B.FM_BILL_ID = BD.FM_BILL_ID
        where T.SYS_TRAN_ID = ' + convert(varchar, @SYS_TRAN_ID) + '
          and isnull(T.DEL, '''') <> ''Y''
          and BD.FM_BILLDET_ID is null 
    ) T
    inner join dbo.FM_BILLDET BD with (updlock, index(PK_FM_BILLDET))
       on BD.FM_BILLDET_ID = T.SMETA_BILLDET_ID
    option (force order, loop join, maxdop 1)'
      
    exec(@dynamicSQL) 
    
    update BDP
        set BDP.CANCEL = T.CANCEL
      from dbo.SYS_TMP_BILLDET T with (nolock, index(PK_SYS_TMP_BILLDET))
      inner join dbo.FM_BILLDET_PAY BDP with (nolock, index(idxFM_BILLDET_DONE_ID))
         on BDP.FM_BILLDET_DONE_ID = T.FM_BILLDET_ID
        and isnull(BDP.CANCEL, 0) <> isnull(T.CANCEL, 0) 
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
        and isnull(T.DEL, '') <> 'Y'
      option (force order, loop join, maxdop 1)     
     
    update T
        set [STATE] = 'C',
            END_DATE = dbo.fnGetDateLocal()
      from dbo.SYS_TRAN T
      where SYS_TRAN_ID = @SYS_TRAN_ID
      
-- Очищаем таблицы с данными
    delete T
      from dbo.SYS_TMP_PATDIREC T
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
    delete T
      from dbo.SYS_TMP_DIR_SERV T
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
    delete T
      from dbo.SYS_TMP_BILLDET T
      where T.SYS_TRAN_ID = @SYS_TRAN_ID
    
    while @@trancount > 0  
      commit transaction  
  end try
  begin catch
    if @@trancount > 0
      rollback transaction
            
    select 
        @ErrorNumber = ERROR_NUMBER(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE(),
        @ErrorLine = ERROR_LINE(),
        @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-')

    select @ErrorMessage = 
        N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' + 
            'Message: '+ ERROR_MESSAGE()

    update T
        set [STATE] = 'R',
            END_DATE = dbo.fnGetDateLocal(),
            COMMENT = @ErrorMessage
      from dbo.SYS_TRAN T
      where SYS_TRAN_ID = @SYS_TRAN_ID
      
    raiserror (
      @ErrorMessage, 
      @ErrorSeverity, 
      1,               
      @ErrorNumber,    -- parameter: original error number.
      @ErrorSeverity,  -- parameter: original error severity.
      @ErrorState,     -- parameter: original error state.
      @ErrorProcedure, -- parameter: original error procedure name.
      @ErrorLine       -- parameter: original error line number.
    )
  
  end catch

err_label:  
  return @ret
end
go

