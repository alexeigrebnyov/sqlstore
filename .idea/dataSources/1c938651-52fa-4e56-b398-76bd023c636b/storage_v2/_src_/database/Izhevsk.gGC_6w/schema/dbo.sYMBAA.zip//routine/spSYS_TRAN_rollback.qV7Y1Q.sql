
CREATE procedure dbo.spSYS_TRAN_rollback
  @SYS_TRAN_ID int = null,
  @COMMENT     varchar(4000) = null,
  @ERR_MESS    varchar(255) = null output 
as
begin
  set nocount on 
  
  declare
    @ret int
  select
    @ERR_MESS = null,
    @ret = 0
    
  select 
    @ERR_MESS = case
                  when nullif(@SYS_TRAN_ID, 0) is null then '@SYS_TRAN_ID is null'
                end  
  if @ERR_MESS is not null
  begin
    set @ret = -1 
    goto err_label
  end                   

  update T
      set [STATE] = 'R',
          END_DATE = dbo.fnGetDateLocal(),
          COMMENT = @COMMENT
    from dbo.SYS_TRAN T
    where SYS_TRAN_ID = @SYS_TRAN_ID
      and [STATE] = 'A'
    
err_label:    
  return @ret
end

go

