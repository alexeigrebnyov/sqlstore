

CREATE procedure [dbo].[sp_CancelExceedPatdir]
AS
BEGIN

	SET XACT_ABORT ON;

	declare @curr_date datetime, @err_mess varchar(max);
	set @curr_date = dbo.fnGetDateLocal();

	select PD.PATDIREC_ID into #pd_ids
	from PATDIREC PD with (nolock)
		join PL_EXAM EX with (nolock, index(PK_PL_EXAM)) on PD.PL_EXAM_ID = EX.PL_EXAM_ID and EX.ACTIVE_PERIOD > 0
		left join DIR_ANSW DA with (nolock, index(idxPATDIREC_ID)) on DA.PATDIREC_ID = PD.PATDIREC_ID
			and (DA.ANSW_STATE = 1 or DA.MOTCONSU_RESP_ID is not null) -- оказано (инверсия в условии where)
	where PD.DIR_STATE in (0, 1) 
		and ((PD.BEGIN_DATE_TIME < DateAdd(day, -(EX.ACTIVE_PERIOD + 1), @curr_date)) or (PD.END_DATE_TIME is not null and PD.END_DATE_TIME < @curr_date)OR (PD.PLANNING_CR_ID is null and PD.CREATE_DATE_TIME < DateAdd(day, -7, GetDate()  )) --добавил Рифнур 
		)
		and (PD.BIO_CODE is null or PD.BIO_CODE = '')
		and DA.DIR_ANSW_ID is null
		and not(PD.is_task = 1 and PD.IS_REQUEST = 0)--исключаем задания
	group by PD.PATDIREC_ID
	option (force order, loop join, maxdop 1)

	create unique index idxPATDIREC_ID on #pd_ids(PATDIREC_ID)
	
	delete PD
	from #pd_ids PD
		join DIR_SERV ds with(nolock) on ds.PATDIREC_ID = PD.PATDIREC_ID and ds.DIR_SERV_TASK_ID is not NULL
		-- исключаем требования, ссылающиеся на задания

	delete PD
	from #pd_ids PD
		join DIR_ANSW DA with (nolock, index(idxPATDIREC_ID)) on DA.PATDIREC_ID = PD.PATDIREC_ID and DA.ANSW_STATE = 0
		inner join FM_BILLDET BD with (nolock, index(idxBILL)) on BD.FM_BILL_ID = DA.FM_BILL_ID
		inner join FM_BILLDET_PAY BDP with (nolock, index(idxFM_BILLDET_DONE_ID)) on BDP.FM_BILLDET_DONE_ID = BD.FM_BILLDET_ID
			and (BDP.FM_INVOICE_ID is not null or BDP.DEVERS_ID is not null) -- в счете или выгружалось
			or BD.RENDERED=1 or BD.DISCOUNT='-100.00'   --талон оплачен добавил Рифнур 

	delete PD
	from #pd_ids PD
		join DIR_ANSW DA with (nolock, index(idxPATDIREC_ID)) on DA.PATDIREC_ID = PD.PATDIREC_ID and DA.ANSW_STATE = 0 
		inner join FM_BILLDET BD with (nolock, index(idxBILL)) on BD.FM_BILL_ID = DA.FM_BILL_ID and BD.DONE = 1 -- оказано

	delete PD
	from #pd_ids PD
		join DIR_ANSW DA with (nolock, index(idxPATDIREC_ID)) on DA.PATDIREC_ID = PD.PATDIREC_ID and DA.ANSW_STATE = 0
		inner join FM_BILL B with (nolock, index(PK_FM_BILL)) on B.FM_BILL_ID = DA.FM_BILL_ID
			and B.MOTCONSU_ID is not null -- отвечено
	
	delete PD
	from #pd_ids PD
		join DIR_ANSW DA with (nolock, index(idxPATDIREC_ID)) on DA.PATDIREC_ID = PD.PATDIREC_ID
		join PLANNING pl with(nolock) on DA.PLANNING_ID = pl.PLANNING_ID and (pl.CANCELLED = 0 or pl.CANCELLED is null)
			and (pl.STATUS = 0 or pl.STATUS is null)

	select DA.PATDIREC_ID, DA.DIR_ANSW_ID, DA.FM_BILL_ID into #da_ids
	from #pd_ids PD
		join DIR_ANSW DA with (nolock, index(idxPATDIREC_ID)) on DA.PATDIREC_ID = PD.PATDIREC_ID
	create unique index idxDIR_ANSW_ID on #da_ids (DIR_ANSW_ID)
	create nonclustered index idxPATDIREC_ID on #da_ids (PATDIREC_ID)
	create nonclustered index idxFM_BILL_ID on #da_ids (FM_BILL_ID)

	begin tran
	begin try
		update DA set
			DA.ANSW_STATE = 2 
		from #da_ids T
		inner join DIR_ANSW DA with (index(PK_DIR_ANSW)) on DA.DIR_ANSW_ID = T.DIR_ANSW_ID

		update PD set
			PD.DIR_STATE = 3,
			PD.CANCELLED = 1
		from #da_ids T
			inner join PATDIREC PD with (index(PK_PATDIREC)) on PD.PATDIREC_ID = T.PATDIREC_ID  

		update BDP set
			BDP.CANCEL = 1
		from #da_ids T
			inner join FM_BILLDET BD with (nolock, index(idxBILL)) on BD.FM_BILL_ID = T.FM_BILL_ID
			inner join FM_BILLDET_PAY BDP with (index(idxFM_BILLDET_DONE_ID)) on BDP.FM_BILLDET_DONE_ID = BD.FM_BILLDET_ID
				and (BDP.CANCEL is null or BDP.CANCEL = 0)

		update BD set
			BD.CANCEL = 1,
			BD.AUTO_CANCELLED = case when BD.CANCEL = 1 then BD.AUTO_CANCELLED else 1 end
		from #da_ids T
			inner join FM_BILLDET BD with (index(idxBILL)) on BD.FM_BILL_ID = T.FM_BILL_ID and (BD.CANCEL is null or BD.CANCEL = 0)
	end try
	begin catch
		set @err_mess = ERROR_MESSAGE();
		while @@trancount > 0
			rollback tran;
	end catch
	while @@trancount > 0
		commit tran;

	drop table #pd_ids
	drop table #da_ids

	if @err_mess is not null
		raiserror (@err_mess, 16, 1);
END

go

