CREATE trigger tD_CHAOS_BRACKMAN_SCALE on CHAOS_BRACKMAN_SCALE for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if exists(
  select 1 from deleted D
    inner join DATA_NEURO_SCALES Z with (nolock)
      on Z.HOUSE_BRACKMANN_STEPEN_ = D.Hause_Brackmann_id)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_NEURO_SCALES', @ERRPARENT = 'CHAOS_BRACKMAN_SCALE'
  goto error
end

Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'CHAOS_BRACKMAN_SCALE', Hause_Brackmann_id, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

