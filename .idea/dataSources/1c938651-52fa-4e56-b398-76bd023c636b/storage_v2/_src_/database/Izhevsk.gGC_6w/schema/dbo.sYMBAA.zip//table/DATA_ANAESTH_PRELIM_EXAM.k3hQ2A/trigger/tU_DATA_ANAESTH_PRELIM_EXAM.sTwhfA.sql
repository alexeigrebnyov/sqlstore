CREATE trigger tU_DATA_ANAESTH_PRELIM_EXAM on DATA_ANAESTH_PRELIM_EXAM for UPDATE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if TRIGGER_NESTLEVEL(OBJECT_ID('tU_DATA_ANAESTH_PRELIM_EXAM')) > 1
  return

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = coalesce(d.KRN_CREATE_DATE, i.KRN_CREATE_DATE),
  KRN_CREATE_USER_ID = coalesce(d.KRN_CREATE_USER_ID, i.KRN_CREATE_USER_ID),
  KRN_CREATE_DATABASE_ID = coalesce(d.KRN_CREATE_DATABASE_ID, i.KRN_CREATE_DATABASE_ID),
  KRN_GUID = coalesce(d.KRN_GUID, i.KRN_GUID),
  KRN_MODIFY_DATE = @DBKERNEL_SERVER_DATE,
  KRN_MODIFY_USER_ID = @DBKERNEL_USER_ID,
  KRN_MODIFY_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from DATA_ANAESTH_PRELIM_EXAM t, inserted i, deleted d
where t.DATA384_ID = i.DATA384_ID
  and i.DATA384_ID = d.DATA384_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRMSG)
  rollback transaction
end
go

