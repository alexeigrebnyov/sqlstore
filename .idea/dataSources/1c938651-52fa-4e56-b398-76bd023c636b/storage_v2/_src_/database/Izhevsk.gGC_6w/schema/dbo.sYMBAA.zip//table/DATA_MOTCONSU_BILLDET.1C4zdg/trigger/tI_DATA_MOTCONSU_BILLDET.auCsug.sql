CREATE trigger tI_DATA_MOTCONSU_BILLDET on DATA_MOTCONSU_BILLDET for INSERT as
begin
declare  @NUMROWS int,
         @NULLCNT int,
         @VALIDCNT int,
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
select @NULLCNT = 0
select @VALIDCNT = count(*) from inserted I
  left join ED_RECEPTION_PLACE Z with (nolock)
    on Z.ED_RECEPTION_PLACE_ID = I.ED_RECEPTION_PLACE_ID
  where (I.ED_RECEPTION_PLACE_ID is null) or Z.ED_RECEPTION_PLACE_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'ED_RECEPTION_PLACE'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join ED_RECEPTION_TYPES Z with (nolock)
    on Z.ED_RECEPTION_TYPE_ID = I.ED_RECEPTION_TYPE_ID
  where (I.ED_RECEPTION_TYPE_ID is null) or Z.ED_RECEPTION_TYPE_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'ED_RECEPTION_TYPES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_BILL Z with (nolock)
    on Z.FM_BILL_ID = I.FM_BILL_ID
  where (I.FM_BILL_ID is null) or Z.FM_BILL_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'FM_BILL'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_BILLDET Z with (nolock)
    on Z.FM_BILLDET_ID = I.FM_BILLDET_ID
  where (I.FM_BILLDET_ID is null) or Z.FM_BILLDET_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'FM_BILLDET'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_CLINK Z with (nolock)
    on Z.FM_CLINK_ID = I.FM_CLINK_ID
  where (I.FM_CLINK_ID is null) or Z.FM_CLINK_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'FM_CLINK'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_CLINK_PATIENTS Z with (nolock)
    on Z.FM_CLINK_PATIENTS_ID = I.FM_CLINK_PATIENTS_ID
  where (I.FM_CLINK_PATIENTS_ID is null) or Z.FM_CLINK_PATIENTS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'FM_CLINK_PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_DEP Z with (nolock)
    on Z.FM_DEP_ID = I.DATA_MOTCONSU_BILLDET_DEP
  where (I.DATA_MOTCONSU_BILLDET_DEP is null) or Z.FM_DEP_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'FM_DEP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_SERV Z with (nolock)
    on Z.FM_SERV_ID = I.FM_SERV_ID
  where (I.FM_SERV_ID is null) or Z.FM_SERV_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'FM_SERV'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDDEP Z with (nolock)
    on Z.MEDDEP_ID = I.MEDDEP_SERV_ID
  where (I.MEDDEP_SERV_ID is null) or Z.MEDDEP_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'MEDDEP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDDEP Z with (nolock)
    on Z.MEDDEP_ID = I.VRACH_OTDELENIE
  where (I.VRACH_OTDELENIE is null) or Z.MEDDEP_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'MEDDEP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.DATA_MOTCONSU_BILLDET_DOCTOR
  where (I.DATA_MOTCONSU_BILLDET_DOCTOR is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.DATA_MOTCONSU_BILLDET_NURSE
  where (I.DATA_MOTCONSU_BILLDET_NURSE is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join MOTCONSU Z with (nolock)
    on Z.MOTCONSU_ID = I.MOTCONSU_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'MOTCONSU'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.PATIENTS_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join PAYMENT_TYPES Z with (nolock)
    on Z.KINDS_PAYMENT_ID = I.VID_OPLATY
  where (I.VID_OPLATY is null) or Z.KINDS_PAYMENT_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_CREATE_DATABASE_ID
  where (I.KRN_CREATE_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_MODIFY_DATABASE_ID
  where (I.KRN_MODIFY_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'RM_DATABASES'
  goto error
end

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

update t set KRN_GUID = convert(varchar(36), dbo.pmt_guid())
from DATA_MOTCONSU_BILLDET t, inserted i
where t.DATA_MOTCONSU_BILLDET_ID = i.DATA_MOTCONSU_BILLDET_ID
  and IsNull(i.KRN_GUID, '') = ''

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = @DBKERNEL_SERVER_DATE,
  KRN_CREATE_USER_ID = @DBKERNEL_USER_ID,
  KRN_CREATE_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from DATA_MOTCONSU_BILLDET t, inserted i
where t.DATA_MOTCONSU_BILLDET_ID = i.DATA_MOTCONSU_BILLDET_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

