CREATE trigger tD_DATA_PERFUSION_CONSUMPT on DATA_PERFUSION_CONSUMPT for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'DATA_PERFUSION_CONSUMPT', DATA417_ID, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

