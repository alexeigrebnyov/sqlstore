CREATE trigger tI_DATA_PERSONAL_INOCUL_CALEND on DATA_PERSONAL_INOCUL_CALEND for INSERT as
begin
declare  @NUMROWS int,
         @NULLCNT int,
         @VALIDCNT int,
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
select @NULLCNT = 0
select @VALIDCNT = count(*) from inserted I
  left join DATA_PERSONAL_INOCUL_CALEND Z with (nolock)
    on Z.DATA_PERSONAL_INOCUL_CALEND_ID = I.SSYLKA_NA_ETAP
  where (I.SSYLKA_NA_ETAP is null) or Z.DATA_PERSONAL_INOCUL_CALEND_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'DATA_PERSONAL_INOCUL_CALEND'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join DM_MEDS Z with (nolock)
    on Z.DM_MEDS_ID = I.PREPARAT
  where (I.PREPARAT is null) or Z.DM_MEDS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'DM_MEDS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join inoCULATION_CALENDAR Z with (nolock)
    on Z.INOCULATION_CALENDAR_ID = I.INOCULATION_CALENDAR_ID
  where (I.INOCULATION_CALENDAR_ID is null) or Z.INOCULATION_CALENDAR_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'inoCULATION_CALENDAR'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join INOCULATION_SCHEMES Z with (nolock)
    on Z.INOCULATION_SCHEMES_ID = I.INOCULATION_SCHEMES_ID
  where (I.INOCULATION_SCHEMES_ID is null) or Z.INOCULATION_SCHEMES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'INOCULATION_SCHEMES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join INOCULATION_TYPES Z with (nolock)
    on Z.INOCULATION_TYPES_ID = I.INOCULATION_TYPES_ID
  where (I.INOCULATION_TYPES_ID is null) or Z.INOCULATION_TYPES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'INOCULATION_TYPES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECIN_CONFIRM
  where (I.MEDECIN_CONFIRM is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_CREATE_ID
  where (I.MEDECINS_CREATE_ID is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join medeCINS Z with (nolock)
    on Z.MEDECINS_ID = I.PRIVIVAL
  where (I.PRIVIVAL is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'medeCINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MOTCONSU Z with (nolock)
    on Z.MOTCONSU_ID = I.SURVEY_MOTCONSU_ID
  where (I.SURVEY_MOTCONSU_ID is null) or Z.MOTCONSU_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'MOTCONSU'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.PATIENTS_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_CREATE_DATABASE_ID
  where (I.KRN_CREATE_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_MODIFY_DATABASE_ID
  where (I.KRN_MODIFY_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PERSONAL_INOCUL_CALEND', @ERRPARENT = 'RM_DATABASES'
  goto error
end

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

update t set KRN_GUID = convert(varchar(36), dbo.pmt_guid())
from DATA_PERSONAL_INOCUL_CALEND t, inserted i
where t.DATA_PERSONAL_INOCUL_CALEND_ID = i.DATA_PERSONAL_INOCUL_CALEND_ID
  and IsNull(i.KRN_GUID, '') = ''

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = @DBKERNEL_SERVER_DATE,
  KRN_CREATE_USER_ID = @DBKERNEL_USER_ID,
  KRN_CREATE_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from DATA_PERSONAL_INOCUL_CALEND t, inserted i
where t.DATA_PERSONAL_INOCUL_CALEND_ID = i.DATA_PERSONAL_INOCUL_CALEND_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

