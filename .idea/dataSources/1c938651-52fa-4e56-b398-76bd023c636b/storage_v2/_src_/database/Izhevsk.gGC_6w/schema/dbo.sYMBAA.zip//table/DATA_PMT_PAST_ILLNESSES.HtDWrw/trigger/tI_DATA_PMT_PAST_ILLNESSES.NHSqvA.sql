CREATE trigger tI_DATA_PMT_PAST_ILLNESSES on DATA_PMT_PAST_ILLNESSES for INSERT as
begin
declare  @NUMROWS int,
         @NULLCNT int,
         @VALIDCNT int,
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
select @NULLCNT = 0
select @VALIDCNT = count(*) from inserted I
  left join CIM10 Z with (nolock)
    on Z.CIM10_ID = I.DIAGNOZ
  where (I.DIAGNOZ is null) or Z.CIM10_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PMT_PAST_ILLNESSES', @ERRPARENT = 'CIM10'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join MOTCONSU Z with (nolock)
    on Z.MOTCONSU_ID = I.MOTCONSU_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PMT_PAST_ILLNESSES', @ERRPARENT = 'MOTCONSU'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.PATIENTS_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PMT_PAST_ILLNESSES', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_CREATE_DATABASE_ID
  where (I.KRN_CREATE_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PMT_PAST_ILLNESSES', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_MODIFY_DATABASE_ID
  where (I.KRN_MODIFY_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_PMT_PAST_ILLNESSES', @ERRPARENT = 'RM_DATABASES'
  goto error
end

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

update t set KRN_GUID = convert(varchar(36), dbo.pmt_guid())
from DATA_PMT_PAST_ILLNESSES t, inserted i
where t.DATA_PMT_PAST_ILLNESSES_ID = i.DATA_PMT_PAST_ILLNESSES_ID
  and IsNull(i.KRN_GUID, '') = ''

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = @DBKERNEL_SERVER_DATE,
  KRN_CREATE_USER_ID = @DBKERNEL_USER_ID,
  KRN_CREATE_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from DATA_PMT_PAST_ILLNESSES t, inserted i
where t.DATA_PMT_PAST_ILLNESSES_ID = i.DATA_PMT_PAST_ILLNESSES_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

