CREATE trigger tD_DATA_US_ABDOMINAL_ORGANS on DATA_US_ABDOMINAL_ORGANS for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if exists(
  select 1 from deleted D
    inner join DATA_INSTRUMENTAL_DIAGNOS Z with (nolock)
      on Z.DATA381_ID = D.DATA_INSTRUMENTAL_DIAG_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_INSTRUMENTAL_DIAGNOS', @ERRPARENT = 'DATA_US_ABDOMINAL_ORGANS'
  goto error
end

Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'DATA_US_ABDOMINAL_ORGANS', DATA_US_ABDOMINAL_ORGANS_ID, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

insert into KRN_SYS_TRACE(TABLE_NAME,REC_ID,ACTION, KRN_GUID, EXTERNAL_USER_ID)
select 'DATA_US_ABDOMINAL_ORGANS', DATA_US_ABDOMINAL_ORGANS_ID, 'D', KRN_GUID, 
  (select top 1 USER_ID from KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

