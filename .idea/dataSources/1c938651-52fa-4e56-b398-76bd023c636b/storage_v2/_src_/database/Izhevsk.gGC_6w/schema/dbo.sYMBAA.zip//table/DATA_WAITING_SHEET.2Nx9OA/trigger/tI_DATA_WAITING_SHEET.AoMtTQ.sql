CREATE trigger tI_DATA_WAITING_SHEET on DATA_WAITING_SHEET for INSERT as
begin
declare  @NUMROWS int,
         @NULLCNT int,
         @VALIDCNT int,
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
select @NULLCNT = 0
select @VALIDCNT = count(*) from inserted I
  left join CIM10 Z with (nolock)
    on Z.CIM10_ID = I.DIAGNOZ
  where (I.DIAGNOZ is null) or Z.CIM10_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'CIM10'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join CIM10 Z with (nolock)
    on Z.CIM10_ID = I.DIAGNOZ_PRI_POSTUPLENII_P
  where (I.DIAGNOZ_PRI_POSTUPLENII_P is null) or Z.CIM10_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'CIM10'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join CIM10 Z with (nolock)
    on Z.CIM10_ID = I.DIAGNOZ_PRI_V_PISKE_MKB_1
  where (I.DIAGNOZ_PRI_V_PISKE_MKB_1 is null) or Z.CIM10_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'CIM10'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join DATA_WAITING_SHEET Z with (nolock)
    on Z.DATA334_ID = I.PLANIRUEMAYA_DO_PERENOSA_
  where (I.PLANIRUEMAYA_DO_PERENOSA_ is null) or Z.DATA334_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'DATA_WAITING_SHEET'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_DEP Z with (nolock)
    on Z.FM_DEP_ID = I.OTDELENIE
  where (I.OTDELENIE is null) or Z.FM_DEP_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'FM_DEP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_ORG Z with (nolock)
    on Z.FM_ORG_ID = I.NAPRAVIVSHEE_UCHREZHDENIE
  where (I.NAPRAVIVSHEE_UCHREZHDENIE is null) or Z.FM_ORG_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'FM_ORG'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_SERV Z with (nolock)
    on Z.FM_SERV_ID = I.KOD_OKAZANNOJ_MEDICINSKOJ
  where (I.KOD_OKAZANNOJ_MEDICINSKOJ is null) or Z.FM_SERV_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'FM_SERV'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join HO_BED_TYPE Z with (nolock)
    on Z.HO_BED_TYPE_ID = I.PROFIL_LECHENIYA
  where (I.PROFIL_LECHENIYA is null) or Z.HO_BED_TYPE_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'HO_BED_TYPE'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join HO_RESERV Z with (nolock)
    on Z.HO_RESERV_ID = I.BRON_DLQ_GOSPITALIZACII
  where (I.BRON_DLQ_GOSPITALIZACII is null) or Z.HO_RESERV_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'HO_RESERV'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.PRINYAL_RESHENIE_O_PERENO
  where (I.PRINYAL_RESHENIE_O_PERENO is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join MOTCONSU Z with (nolock)
    on Z.MOTCONSU_ID = I.MOTCONSU_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'MOTCONSU'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.PATIENTS_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join PAYMENT_TYPES Z with (nolock)
    on Z.KINDS_PAYMENT_ID = I.VIDY_OPLATY_SSYLKA
  where (I.VIDY_OPLATY_SSYLKA is null) or Z.KINDS_PAYMENT_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_CREATE_DATABASE_ID
  where (I.KRN_CREATE_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_MODIFY_DATABASE_ID
  where (I.KRN_MODIFY_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join VMP_TYPES Z with (nolock)
    on Z.VMP_KIND_ID = I.VID_VMP
  where (I.VID_VMP is null) or Z.VMP_KIND_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'VMP_TYPES'
  goto error
end

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

update t set KRN_GUID = convert(varchar(36), dbo.pmt_guid())
from DATA_WAITING_SHEET t, inserted i
where t.DATA334_ID = i.DATA334_ID
  and IsNull(i.KRN_GUID, '') = ''

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = @DBKERNEL_SERVER_DATE,
  KRN_CREATE_USER_ID = @DBKERNEL_USER_ID,
  KRN_CREATE_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from DATA_WAITING_SHEET t, inserted i
where t.DATA334_ID = i.DATA334_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

