CREATE trigger tD_DM_MEASURE on DM_MEASURE for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if exists(
  select 1 from deleted D
    inner join DM_MEDS Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_MEDS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_MEDS Z with (nolock)
      on Z.FACTORING_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_MEDS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_MEDS Z with (nolock)
      on Z.MIN_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_MEDS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_MEDS_MEASURES Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_MEDS_MEASURES', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_MIXTURES Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_MIXTURES', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_TRANSFERS Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_TRANSFERS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_TRANSFERS_DETAIL Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_TRANSFERS_DETAIL', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PATDIREC_DRUGS Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PATDIREC_DRUGS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PATDIREC_DRUGS Z with (nolock)
      on Z.INTAKE_DURATION_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PATDIREC_DRUGS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PATDIREC_DRUGS Z with (nolock)
      on Z.INTAKE_SPEED_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PATDIREC_DRUGS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PATDIREC_DRUGS_DET Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PATDIREC_DRUGS_DET', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PR_DRUG_MNNS Z with (nolock)
      on Z.MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PR_DRUG_MNNS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PR_DRUGS Z with (nolock)
      on Z.ACTIVE_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PR_DRUGS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PR_DRUGS Z with (nolock)
      on Z.PACKING_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PR_DRUGS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PR_DRUGS_DET Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PR_DRUGS_DET', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PR_DRUGS_MEDS Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PR_DRUGS_MEDS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PR_TEMPLATES Z with (nolock)
      on Z.INTAKE_DURATION_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PR_TEMPLATES', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PR_TEMPLATES Z with (nolock)
      on Z.INTAKE_SPEED_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PR_TEMPLATES', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join CP_STANDART_MNN Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'CP_STANDART_MNN', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_PATIENT_DYNAM_INDEX Z with (nolock)
      on Z.EDINICA_IZMERENIQ = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_PATIENT_DYNAM_INDEX', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_CONTR_DET Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_CONTR_DET', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_COSTS Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_COSTS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_DEM_GOODS Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_DEM_GOODS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_LOTS Z with (nolock)
      on Z.INCOME_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_LOTS', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_LOTS_DETAIL Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_LOTS_DETAIL', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_MEASURE_ACTIVE Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_MEASURE_ACTIVE', @ERRPARENT = 'DM_MEASURE'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DM_MEASURE_PACKING Z with (nolock)
      on Z.DM_MEASURE_ID = D.DM_MEASURE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DM_MEASURE_PACKING', @ERRPARENT = 'DM_MEASURE'
  goto error
end

delete DM_MEASURES_INTERACTION
from deleted, DM_MEASURES_INTERACTION
where deleted.DM_MEASURE_ID = DM_MEASURES_INTERACTION.SOURCE_MEASURE_ID

delete DM_MEASURES_INTERACTION
from deleted, DM_MEASURES_INTERACTION
where deleted.DM_MEASURE_ID = DM_MEASURES_INTERACTION.TARGET_MEASURE_ID

delete DM_MEASURE_EXTCODES
from deleted, DM_MEASURE_EXTCODES
where deleted.DM_MEASURE_ID = DM_MEASURE_EXTCODES.DM_MEASURE_ID

update TMP_WAREHOUSE_REPORT
set TMP_WAREHOUSE_REPORT.DFLT_MEASURE_ID = NULL
from deleted, TMP_WAREHOUSE_REPORT
where deleted.DM_MEASURE_ID = TMP_WAREHOUSE_REPORT.DFLT_MEASURE_ID
  and TMP_WAREHOUSE_REPORT.DFLT_MEASURE_ID is not null 

update TMP_WAREHOUSE_REPORT
set TMP_WAREHOUSE_REPORT.DM_MEASURE_ID = NULL
from deleted, TMP_WAREHOUSE_REPORT
where deleted.DM_MEASURE_ID = TMP_WAREHOUSE_REPORT.DM_MEASURE_ID
  and TMP_WAREHOUSE_REPORT.DM_MEASURE_ID is not null 

Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'DM_MEASURE', DM_MEASURE_ID, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

insert into KRN_SYS_TRACE(TABLE_NAME,REC_ID,ACTION, KRN_GUID, EXTERNAL_USER_ID)
select 'DM_MEASURE', DM_MEASURE_ID, 'D', KRN_GUID, 
  (select top 1 USER_ID from KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

