CREATE trigger tI_DM_WAREHOUSES on DM_WAREHOUSES for INSERT as
begin
declare  @NUMROWS int,
         @NULLCNT int,
         @VALIDCNT int,
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
select @NULLCNT = 0
--------- Begin of user section -----------

-- 75608

    exec dm_wh_tree_update;

    -- обновление HLEVEL у добавленных записей
    update DM_WAREHOUSES 
        set HLEVEL = (select max(t.RLENGTH) 
                        from DM_WH_TREE t 
                       where t.CHILD_ID = DM_WAREHOUSES.DM_WAREHOUSES_ID)
        from DM_WAREHOUSES 
        join inserted on DM_WAREHOUSES.DM_WAREHOUSES_ID = inserted.DM_WAREHOUSES_ID

---------- End of user section ------------
select @VALIDCNT = count(*) from inserted I
  left join DM_WAREHOUSES Z with (nolock)
    on Z.DM_WAREHOUSES_ID = I.WH_PARENT_ID
  where (I.WH_PARENT_ID is null) or Z.DM_WAREHOUSES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'DM_WAREHOUSES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_ACCOUNT Z with (nolock)
    on Z.FM_ACCOUNT_ID = I.FM_ACCOUNT_ID
  where (I.FM_ACCOUNT_ID is null) or Z.FM_ACCOUNT_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'FM_ACCOUNT'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  inner join FM_DEP Z with (nolock)
    on Z.FM_DEP_ID = I.FM_DEP_ID
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'FM_DEP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_ORG_ADR Z with (nolock)
    on Z.FM_ORG_ADR_ID = I.FM_ORG_ADR_ID
  where (I.FM_ORG_ADR_ID is null) or Z.FM_ORG_ADR_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'FM_ORG_ADR'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_SOURCE_FIN Z with (nolock)
    on Z.FM_SOURCE_FIN_ID = I.FM_SOURCE_FIN_ID
  where (I.FM_SOURCE_FIN_ID is null) or Z.FM_SOURCE_FIN_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'FM_SOURCE_FIN'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_TAXE Z with (nolock)
    on Z.FM_TAXE_ID = I.FM_TAXE_ID
  where (I.FM_TAXE_ID is null) or Z.FM_TAXE_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'FM_TAXE'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MAT_RESPONSE
  where (I.MAT_RESPONSE is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.PATIENTS_ID
  where (I.PATIENTS_ID is null) or Z.PATIENTS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_CREATE_DATABASE_ID
  where (I.KRN_CREATE_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_MODIFY_DATABASE_ID
  where (I.KRN_MODIFY_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'DM_WAREHOUSES', @ERRPARENT = 'RM_DATABASES'
  goto error
end

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

update t set KRN_GUID = convert(varchar(36), dbo.pmt_guid())
from DM_WAREHOUSES t, inserted i
where t.DM_WAREHOUSES_ID = i.DM_WAREHOUSES_ID
  and IsNull(i.KRN_GUID, '') = ''

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = @DBKERNEL_SERVER_DATE,
  KRN_CREATE_USER_ID = @DBKERNEL_USER_ID,
  KRN_CREATE_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from DM_WAREHOUSES t, inserted i
where t.DM_WAREHOUSES_ID = i.DM_WAREHOUSES_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

