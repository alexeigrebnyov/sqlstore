CREATE trigger [dbo].[tIU_DS_RESTESTS_SET_REFERENCE] on [dbo].[DS_RESTESTS] for INSERT, UPDATE as
begin
declare  @NUMROWS int,
         
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255),
		 @DS_RESTESTS_IDs xml,
		 @OutValues xml 



declare @CONCAT_NULL_YIELDS_NULL  int, @ANSI_WARNINGS  int, @ANSI_PADDING  int, @ANSI_NULLS  int, @QUOTED_IDENTIFIER int
	-- запомним настройки окружения
	select  @CONCAT_NULL_YIELDS_NULL =	cast(SESSIONPROPERTY ('CONCAT_NULL_YIELDS_NULL') as int) ,
			@ANSI_WARNINGS =	cast(SESSIONPROPERTY ('ANSI_WARNINGS') as int) ,
			@ANSI_PADDING =	cast(SESSIONPROPERTY ('ANSI_PADDING') as int) ,
			@ANSI_NULLS =	cast(SESSIONPROPERTY ('ANSI_NULLS') as int) ,
			@QUOTED_IDENTIFIER =	cast(SESSIONPROPERTY ('QUOTED_IDENTIFIER') as int) 
			
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_WARNINGS ON
SET ANSI_PADDING ON
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- отключим блокировки
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED 

set @NUMROWS = @@ROWCOUNT
--if @NUMROWS = 0 or 
 if dbo.TriggersEnabled() = 0
  return

-- если отключены серверные вычисления рефе.интервалов
if not exists (
	select PRM_NAME
		from FM_PARAMS
	where PRM_NAME = 'USE_REF_VALUES_SRV' and PRM_VALUE = 1
	  )
return

-- уберем рекурсию
if TRIGGER_NESTLEVEL() > 1
return

set @DS_RESTESTS_IDs =
						(	-- отберем только пустые
							select 
								DS_RESTESTS_ID
								from inserted Item
								where   isnull([NORM_MIN_REC],0) +  
										isnull([NORM_MAX_REC],0) + 
										isnull([NORM_MIN_LIM],0) + 
										isnull([NORM_MAX_LIM],0) = 0 
								for xml auto, root ('Root')
						)
--print cast(@DS_RESTESTS_IDs as varchar(max))

if @@error <> 0
begin
  select @ERRNO = 51001, @ERRCHILD = 'DS_RESTESTS', @ERRPARENT = 'tIU_DS_RESTESTS_SET_REFERENCE'
  goto error
end

 exec spLab_QueryReferenceIntervalFromResTest @DS_RESTESTS_IDs, @OutValues output, 0

if @@error <> 0
begin
  select @ERRNO = 51001, @ERRCHILD = 'DS_RESTESTS', @ERRPARENT = 'tIU_DS_RESTESTS_SET_REFERENCE_EXEC'
  goto error
end

/*
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_WARNINGS ON
SET ANSI_PADDING ON
*/
-- select * from [dbo].[DS_RESTESTS] order by res_date desc

	update [dbo].[DS_RESTESTS]
	set	NORM_MIN_REC = t.c.value('@NORM_MIN_REC','numeric (24,10)') ,
		NORM_MAX_REC = t.c.value('@NORM_MAX_REC','numeric (24,10)') ,
		NORM_MIN_LIM = t.c.value('@NORM_MIN_LIM','numeric (24,10)') ,
		NORM_MAX_LIM = t.c.value('@NORM_MAX_LIM','numeric (24,10)') ,
		NORM_STATE   = t.c.value('@NORM_STAT', 'int'),
		STATE   = t.c.value('@STATE', 'int'),
		NORM_TEXT_REC = t.c.value('@NORM_TEXT_REC', 'varchar(1000)')
	from @OutValues.nodes ('Root/Item') t(c)
	where DS_RESTESTS_ID = t.c.value('@DS_RESTESTS_ID', 'int') 

	-- вернем настройки окружения
	if  @CONCAT_NULL_YIELDS_NULL =	1
	SET CONCAT_NULL_YIELDS_NULL ON 
	else
	SET CONCAT_NULL_YIELDS_NULL OFF

	if @ANSI_WARNINGS =	1
	SET ANSI_WARNINGS ON
	else
	SET ANSI_WARNINGS OFF

	if @ANSI_PADDING =	1
	SET ANSI_PADDING ON
	else
	SET ANSI_PADDING OFF

	if @ANSI_NULLS =	1
	SET ANSI_NULLS ON
	else
	SET ANSI_NULLS OFF

	if	@QUOTED_IDENTIFIER = 1
	SET QUOTED_IDENTIFIER ON
	else
	SET QUOTED_IDENTIFIER OFF

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

