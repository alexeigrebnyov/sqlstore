CREATE trigger tD_FM_COURS_TYPE on FM_COURS_TYPE for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if exists(
  select 1 from deleted D
    inner join FM_CONTR Z with (nolock)
      on Z.FM_COURS_TYPE_ID = D.FM_COURS_TYPE_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'FM_CONTR', @ERRPARENT = 'FM_COURS_TYPE'
  goto error
end

delete FM_DEVISE_COURS
from deleted, FM_DEVISE_COURS
where deleted.FM_COURS_TYPE_ID = FM_DEVISE_COURS.FM_COURS_TYPE_ID

Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'FM_COURS_TYPE', FM_COURS_TYPE_ID, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

insert into KRN_SYS_TRACE(TABLE_NAME,REC_ID,ACTION, KRN_GUID, EXTERNAL_USER_ID)
select 'FM_COURS_TYPE', FM_COURS_TYPE_ID, 'D', KRN_GUID, 
  (select top 1 USER_ID from KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

