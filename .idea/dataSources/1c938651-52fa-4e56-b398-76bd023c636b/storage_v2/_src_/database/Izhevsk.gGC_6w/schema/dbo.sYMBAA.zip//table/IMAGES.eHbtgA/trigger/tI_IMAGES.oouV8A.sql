CREATE trigger tI_IMAGES on IMAGES for INSERT as
begin
declare  @NUMROWS int,
         @NULLCNT int,
         @VALIDCNT int,
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
select @NULLCNT = 0
select @VALIDCNT = count(*) from inserted I
  left join FM_INSCOND Z with (nolock)
    on Z.FM_INSCOND_ID = I.FM_INSCOND_ID
  where (I.FM_INSCOND_ID is null) or Z.FM_INSCOND_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'FM_INSCOND'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join IMAGES Z with (nolock)
    on Z.Images_ID = I.IMAGES_SRC_ID
  where (I.IMAGES_SRC_ID is null) or Z.Images_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'IMAGES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_CREATE_ID
  where (I.MEDECINS_CREATE_ID is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MOTCONSU Z with (nolock)
    on Z.MOTCONSU_ID = I.MOTCONSU_ID
  where (I.MOTCONSU_ID is null) or Z.MOTCONSU_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'MOTCONSU'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.PATIENTS_ID
  where (I.PATIENTS_ID is null) or Z.PATIENTS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_CREATE_DATABASE_ID
  where (I.KRN_CREATE_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_MODIFY_DATABASE_ID
  where (I.KRN_MODIFY_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RUBRICS Z with (nolock)
    on Z.Rubrics_ID = I.Rubrics_ID
  where (I.Rubrics_ID is null) or Z.Rubrics_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'RUBRICS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join SIGN_CERT_INFO Z with (nolock)
    on Z.SIGN_CERT_INFO_ID = I.SIGN_CERT_INFO_ID
  where (I.SIGN_CERT_INFO_ID is null) or Z.SIGN_CERT_INFO_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'SIGN_CERT_INFO'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join VIRTUAL_DISKS Z with (nolock)
    on Z.VIRTUAL_DISKS_ID = I.VIRTUAL_DISKS_ID
  where (I.VIRTUAL_DISKS_ID is null) or Z.VIRTUAL_DISKS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'IMAGES', @ERRPARENT = 'VIRTUAL_DISKS'
  goto error
end

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

update t set KRN_GUID = convert(varchar(36), dbo.pmt_guid())
from IMAGES t, inserted i
where t.Images_ID = i.Images_ID
  and IsNull(i.KRN_GUID, '') = ''

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = @DBKERNEL_SERVER_DATE,
  KRN_CREATE_USER_ID = @DBKERNEL_USER_ID,
  KRN_CREATE_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from IMAGES t, inserted i
where t.Images_ID = i.Images_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

