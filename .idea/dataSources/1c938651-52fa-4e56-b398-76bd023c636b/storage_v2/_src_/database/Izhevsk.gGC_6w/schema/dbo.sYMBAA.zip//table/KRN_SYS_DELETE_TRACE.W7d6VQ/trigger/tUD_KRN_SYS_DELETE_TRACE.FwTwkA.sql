

CREATE trigger tUD_KRN_SYS_DELETE_TRACE on KRN_SYS_DELETE_TRACE for UPDATE,DELETE as
begin
  raiserror ('Table KRN_SYS_DELETE_TRACE is read only.', 16, 1)
  rollback transaction
end

go

