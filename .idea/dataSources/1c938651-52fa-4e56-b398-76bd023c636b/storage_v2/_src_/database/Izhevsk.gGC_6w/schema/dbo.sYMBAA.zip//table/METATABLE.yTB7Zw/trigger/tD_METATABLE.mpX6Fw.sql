

CREATE trigger tD_METATABLE on METATABLE for DELETE as
begin
    delete ROLEPERM
    from ROLEPERM,deleted
    where  ROLEPERM.TABLE_NAME = deleted.TABLE_NAME

    delete TABLELINK
    from TABLELINK,deleted
    where TABLELINK.PARENT = deleted.TABLE_NAME

    delete TABLELINK
    from TABLELINK,deleted
    where TABLELINK.CHILD = deleted.TABLE_NAME

    delete METAFIELD
    from METAFIELD,deleted
    where METAFIELD.TABLE_NAME = deleted.TABLE_NAME
end

go

