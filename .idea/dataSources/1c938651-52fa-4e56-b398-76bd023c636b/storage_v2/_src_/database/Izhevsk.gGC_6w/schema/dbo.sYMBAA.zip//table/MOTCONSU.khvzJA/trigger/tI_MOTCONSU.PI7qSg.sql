CREATE trigger tI_MOTCONSU on MOTCONSU for INSERT as
begin
declare  @NUMROWS int,
         @NULLCNT int,
         @VALIDCNT int,
         @ERRNO   int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255),
         @IROWCNT int
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
select @NULLCNT = 0
--------- Begin of user section -----------

if update(EV_NAME)
begin
          /* Если становится событием, то прописываем ему MOTCONSU_EV_ID */
          update MOTCONSU set MOTCONSU_EV_ID = inserted.MOTCONSU_ID
          from inserted inner join MOTCONSU on MOTCONSU.MOTCONSU_ID = inserted.MOTCONSU_ID
          where isnull(inserted.EV_NAME , '') <> ''
end

---------- End of user section ------------
select @VALIDCNT = count(*) from inserted I
  left join CP_PLAN Z with (nolock)
    on Z.CP_PLAN_ID = I.STANDART
  where (I.STANDART is null) or Z.CP_PLAN_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'CP_PLAN'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join DATA_NUMBER_KART_PATIENTS Z with (nolock)
    on Z.DATA_NUMBER_KART_PATIENTS_ID = I.NOMER_AMBULATORNOY_KARTY_
  where (I.NOMER_AMBULATORNOY_KARTY_ is null) or Z.DATA_NUMBER_KART_PATIENTS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'DATA_NUMBER_KART_PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join DATA_TRANSFERS Z with (nolock)
    on Z.DATA_TRANSFERS_ID = I.DATA_TRANSFERS_ID
  where (I.DATA_TRANSFERS_ID is null) or Z.DATA_TRANSFERS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'DATA_TRANSFERS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_BILL Z with (nolock)
    on Z.FM_BILL_ID = I.FM_BILL_ID
  where (I.FM_BILL_ID is null) or Z.FM_BILL_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'FM_BILL'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_DEP Z with (nolock)
    on Z.FM_DEP_ID = I.FM_DEP_ID
  where (I.FM_DEP_ID is null) or Z.FM_DEP_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'FM_DEP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join FM_ORG Z with (nolock)
    on Z.FM_ORG_ID = I.LPU
  where (I.LPU is null) or Z.FM_ORG_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'FM_ORG'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join HO_RESERV Z with (nolock)
    on Z.HO_RESERV_ID = I.HO_RESERV_ID
  where (I.HO_RESERV_ID is null) or Z.HO_RESERV_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'HO_RESERV'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDDEP Z with (nolock)
    on Z.MEDDEP_ID = I.MEDDEP_ID
  where (I.MEDDEP_ID is null) or Z.MEDDEP_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDDEP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.LEHAHIJ_VRAH
  where (I.LEHAHIJ_VRAH is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_APPROVED_ID
  where (I.MEDECINS_APPROVED_ID is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_CANCEL_ID
  where (I.MEDECINS_CANCEL_ID is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_CREATE_ID
  where (I.MEDECINS_CREATE_ID is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_ID
  where (I.MEDECINS_ID is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.MEDECINS_MODIFY_ID
  where (I.MEDECINS_MODIFY_ID is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.SOZDAL
  where (I.SOZDAL is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.VRACH_NAPRAVIVSHIY
  where (I.VRACH_NAPRAVIVSHIY is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MEDECINS Z with (nolock)
    on Z.MEDECINS_ID = I.VRT_EMBRIOLOG
  where (I.VRT_EMBRIOLOG is null) or Z.MEDECINS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MEDECINS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MODELS Z with (nolock)
    on Z.Models_ID = I.MODELS_ID
  where (I.MODELS_ID is null) or Z.Models_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MODELS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MODELSGROUP Z with (nolock)
    on Z.MODELSGROUP_ID = I.MEROPRIQTIE
  where (I.MEROPRIQTIE is null) or Z.MODELSGROUP_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MODELSGROUP'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MOTCONSU Z with (nolock)
    on Z.MOTCONSU_ID = I.MOTCONSU_EV_ID
  where (I.MOTCONSU_EV_ID is null) or Z.MOTCONSU_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MOTCONSU'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join MOTCONSU_EVENT_TYPES Z with (nolock)
    on Z.MOTCONSU_EVENT_TYPES_ID = I.MOTCONSU_EVENT_TYPES_ID
  where (I.MOTCONSU_EVENT_TYPES_ID is null) or Z.MOTCONSU_EVENT_TYPES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'MOTCONSU_EVENT_TYPES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.KONTRAGENT_ID
  where (I.KONTRAGENT_ID is null) or Z.PATIENTS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join PATIENTS Z with (nolock)
    on Z.PATIENTS_ID = I.PATIENTS_ID
  where (I.PATIENTS_ID is null) or Z.PATIENTS_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'PATIENTS'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join PLANNING Z with (nolock)
    on Z.PLANNING_ID = I.PLANNING_ID
  where (I.PLANNING_ID is null) or Z.PLANNING_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'PLANNING'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_CREATE_DATABASE_ID
  where (I.KRN_CREATE_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'RM_DATABASES'
  goto error
end

select @VALIDCNT = count(*) from inserted I
  left join RM_DATABASES Z with (nolock)
    on Z.RM_DATABASES_ID = I.KRN_MODIFY_DATABASE_ID
  where (I.KRN_MODIFY_DATABASE_ID is null) or Z.RM_DATABASES_ID is not null
if @VALIDCNT != @NUMROWS
begin
  select @ERRNO = 51001, @ERRCHILD = 'MOTCONSU', @ERRPARENT = 'RM_DATABASES'
  goto error
end

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

update t set KRN_GUID = convert(varchar(36), dbo.pmt_guid())
from MOTCONSU t, inserted i
where t.MOTCONSU_ID = i.MOTCONSU_ID
  and IsNull(i.KRN_GUID, '') = ''

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = @DBKERNEL_SERVER_DATE,
  KRN_CREATE_USER_ID = @DBKERNEL_USER_ID,
  KRN_CREATE_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from MOTCONSU t, inserted i
where t.MOTCONSU_ID = i.MOTCONSU_ID

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRCHILD, @ERRPARENT)
  rollback transaction
end
go

