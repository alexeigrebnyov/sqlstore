CREATE trigger tU_MOTCONSU on MOTCONSU for UPDATE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @UROWCNT int
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
--------- Begin of user section -----------

if update(EV_NAME)
begin
          /* Если запись перестала быть событием, то очищаем его у всех своих подчиненных записей */
          /* Это выполняется только для заголовка события */
          update MOTCONSU set MOTCONSU_EV_ID = NULL
          from inserted inner join deleted  on inserted.MOTCONSU_ID = deleted.MOTCONSU_ID
                        inner join MOTCONSU on MOTCONSU.MOTCONSU_EV_ID = inserted.MOTCONSU_ID
          where isnull(deleted.EV_NAME, '') <> '' and isnull(inserted.EV_NAME, '') = '' 

          /* Если запись становится событием, то прописываем себе поле MOTCONSU_EV_ID */
          update MOTCONSU set MOTCONSU_EV_ID = inserted.MOTCONSU_ID
          from inserted inner join deleted  on inserted.MOTCONSU_ID = deleted.MOTCONSU_ID
                        inner join MOTCONSU on MOTCONSU.MOTCONSU_ID = inserted.MOTCONSU_ID
          where isnull(deleted.EV_NAME, '') = '' and isnull(inserted.EV_NAME, '') <> '' 
end

if update(MOTCONSU_EV_ID)
begin
          /* При присвоении события */
          /* прописываем всем привязанным через направления записям свой MOTCONSU_EV_ID */
          /* (только если ответные записи не привязаны к другому событию) */
          update MOTCONSU set MOTCONSU_EV_ID = inserted.MOTCONSU_EV_ID
          from inserted inner join deleted  on inserted.MOTCONSU_ID = deleted.MOTCONSU_ID
                        inner join PATDIREC on inserted.MOTCONSU_ID = PATDIREC.MOTCONSU_ID
                        inner join DIR_ANSW on PATDIREC.PATDIREC_ID = DIR_ANSW.PATDIREC_ID
                        inner join MOTCONSU on MOTCONSU.MOTCONSU_ID = DIR_ANSW.MOTCONSU_RESP_ID
                                               and MOTCONSU.MOTCONSU_EV_ID is null and MOTCONSU.MOTCONSU_ID <> inserted.MOTCONSU_ID
          /* Если новое значение не NULL и MOTCONSU_EV_ID изменилось */
          where inserted.MOTCONSU_EV_ID is not null
                and isnull(inserted.MOTCONSU_EV_ID, 0) <> isnull(deleted.MOTCONSU_EV_ID, 0)

          /* прописываем привязку к событию для талонов, созданным по неотвеченным направлениям */
          update FM_BILL set MOTCONSU_EV_ID = inserted.MOTCONSU_EV_ID
          from inserted inner join FM_BILL on FM_BILL.MOTCONSU_DIR_ID = inserted.MOTCONSU_ID
                                              and FM_BILL.MOTCONSU_ID is null
                                              and isnull(FM_BILL.MOTCONSU_EV_ID, 0) <> isnull(inserted.MOTCONSU_EV_ID, 0)

          /* прописываем привязку к событию для талонов привязанных к консультации */
          update FM_BILL set MOTCONSU_EV_ID = inserted.MOTCONSU_EV_ID
          from inserted inner join FM_BILL on FM_BILL.MOTCONSU_ID = inserted.MOTCONSU_ID
                                              and isnull(FM_BILL.MOTCONSU_EV_ID, 0) <> isnull(inserted.MOTCONSU_EV_ID, 0)
end

---------- End of user section ------------
if TRIGGER_NESTLEVEL(OBJECT_ID('tU_MOTCONSU')) > 1
  return

Declare
  @DBKERNEL_USER_ID int,
  @DBKERNEL_HOST_DATABASE_ID int,
  @DBKERNEL_SERVER_DATE DateTime

set @DBKERNEL_USER_ID = (select USER_ID From KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
set @DBKERNEL_HOST_DATABASE_ID = (select top 1 RM_DATABASES_ID from RM_DATABASES where IS_LOCAL = 1)
set @DBKERNEL_SERVER_DATE = GetDate()
set @DBKERNEL_SERVER_DATE = DateAdd(ms, -DatePart(ms, @DBKERNEL_SERVER_DATE), @DBKERNEL_SERVER_DATE)

update t set
  KRN_CREATE_DATE = coalesce(d.KRN_CREATE_DATE, i.KRN_CREATE_DATE),
  KRN_CREATE_USER_ID = coalesce(d.KRN_CREATE_USER_ID, i.KRN_CREATE_USER_ID),
  KRN_CREATE_DATABASE_ID = coalesce(d.KRN_CREATE_DATABASE_ID, i.KRN_CREATE_DATABASE_ID),
  KRN_GUID = coalesce(d.KRN_GUID, i.KRN_GUID),
  KRN_MODIFY_DATE = @DBKERNEL_SERVER_DATE,
  KRN_MODIFY_USER_ID = @DBKERNEL_USER_ID,
  KRN_MODIFY_DATABASE_ID = @DBKERNEL_HOST_DATABASE_ID
from MOTCONSU t, inserted i, deleted d
where t.MOTCONSU_ID = i.MOTCONSU_ID
  and i.MOTCONSU_ID = d.MOTCONSU_ID

insert into KRN_SYS_TRACE(TABLE_NAME, REC_ID, ACTION, KRN_GUID, EXTERNAL_USER_ID)
select 'MOTCONSU', MOTCONSU_ID, 'U', KRN_GUID,
  (select top 1 USER_ID from KRN_SYS_SESSIONS with (nolock) where SESSION_ID = @@SPID)
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRMSG)
  rollback transaction
end
go

