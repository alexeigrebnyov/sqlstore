CREATE trigger tD_OMI_TERR_CODES on OMI_TERR_CODES for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if exists(
  select 1 from deleted D
    inner join DATA_ADDR_WORKPL_CHANGE Z with (nolock)
      on Z.KOD_TERRITORII = D.OMS_KOD_TER_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_ADDR_WORKPL_CHANGE', @ERRPARENT = 'OMI_TERR_CODES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join FM_ORG Z with (nolock)
      on Z.OMS_KOD_TER_ID = D.OMS_KOD_TER_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'FM_ORG', @ERRPARENT = 'OMI_TERR_CODES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join MEDECINS Z with (nolock)
      on Z.REGION_STRA_OVANIQ = D.OMS_KOD_TER_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'MEDECINS', @ERRPARENT = 'OMI_TERR_CODES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join OMI_POLICY_FORMATS Z with (nolock)
      on Z.OMS_KOD_TER_ID = D.OMS_KOD_TER_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'OMI_POLICY_FORMATS', @ERRPARENT = 'OMI_TERR_CODES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join OMI_SMORG_HEAD Z with (nolock)
      on Z.OMS_KOD_TER_ID = D.OMS_KOD_TER_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'OMI_SMORG_HEAD', @ERRPARENT = 'OMI_TERR_CODES'
  goto error
end

Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'OMI_TERR_CODES', OMS_KOD_TER_ID, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

