CREATE trigger tD_PAYMENT_TYPES on PAYMENT_TYPES for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if exists(
  select 1 from deleted D
    inner join DATA_AMBULAT_PATIENT_COUPON Z with (nolock)
      on Z.ED_PAYMENT_TYPE_ID = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_AMBULAT_PATIENT_COUPON', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_EPICRISIS Z with (nolock)
      on Z.VID_OPLAT = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_EPICRISIS', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_HOSPITALIZ_ADM_ROOM Z with (nolock)
      on Z.KINDS_PAYMENT_ID = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_HOSPITALIZ_ADM_ROOM', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_MOTCONSU_BILLDET Z with (nolock)
      on Z.VID_OPLATY = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_MOTCONSU_BILLDET', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_OPERATIONS_F_066U_03 Z with (nolock)
      on Z.KINDS_PAYMENT_ID = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_OPERATIONS_F_066U_03', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_PATDIREC Z with (nolock)
      on Z.VID_OPLATY = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_PATDIREC', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_SURGICAL_OPER Z with (nolock)
      on Z.PAYMENT_TYPE_ID = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_SURGICAL_OPER', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join DATA_WAITING_SHEET Z with (nolock)
      on Z.VIDY_OPLATY_SSYLKA = D.KINDS_PAYMENT_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_WAITING_SHEET', @ERRPARENT = 'PAYMENT_TYPES'
  goto error
end

Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'PAYMENT_TYPES', KINDS_PAYMENT_ID, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

