CREATE trigger tD_PROCEDURES on PROCEDURES for DELETE as
begin
declare  @ERRNO   int,
         @NUMROWS int,
         @ERRMSG  varchar(255),
         @ERRCHILD  varchar(255),
         @ERRPARENT  varchar(255)
set @NUMROWS = @@ROWCOUNT
if @NUMROWS = 0 or dbo.TriggersEnabled() = 0
  return
if exists(
  select 1 from deleted D
    inner join DATA_PROCEDURES_PERFORM Z with (nolock)
      on Z.PROCEDURES_ID = D.PROCEDURES_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'DATA_PROCEDURES_PERFORM', @ERRPARENT = 'PROCEDURES'
  goto error
end

if exists(
  select 1 from deleted D
    inner join PMT_DATA387 Z with (nolock)
      on Z.PROTSEDURA = D.PROCEDURES_ID)
begin
  select @ERRNO  = 51002, @ERRCHILD = 'PMT_DATA387', @ERRPARENT = 'PROCEDURES'
  goto error
end

Declare @EXTERNAL_USER_ID int
select @EXTERNAL_USER_ID = USER_ID From KRN_SYS_SESSIONS with (nolock)
where SESSION_ID = @@SPID
insert KRN_SYS_DELETE_TRACE(TABLE_NAME, REC_ID, KRN_GUID, EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID)
select 'PROCEDURES', PROCEDURES_ID, KRN_GUID, @EXTERNAL_USER_ID, KRN_CREATE_DATABASE_ID
from deleted

return

usererror:
  raiserror (100000, 16, 1, @ERRMSG)
  rollback transaction
  return

error:
  raiserror (@ERRNO, 16, 1, @ERRPARENT, @ERRCHILD)
  rollback transaction
end
go

