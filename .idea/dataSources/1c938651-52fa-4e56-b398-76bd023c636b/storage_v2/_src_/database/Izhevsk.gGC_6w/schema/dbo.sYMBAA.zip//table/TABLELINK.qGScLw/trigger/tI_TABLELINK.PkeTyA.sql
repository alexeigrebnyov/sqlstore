

CREATE trigger tI_TABLELINK on TABLELINK for INSERT as
begin
  declare  @numrows int,
           @nullcnt int,
           @validcnt int,
           @errmsg  varchar(255)

  select @numrows = @@rowcount
  if update(PARENT)
  begin
    select @nullcnt = 0
    select @validcnt = count(*)
    from inserted,METATABLE
    where inserted.PARENT = METATABLE.TABLE_NAME

    if @validcnt + @nullcnt != @numrows
    begin
      select @errmsg = 'Cannot INSERT TABLELINK because METATABLE does not exist.'
      goto error
    end
  end

  if update(CHILD)
  begin
    select @nullcnt = 0
    select @validcnt = count(*)
    from inserted,METATABLE
    where  inserted.CHILD = METATABLE.TABLE_NAME

    if @validcnt + @nullcnt != @numrows
    begin
      select @errmsg = 'Cannot INSERT TABLELINK because METATABLE does not exist.'
      goto error
    end
  end

  return
error:
    raiserror (@errmsg, 16, 1)
    rollback transaction
end

go

